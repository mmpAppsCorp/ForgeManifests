# 1950s Retro Diner | Map Pack (Walled)

1950s Retro Diner | Map Pack delivers a classic roadside eatery steeped in chrome, neon, and mid-century Americana—perfect for slice-of-life scenes, investigations, chance encounters, or tense confrontations over coffee and pie.

This pack includes two distinct diner environments: an authentic 1950s Diner capturing the look and feel of the era, and a Modern-Day Retro 1950s Diner that preserves the nostalgic aesthetic while fitting seamlessly into contemporary settings. Both locations feature booth seating, counters, kitchen areas, and the unmistakable charm of a timeless diner.

Whether serving as a casual meeting place, a narrative hub, or the backdrop for secrets and suspense, 1950s Retro Diner | Map Pack provides a versatile, character-rich setting ready for stories across multiple time periods.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- 1950s Diner
- Modern Day Retro 1950s Diner

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
