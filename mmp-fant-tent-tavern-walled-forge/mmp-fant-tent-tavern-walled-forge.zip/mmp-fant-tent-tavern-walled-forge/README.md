# Tent Tavern | Map Pack (Walled)

Tent Tavern | Map Pack delivers a mobile wilderness gathering place perfect for nomadic cultures, desert caravans, frontier traders, or traveling mercenaries.

This pack features a fully realized Tent Tavern, presented both inside and outside, capturing the feel of a temporary but well-used social hub. Canvas walls, fire pits, rugs, makeshift furnishings, and supply areas create a flexible space that can serve as a neutral meeting ground, a lively drinking spot, or a tense negotiation site.

Whether encountered along a trade route, at the edge of a desert oasis, or deep in the wilds, Tent Tavern | Map Pack provides an atmospheric and versatile setting for wilderness encounters, shifting alliances, and stories that move with the road.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tent Tavern - nomads, inside & outside

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
