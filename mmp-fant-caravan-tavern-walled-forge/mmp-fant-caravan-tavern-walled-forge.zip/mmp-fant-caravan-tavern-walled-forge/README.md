# Fantasy Caravan Tavern | Map Pack (Walled)

Caravan Tavern | Map Pack provides a rugged, mobile gathering place ideal for desert crossings, trade routes, borderlands, and remote wilderness campaigns.

This pack features a fully realized Caravan Tavern shown inside, outside, and underneath, capturing the feel of a traveling inn built onto wagons, beasts of burden, or makeshift platforms. The interior works perfectly for tense negotiations, secret meetings, or rowdy drinking scenes, while the exterior supports ambushes, defenses, and roadside encounters. The underside offers hidden storage, smuggling compartments, or covert entrances for less honest dealings.

Whether used as a neutral trading stop, a nomadic social hub, or a dangerous meeting ground far from the law, Caravan Tavern | Map Pack delivers a flexible and atmospheric setting for fantasy and frontier adventures alike.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Caravan Tavern - inside, outside, underneath

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
