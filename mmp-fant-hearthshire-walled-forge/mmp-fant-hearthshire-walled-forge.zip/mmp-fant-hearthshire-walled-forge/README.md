# Hearthshire - Halfling Village | Map Pack (Walled)

Hearthshire | Map Pack delivers a warm, storybook halfling village designed for cozy roleplay, local intrigue, and deceptively important small-folk adventures.

This pack centers on Hearthshire, a fully realized halfling settlement built around comfort, community, and quiet secrets. The village includes a welcoming Tavern, working Brewery, charming Homes, and a lively Town Square—each presented with both interior and rooftop maps to support stealth, observation, or unexpected action.

Beyond everyday life, Hearthshire offers locations that invite deeper storytelling, including a Wealthy Home that hints at hidden influence, a Wizard’s Hovel tucked away from prying eyes, and a Community Garden that serves as a peaceful gathering place—or a perfect site for clandestine meetings.

Ideal for social encounters, mystery arcs, low-level adventures, or as a tranquil contrast to darker regions, Hearthshire | Map Pack provides a richly detailed halfling village where small places can host big stories.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hearthshire - Halfling Village
  - Brewery - inside & roof
  - Home - inside & roof
  - Tavern - inside & roof
  - Town Square
  - Community Garden
  - Wealthy Home - inside & roof
  - Wizard's Hovel - inside & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
