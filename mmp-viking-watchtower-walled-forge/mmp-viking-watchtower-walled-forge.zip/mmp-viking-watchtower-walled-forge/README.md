# Viking Village - Watchtower | Map Pack (Walled)

Viking Village – Watchtower | Map Pack provides a fortified lookout essential to the defense and vigilance of a Norse settlement, perfect for early-warning scenes, raids, sieges, or tense standoffs on the village edge.

This pack features a three-level Viking watchtower, with interior and exterior spaces designed for guards, signal fires, and long-range observation. The vertical layout supports layered encounters, from ground-level breaches to desperate last stands at the top.

All land maps are included in summer and winter environments, allowing the tower to serve equally well during calm trading seasons or harsh, snowbound conflicts.

Whether used as a defensive stronghold, a place of imprisonment, or the first point of contact with approaching danger, Viking Village – Watchtower | Map Pack adds height, tension, and strategic depth to your Viking-era adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Watchtower - three levels

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
