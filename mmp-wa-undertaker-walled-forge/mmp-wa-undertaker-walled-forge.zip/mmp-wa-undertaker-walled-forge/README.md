# Western Adventures - Undertakers | Map Pack (Walled)

Western Adventures - Undertakers| Map Pack delivers a somber frontier business ideal for grim investigations, last rites, suspicious deaths, or secrets buried with the past.

This pack includes both Large and Small Undertaker Offices, presented in summer and winter settings, featuring preparation rooms, viewing areas, storage, and private workspaces—perfect for quiet roleplay, tense interrogations, or uncovering dark truths beneath a respectable façade.

Whether serving as a place of mourning, a cover for illicit dealings, or the starting point of a mystery, Western Adventures - Undertakers| Map Pack provides an atmospheric and versatile location for Western adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Undertaker Office / Small Undertaker Office - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
