# Airplane Hanger | Map Pack (Walled)

Airplane Hangar | Map Pack delivers a versatile aviation support environment ideal for modern action, espionage, smuggling, disaster response, or military-focused campaigns.

This pack centers on a detailed Airplane Hangar, suitable for maintenance operations, covert meetings, emergency repairs, or high-stakes infiltration. The hangar is paired with both dirt and asphalt runways, allowing it to represent anything from a remote bush airstrip to a semi-developed regional facility.

To support global storytelling, the location is provided across multiple environments—arctic, desert, forest, grassland, and jungle—making it easy to place the hangar anywhere in the world. Two aircraft overlay tiles are included, giving you full control over whether the hangar is occupied, abandoned, or in the middle of frantic activity.

Whether your scene involves a hurried takeoff, a secret cargo transfer, or a tense standoff on the runway, Airplane Hangar | Map Pack provides a flexible and immersive setting ready for play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Airplane Hanger
  - Dirt & asphalt runways
  - Arctic, desert, forest, grass & jungle environments
  - Two plane tiles

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
