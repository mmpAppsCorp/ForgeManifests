# Jungle Tavern | Map Pack (Walled)

Jungle Tavern | Map Pack delivers a remote, humid hideaway deep within dense jungle terrain—perfect for ambushes, secret meetings, smuggler stops, or dangerous rest stops far from civilization.

This pack features a two-level Jungle Tavern built from weathered wood and stone, surrounded by thick vegetation and oppressive heat. The layout supports tense negotiations, surprise attacks from the treeline, and uneasy truces between travelers, mercenaries, and locals.

Whether used as a neutral meeting ground, a lawless outpost, or a front for darker activity hidden beneath the canopy, Jungle Tavern | Map Pack provides a flavorful and atmospheric setting for wilderness and exploration-focused campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Jungle Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
