# Capital Ship | Map Pack (Walled)

Capital Ship | Map Pack delivers a fully realized military starship environment designed for large-scale sci-fi campaigns, fleet actions, boarding operations, and high-stakes command drama. Every map is provided in both normal and alert status, allowing you to instantly shift tone from routine operations to full combat readiness.

This pack includes a comprehensive set of internal and external ship locations, from the Bridge and Captain’s Quarters & Ready Room to expansive Cargo Bays, Freight Processing, and multiple Landing and Launch Bays. Key operational areas such as the Computer Core, Power Core, Thruster Maintenance, Water Treatment, and Executive Landing Pad support engineering crises, sabotage, or tactical objectives deep within the vessel.

Security and personnel spaces round out the ship, including Troop Transport Bays, Armoury, Medical, Detention Center, Mess & Kitchen, and several typical corridor layouts ideal for firefights, patrols, or tense stand-offs. Whether your story centers on command decisions, internal threats, or all-out boarding actions, Capital Ship | Map Pack provides a versatile and immersive setting for epic spacefaring adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Capital Ship, all maps have normal & alert status
  - Bridge
  - Captain's Quarters & Ready Room
  - Cargo Bay
  - Freight Dock - open & closed
  - Freight Processing
  - Large Cargo Bay
  - Three Typical Corridors
  - Computer Core
  - Power Core
  - Thruster Maintenance
  - Water Treatment
  - Executive Landing Pad
  - Troop Transport Bay
  - Launch Bay
  - Landing Bay
  - Medical
  - Armoury
  - Detention Center
  - Kitchen & Mess

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
