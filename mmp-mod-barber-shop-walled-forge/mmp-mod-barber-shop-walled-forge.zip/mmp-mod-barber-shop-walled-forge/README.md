# Barber Shop | Map Pack (Walled)

Barber Shop | Map Pack delivers a classic modern grooming business suited for investigations, street-level drama, undercover meetings, or everyday slice-of-life scenes.

This pack features a detailed Barber Shop interior with chairs, mirrors, waiting area, and workstations—ideal for conversations overheard mid-cut, tense confrontations in a confined space, or quiet meetings disguised as routine appointments.

Whether it’s a neighborhood staple, a front for illicit dealings, or the backdrop for character-driven moments, Barber Shop | Map Pack provides a grounded, flexible setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Barber Shop

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
