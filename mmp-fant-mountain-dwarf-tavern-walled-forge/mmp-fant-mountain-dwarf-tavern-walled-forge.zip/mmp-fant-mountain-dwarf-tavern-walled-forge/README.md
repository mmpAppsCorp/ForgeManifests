# Mountain Dwarf Tavern | Map Pack (Walled)

Mountain Dwarf Tavern | Map Pack delivers a rugged, stone-hewn tavern carved directly into the mountainside, perfect for underground intrigue, clan politics, mining disputes, or hard-drinking adventurers seeking shelter from the cold.

This pack features a three-level tavern complex physically connected to an active mine, blending communal drinking halls with industrial dwarven spaces. Heavy stone walls, forge-lit interiors, and utilitarian layouts create a setting that feels both lived-in and defensible, ideal for tense negotiations, ambushes, or subterranean encounters.

Whether used as a neutral meeting ground between clans, a front for illicit mining operations, or a last refuge deep in the mountains, Mountain Dwarf Tavern | Map Pack provides a distinctive and atmospheric location for fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Mountain Dwarf Tavern - attached to a mine, three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
