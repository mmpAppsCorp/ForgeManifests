# Backwater Town - Sheriff | Map Pack (Walled)

Backwater Town – Sheriff | Map Pack delivers a rugged frontier law office ideal for tense standoffs, uneasy interrogations, jailbreaks, or last-stand shootouts in a remote and lawless settlement.

This pack features a two-level Sheriff’s Office, complete with functional workspaces, holding areas, and living quarters—perfect for investigations, corruption plots, or a town where the badge is the only thin line between order and chaos.

All maps are provided in arctic, desert, and grassland environments and include both furnished and unfurnished versions, allowing you to tailor the location to anything from an established outpost of justice to a barely functioning symbol of authority in a forgotten town.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Sheriff - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
