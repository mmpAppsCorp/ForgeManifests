# Firehall | Map Pack (Walled)

Firehall | Map Pack delivers a fully realized emergency services facility ideal for modern campaigns involving first responders, urban disasters, investigations, or high-stakes action scenes.

This pack features a detailed Firehall presented across ground, upper, and roof levels, with versions both with and without fire trucks present. Interior spaces support scenes ranging from routine operations and briefings to urgent call-outs, evacuations, and emergencies that unfold in real time.

Whether used as an active response hub, a coordination center during a citywide crisis, or the backdrop for dramatic character moments between calls, Firehall | Map Pack provides a flexible and authentic setting for modern adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Firehall - ground, upper, roof, with and without trucks

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
