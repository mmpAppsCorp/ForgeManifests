# Desert Tavern | Map Pack (Walled)

Desert Tavern | Map Pack delivers a rugged, sun-scorched roadside refuge ideal for frontier travel, smuggling routes, mercenary meetups, or tense negotiations far from the safety of cities.

This pack features a two-level desert tavern built to withstand heat, dust, and isolation, with shaded gathering spaces, utilitarian interiors, and upper-level rooms that overlook the surrounding wasteland. It works equally well as a neutral meeting ground, a dangerous watering hole, or the last stop before a long and unforgiving journey.

Whether your party is seeking shelter from the elements, information from hardened locals, or trouble that finds them first, Desert Tavern | Map Pack provides a compact but atmospheric setting perfectly suited for harsh environments and high-stakes encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Desert Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
