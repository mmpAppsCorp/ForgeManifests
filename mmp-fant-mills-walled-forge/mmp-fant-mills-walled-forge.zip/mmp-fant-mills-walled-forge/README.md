# Fantasy Windmill & Water Mill | Map Pack (Walled)

Fantasy Windmill & Water Mill | Map Pack delivers two iconic pieces of medieval infrastructure, perfect for rural settlements, trade routes, hidden lairs, or dramatic encounters driven by industry and necessity.

This pack includes a fully detailed Water Mill and Windmill, each mapped across five levels, showcasing working machinery, storage areas, living spaces, and upper mechanisms. These vertical layouts make them ideal for investigations, ambushes, sabotage, or tense vertical combat where control of space matters.

Whether serving as vital economic hubs, secluded meeting points, or deceptively quiet locations hiding secrets below the grindstones, Fantasy Windmill & Water Mill | Map Pack provides versatile, story-rich environments for any fantasy campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Water Mill - five levels
- Windmill - five levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
