# Big Ben | Map Pack (Walled)

**Big Ben | Map Pack** brings one of the world’s most iconic landmarks into your game as a fully explorable vertical location, perfect for political intrigue, espionage, supernatural mysteries, time-based anomalies, or high-stakes infiltration scenarios.

This pack presents Big Ben from its foundations to the belfry, mapping the tower floor by floor as a dense, layered environment filled with narrow stairwells, maintenance spaces, hidden rooms, and imposing mechanical structures. From shadowy lower levels to the thunderous clockworks above, every ascent raises both tension and stakes.

Explore utilitarian basements, administrative and storage floors, forgotten prison levels, and the inner workings of the clock itself. The upper reaches culminate in the Belfry, where massive bells loom overhead—ideal for dramatic confrontations, daring escapes, or climactic finales framed by echoing chimes.

Whether your adventure calls for covert operations, historical drama, occult investigations, or modern thrillers, **Big Ben | Map Pack** provides a distinctive vertical setting that rewards exploration and careful planning.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Basement Floor
- Ground Floor
- 1st Floor
- 2nd Floor
- 3rd Floor - prison
- 4th Floor
- 5th Floor
- 6th Floor - storage
- 7th Floor - maintenance
- 8th Floor - clocks
- 9th Floor - link room
- 10th Floor - Belfry
- 11th Floor - Ayrton Light

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
