# Fantasy Miner Tavern | Map Pack (Walled)

Miner Tavern | Map Pack delivers a rugged, hard-worn gathering place carved from stone and sweat, ideal for frontier settlements, mountain towns, and underground communities where miners gather after long shifts below ground.

This pack features a four-level tavern designed around the needs of laborers and prospectors, with rough common areas, private back rooms, storage spaces, and deeper levels that hint at tunnels, secrets, or forgotten shafts. The vertical layout supports everything from tense negotiations and barroom brawls to hidden dealings and dangerous discoveries beneath the tavern itself.

Whether used as a local hub for rumors and contracts, a neutral meeting place between rival crews, or the entrance to something far more dangerous below, Miner Tavern | Map Pack provides a gritty, atmospheric location perfectly suited for fantasy and frontier adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Miner Tavern - four levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
