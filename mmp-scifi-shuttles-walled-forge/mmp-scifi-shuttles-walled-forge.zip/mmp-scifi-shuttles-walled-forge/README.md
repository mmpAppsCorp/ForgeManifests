# Space Shuttles | Map Pack (Walled)

Space Shuttles | Map Pack delivers a versatile collection of compact spacecraft interiors designed for transport, missions, emergencies, and high-stakes encounters in science-fiction campaigns.

This pack features a wide range of shuttle types—from cargo haulers and executive transports to medical, research, and prisoner transfer vessels—each providing distinct layouts suited to their roles. A fully empty shuttle and generic lower deck are included for easy customization, allowing you to tailor interiors to your story’s needs.

To support cinematic variety, all shuttles are provided across multiple environments, including landed configurations on arctic, desert, grass, metal, and pavement surfaces, as well as dramatic flying scenes in both open sky and deep space.

Whether used for routine travel, covert insertions, medical evacuations, or tense boarding actions, Space Shuttles | Map Pack offers flexible, reusable maps that fit seamlessly into any space-opera or sci-fi setting.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Shuttles
  - Cargo Shuttle
  - Empty Shuttle - for you to customize
  - Executive Shuttle
  - Mechanical Shuttle
  - Medical Shuttle
  - Passenger Shuttle
  - Research Shuttle
  - Prisoner Transfer Shuttle
  - Generic Lower Deck
  - Generic Underside

Provided in six environments
  - Landed Arctic
  - Landed Desert
  - Landed Grass
  - Landed Metal
  - Landed Pavement
  - Flying Space
  - Flying Sky

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
