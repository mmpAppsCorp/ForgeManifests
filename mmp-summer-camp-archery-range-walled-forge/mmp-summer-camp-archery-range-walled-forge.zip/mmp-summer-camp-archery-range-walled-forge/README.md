# Summer Camp - Archery Range | Map Pack (Walled)

Summer Camp – Archery Range | Map Pack delivers a focused outdoor training and competition space ideal for camp activities, rival challenges, accidents gone wrong, or tense wilderness encounters.

This pack features a detailed Archery Range layout designed for instruction, practice, and contests, with clear shooting lanes, target areas, and surrounding terrain that can easily escalate from friendly competition into dramatic action.

Whether used for summer camp training, survival scenarios, scouting trials, or the opening scene of something far more dangerous, Summer Camp – Archery Range | Map Pack provides a clean, flexible setting ready for storytelling and conflict.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Archery Range

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
