# Cabins in the Woods | Map Pack (Walled)

Cabins in the Woods | Map Pack delivers isolated rural dwellings perfect for survival horror, crime investigations, wilderness encounters, or tense character-driven scenes far from civilization.

This pack features a Wood Cabin and Stone Cabin, each provided in both summer and winter environments, allowing you to shift the tone from quiet retreat to frozen isolation. Also included is the infamous Mail Bomber’s Cabin, a remote and unsettling location ideal for manhunts, psychological thrillers, or true-crime–inspired scenarios.

Whether used as a peaceful hideaway, a suspect’s refuge, or a place where something has gone terribly wrong, Cabins in the Woods | Map Pack offers atmospheric, story-driven locations designed to make isolation feel dangerous.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Wood Cabin - summer & winter
- Stone Cabin - summer & winter
- Mail Bomber's Cabin

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
