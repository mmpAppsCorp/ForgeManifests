# Airport | Map Pack (Walled)

Airport | Map Pack delivers a fully realized modern airport environment designed for high-tension security scenes, travel-focused adventures, smuggling operations, disasters, and fast-moving chases.

This pack features a detailed airport complex with clearly defined public, restricted, and high-security zones, including Arrivals, Departures, Boarding Lounge, Security, Customs & Border Control, and Luggage Routing. Exterior and operational areas such as the Tarmac and Air Traffic Control provide ideal settings for runway incidents, covert extractions, or large-scale emergencies.

Whether your scenario involves international intrigue, time-critical departures, border inspections, or chaos spreading through a busy terminal, Airport | Map Pack offers a versatile and immersive location for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Airport
  - Arrivals
  - Departures
  - Boarding Lounge
  - Customs & Border Control
  - Security
  - Tarmac
  - Luggage Routing
  - Air Traffic Control

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
