# Pool Hall | Map Pack (Walled)

Pool Hall | Map Pack delivers a classic recreational venue ideal for casual meetups, tense conversations, underground dealings, or sudden confrontations in modern campaigns.

This pack features a detailed Pool Hall interior, complete with pool tables, seating areas, bar space, and ambient details that make it easy to stage everything from friendly games and social scenes to criminal negotiations or violent escalations.

Whether the location serves as a neighborhood hangout, a front for illicit activity, or the backdrop for a dramatic showdown, Pool Hall | Map Pack provides a flexible and atmospheric setting that fits seamlessly into urban adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Pool Hall

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
