# Viking Village - Training Grounds | Map Pack (Walled)

Viking Village – Training Grounds | Map Pack delivers a rugged outdoor combat and drills area designed for warriors honing their skills in preparation for raids, duels, and warfare.

This pack features a detailed Training Grounds map suitable for sparring, weapon practice, shield walls, and tactical exercises. It works equally well for daily village life scenes or high-stakes moments where rival clans, challengers, or would-be heroes test their strength.

All land maps are provided in both summer and winter environments, allowing you to shift the tone from muddy training fields to snow-covered proving grounds as seasons change.

Whether used for character backstories, rite-of-passage trials, or sudden ambushes during practice, Viking Village – Training Grounds | Map Pack adds an authentic martial space to any Norse-inspired campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Training Grounds

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
