# Hospital | Map Pack (Walled)

Hospital | Map Pack delivers a comprehensive modern medical facility ideal for emergency response scenarios, investigative drama, tense rescues, or high-stakes confrontations where lives are on the line.

This pack features a fully realized hospital layout, including a chaotic Emergency Entrance, a controlled Public Entrance, and detailed interior wings such as Radiology, Surgery, Patient Rooms, and dedicated Staff Areas. Each space is designed to support fast-paced action, quiet investigation, or moral dilemmas under pressure.

Whether your scene involves a midnight trauma intake, a covert operation through sterile corridors, or a desperate race against time, Hospital | Map Pack provides a versatile and immersive setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hospital
  - Emergency Entrance
  - Public Entrance
  - Radiology Wing
  - Rooms Wing
  - Surgery Wing
  - Staff Areas

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
