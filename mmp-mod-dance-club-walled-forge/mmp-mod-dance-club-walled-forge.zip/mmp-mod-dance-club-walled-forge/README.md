# Warehouse Dance Club | Map Pack (Walled)

Warehouse Dance Club | Map Pack delivers a gritty, high-energy rave venue perfect for underground parties, criminal meetups, covert exchanges, or chaotic encounters that spiral out of control.

This pack features a sprawling Warehouse Dance Club interior with an open club floor built for massive crowds, pulsing lights, and booming sound systems, along with an elevated mezzanine ideal for VIP areas, DJs, or overlooking the action below. The exterior map provides space for arrivals, security, backdoor dealings, or law-enforcement crackdowns.

Whether your scene involves an illegal rave, a secret rendezvous hidden in plain sight, or a violent interruption under strobe lights and bass, Warehouse Dance Club | Map Pack provides a versatile modern setting built for tension, movement, and mayhem.

Whether your adventure involves undercover stings, heist planning, gang conflicts, missing-person investigations, or neon-soaked nightlife vignettes, Modern Adult Entertainment | Map Pack gives you immersive modern environments ready for any storyline.

---

## Included Maps

This pack contains the following locations:

- Warehouse Dance Club - club, mezzanine, exterior

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
