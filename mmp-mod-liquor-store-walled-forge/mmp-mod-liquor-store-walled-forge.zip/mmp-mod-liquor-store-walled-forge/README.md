# Liquor Store | Map Pack (Walled)

Liquor Store | Map Pack provides a compact but versatile retail location ideal for modern, urban, or small-town encounters. Whether your scenario involves a late-night robbery, a tense negotiation, undercover surveillance, or an unexpected confrontation in a quiet neighborhood, this map delivers a familiar and flexible setting.

The interior store layout features aisles, coolers, counters, and storage areas suitable for tactical movement, social encounters, or quick smash-and-grab scenes. The included rooftop map adds verticality, escape routes, and opportunities for ambushes, overwatch, or dramatic chases.

Perfect for crime stories, investigative campaigns, or everyday street-level adventures, Liquor Store | Map Pack slots easily into any modern setting as a believable and frequently visited location.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Liquor Store - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
