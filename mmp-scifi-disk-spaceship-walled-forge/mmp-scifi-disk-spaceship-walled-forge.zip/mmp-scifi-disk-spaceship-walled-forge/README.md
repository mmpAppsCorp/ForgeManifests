# Federation Disk Spaceship | Map Pack (Walled)

Federation Disk Spaceship | Map Pack delivers a classic, exploration-focused starship environment ideal for science-fiction campaigns centered on diplomacy, discovery, military action, or deep-space intrigue.

This pack features a fully realized disk-shaped spacecraft with clearly defined operational zones. The Upper Deck includes the Bridge, security areas, crew quarters, teleporter, science sections, and mess—perfect for command decisions, first-contact encounters, or tense internal conflicts. The Lower Deck expands the ship’s functionality with Engineering, Cargo areas, and a Hangar Deck presented both empty and fully occupied, supporting boarding actions, repairs under fire, or covert loading operations.

Additional locations such as Toppers Bar provide a social hub for crew interaction, negotiations, or off-duty drama, while the Gunwells allow for defensive or combat-oriented scenarios during ship-to-ship engagements.

Whether used as a flagship of an interstellar fleet, a roaming exploration vessel, or the centerpiece of a long-running campaign, Federation Disk Spaceship | Map Pack offers a versatile and immersive setting for spacefaring adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Federation Disk Spaceship
  - Upper Deck - Bridge, security, quarters, teleporter, science, mess
  - Lower Deck - Engineering, Hanger Deck (empty & Full), Cargo
  - Toppers Bar
  - Gunwells

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
