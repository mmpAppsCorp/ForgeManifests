# Modern Subway | Map Pack (Walled)

Modern Subway | Map Pack delivers a flexible underground transit environment ideal for chases, covert meetings, urban horror, infrastructure sabotage, or large-scale city encounters.

This pack features a modular modern subway system with a wide variety of track configurations—including straight runs, corners, diverging lines, exchanges, and complex junctions—allowing you to build anything from a simple station stop to a sprawling underground network. Platforms are provided in multiple forms, including standard platforms, connectors, and top-side access points, supporting both passenger areas and service zones.

A detailed subway car and engine tile are included, with all orientations provided, making it easy to stage train arrivals, emergency stops, ambushes, or evacuation scenarios.

Whether your story involves tense pursuits beneath the city, hidden operations in forgotten tunnels, or disasters unfolding on the rails, Modern Subway | Map Pack provides a clean, adaptable foundation for modern urban adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Subway
  - Tracks - combine, corner, diverge, exchange, straight
  - Platform - platform, connector, top-side
  - A subway car and engine tile
  - All orientations provided

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
