# Summer Camp - Mess & Kitchen | Map Pack (Walled)

Summer Camp – Mess & Kitchen | Map Pack delivers the heart of camp life, where meals are prepared, announcements are made, and tensions quietly simmer beneath the surface.

This pack includes a fully realized Mess & Kitchen, featuring communal dining space, food preparation areas, storage, and service zones, along with a roof map for maintenance access, rooftop encounters, or late-night sneaking. It’s an ideal setting for social scenes, investigations, supply shortages, or moments when routine breaks down.

Whether used for wholesome camp activities, mystery-driven storytelling, or darker late-night encounters, Summer Camp – Mess & Kitchen | Map Pack provides a versatile and familiar location that anchors any summer camp adventure.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Mess & Kitchen - ground & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
