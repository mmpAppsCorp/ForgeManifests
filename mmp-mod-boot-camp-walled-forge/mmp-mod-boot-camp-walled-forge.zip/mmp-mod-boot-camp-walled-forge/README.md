# Military Boot Camp | Map Pack (Walled)

**Military Boot Camp | Map Pack** provides a complete training installation designed for modern military, paramilitary, or tactical campaign settings. These maps are ideal for recruitment arcs, training montages, disciplinary scenarios, infiltration missions, or early-career character development.

The boot camp is presented as a cohesive facility featuring all core operational areas, including Administration, Barracks, Classrooms, a live-fire Firing Range, Mess & Kitchen facilities, and a full Obstacle Course for physical training and endurance challenges.

To support a wide range of climates and story tones, every location is provided in arctic, desert, and grassland environments—allowing the same installation to represent frozen outposts, harsh desert training grounds, or temperate military bases.

Whether your scenario involves basic training, covert operations, sabotage, inspections, or escape attempts, **Military Boot Camp | Map Pack** delivers a flexible, grounded military setting ready for immediate play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Boot Camp - arctic, desert, grass configurations
  - Admin Building
  - Barracks
  - Classroom
  - Firing Range
  - Mess & Kitchen
  - Obstacle Course

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
