# Airplanes - 737 & Private Jet | Map Pack (Walled)

Airplanes – 737 & Passenger Jet | Map Pack delivers detailed modern aircraft environments ideal for high-altitude emergencies, tense negotiations, airborne combat, hijack scenarios, or disaster-focused storytelling.

This pack includes a fully realized Passenger Jet mapped across the main deck and cargo deck, presented in multiple states—flying, landed, emergency landing, and water landing—giving you maximum flexibility for dramatic midair or ground-based encounters. A sleek Private Jet is also included in both flying and landed configurations, perfect for VIP transport, corporate intrigue, or covert operations.

Whether your scene takes place at cruising altitude, on a runway, or in the aftermath of a forced landing, Airplanes – 737 & Passenger Jet | Map Pack provides versatile, realistic aircraft maps ready for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Passenger Jet - main deck & cargo deck, flying, landed, emergency, water landing
- Private Jet - flying & landed

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
