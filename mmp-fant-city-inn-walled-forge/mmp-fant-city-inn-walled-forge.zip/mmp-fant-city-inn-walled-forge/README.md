# Fantasy City Inn | Map Pack (Walled)

Fantasy City Inn | Map Pack delivers a fully realized urban inn designed for intrigue, investigation, and classic fantasy roleplay in the heart of a bustling city.

This pack features a multi-level City Inn with a lively ground-floor pub and kitchen, staff quarters, and an enclosed inner court—perfect for social encounters, rumors, and secret meetings. Upper floors provide common rooms and private accommodations, including an owner’s suite, while the cellar adds depth with an exit to the sewers and optional teleportation circle for covert movement or magical complications.

All maps are provided in arctic, desert, and forest environments, allowing the inn to seamlessly fit into a wide range of settings—from frozen capitals to sun-baked trade cities or woodland crossroads.

Whether serving as a party hub, a den of secrets, or the starting point for urban adventures, Fantasy City Inn | Map Pack offers a versatile and story-rich location ready for play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy City Inn
  - Ground Floor - pub, kitchen, staff quarters, inner court
  - Second Floor - common rooms, owner's suite
  - Third Floor - common rooms & private rooms
  - Cellar - exit to sewers, with and without teleportation circle

All are provided in arctic, desert, and forest environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
