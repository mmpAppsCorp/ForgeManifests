# Lonely Church | Map Pack (Walled)

Lonely Church | Map Pack delivers an isolated, atmospheric place of worship ideal for tense confrontations, hidden agendas, quiet reflection, or sudden violence far from civilization.

This pack features a Lonely Church set in stark isolation, with detailed interior and exterior maps that emphasize its remoteness and uneasy calm. The church interior supports intimate, dialogue-heavy scenes, while the surrounding grounds and rooftop create space for ambushes, standoffs, or dramatic arrivals.

Perfect for modern crime dramas, revenge tales, western-inspired stories, or cinematic one-on-one encounters, Lonely Church | Map Pack provides a minimalist but powerful setting where isolation amplifies every decision.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Lonely Church - church & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
