# Backwater Town - Cantina | Map Pack (Walled)

Backwater Town – Cantina | Map Pack delivers a gritty frontier watering hole ideal for smugglers, mercenaries, travelers, and those looking to stay off the authorities’ radar. This cantina serves as a social crossroads where deals are made, fights break out, and secrets change hands over cheap drinks and loud music.

The map features a fully realized Cantina interior designed for tense negotiations, undercover meetings, sudden brawls, or dramatic ambushes. Its layout supports both roleplay-heavy scenes and fast-moving combat encounters, making it a versatile hub for story progression.

All maps are provided in arctic, desert, and grassland environments, allowing the cantina to fit seamlessly into frozen outposts, dusty frontier towns, or remote rural settlements. Each version is available furnished and unfurnished, giving you full control over how the space is dressed and used in your campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Cantina

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
