# Fantasy Country Inn | Map Pack (Walled)

earned night’s rest between adventures.

This pack centers on a fully realized country inn, featuring a lively ground floor with courtyard access, stables, and a working pub kitchen, alongside an upper floor of common rooms, staff quarters, and a private owner’s suite. Rooftop watchtowers provide vantage points for guards or lookouts, while the cellar introduces intrigue with versions both with and without a hidden teleportation circle—perfect for smuggling, secret escapes, or magical surprises.

All maps are provided in arctic, desert, and forest environments, allowing the inn to seamlessly fit into a wide range of climates and regions. Whether it serves as a peaceful waypoint, a den of rumors, or the center of a larger mystery, Fantasy Country Inn | Map Pack offers a versatile and atmospheric setting for fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy Country Inn
  - Ground Floor - courtyard, stables, pub kitchen
  - Upper Floor - common rooms, staff quarters, owner's suite, stable loft
  - Rooftops - watchtower
  - Cellar - with and without teleportation circle

All are provided in arctic, desert, and forest environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
