# Beauty Salon | Map Pack (Walled)

Beauty Salon | Map Pack delivers a sleek modern personal-care location ideal for social encounters, investigations, undercover meetings, or sudden trouble in an otherwise ordinary setting.

This pack features a detailed Beauty Salon interior, complete with styling stations, mirrors, wash areas, product displays, and back-of-house spaces—perfect for scenes that mix everyday life with gossip, secrets, or escalating tension.

Whether used as a neighborhood business, a cover for clandestine activity, or the unexpected site of a confrontation, Beauty Salon | Map Pack provides a versatile and believable backdrop for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Beauty Salon

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
