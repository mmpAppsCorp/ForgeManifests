# Viking Village - Longship | Map Pack (Walled)

Viking Village – Longship | Map Pack delivers an iconic Norse seafaring vessel, perfect for raids, exploration, trade missions, sea battles, or tense diplomatic journeys along frozen coasts and open waters.

This pack features a detailed Viking Longship, presented with oars both raised and deployed, allowing you to stage scenes at rest, underway, or preparing for battle. Multiple water conditions are included—calm seas, rough waters, and iced-over oceans—giving you flexibility to represent everything from peaceful voyages to perilous winter crossings.

Whether serving as a raiding ship, a trading vessel, or the pride of a chieftain’s fleet, Viking Village – Longship | Map Pack provides an atmospheric and versatile setting for any Norse-inspired campaign that takes to the sea.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Longship
  - Oars up, oars out
  - Calm, rough, iced waters

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
