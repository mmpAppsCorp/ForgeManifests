# Modern Mansion | Map Pack (Walled)

Modern Mansion | Map Pack delivers a sprawling luxury residence ideal for high-stakes drama, covert operations, elite gatherings, or criminal intrigue in modern campaigns.

This pack features a multi-level modern mansion mapped across four full floors, offering expansive living spaces, private quarters, and architectural variety suitable for infiltration, investigations, or social encounters that can turn dangerous fast.

Whether used as a billionaire’s estate, a secret headquarters, a crime boss’s hideout, or the site of an exclusive event gone wrong, Modern Mansion | Map Pack provides a versatile, upscale environment ready for cinematic play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Modern Mansion - four floors

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
