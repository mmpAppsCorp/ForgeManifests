# Convenience Store | Map Pack (Walled)

Convenience Store | Map Pack delivers a compact, everyday retail location ideal for modern investigations, late-night encounters, robberies gone wrong, or seemingly mundane stops that spiral into chaos.

This pack includes a detailed Convenience Store interior, complete with aisles, counters, coolers, and back-room spaces, along with an accessible Roof—perfect for surveillance, rooftop confrontations, or getaway scenes.

Whether it’s a quick stop for supplies, a crime scene, or the unexpected center of a tense encounter, Convenience Store | Map Pack provides a flexible, familiar setting that fits seamlessly into modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Convenience Store - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
