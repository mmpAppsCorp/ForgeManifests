# Redrum Hotel | Map Pack (Walled)

Redrum Hotel | Map Pack delivers a sprawling luxury hotel setting twisted by escalating horror, shifting realities, and violent echoes of the past—perfect for psychological horror, supernatural investigations, or survival scenarios where the environment itself becomes the threat.

This pack features an expansive multi-floor hotel presented across multiple unsettling states, allowing the same spaces to evolve from pristine and ordinary into blood-soaked, frozen, warped, or reality-breaking nightmares. Lobbies fracture, lounges distort, and guest rooms transform into scenes of violence, torment, and impossible phenomena, giving GMs powerful tools to escalate tension over time.

With kitchens turned murder scenes, employee areas hiding grim secrets, suites consumed by rifts and rituals, and pools that shift from serene to sinister, Redrum Hotel | Map Pack is designed for campaigns where repetition becomes dread and familiarity becomes fear.

Whether used for a slow-burn haunting, a time-loop descent into madness, or a full-scale supernatural outbreak, this map pack provides a deeply atmospheric setting that grows darker the longer players remain inside.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Luxury Hotel
  - Lobby - normal, blood, all-work, rift
  - Lounge - normal, portal, rift, strange
  - Pool - summer, winter, winter empty, summer scary, winter scary, winter empty scary
  - Restaurant - normal, murder, blood bath
  - Kitchen - normal, frozen, murder
  - Employee Suite - normal, frozen, headshot, Johnny, murder
  - Rooms - normal, frozen, headshot, lightning, murder, red, rift, torture
  - Suites - normal, frozen, headshot, murder, red, rift, torture

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
