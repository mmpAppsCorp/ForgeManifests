# Western Adventures - Schools | Map Pack (Walled)

Western Adventures - Schools | Map Pack delivers authentic frontier-era education settings ideal for town life, investigations, social encounters, or dramatic showdowns in the Old West.

This pack includes both a Large Schoolhouse and a One-Room School, each presented in summer and winter environments, capturing the seasonal realities of frontier communities. From structured classrooms to sparse rural learning halls, these locations work equally well for everyday life scenes or tense narrative moments.

Whether used for community gatherings, hostage situations, secret meetings, or quiet moments of normalcy amid frontier danger, Western Adventures - Schools | Map Pack provides ready-to-play educational spaces grounded in historical flavor.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large School / One-Room School - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
