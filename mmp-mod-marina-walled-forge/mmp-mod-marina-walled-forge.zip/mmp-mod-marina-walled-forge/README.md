# Modern Marina | Map Pack (Walled)

Modern Marina | Map Pack delivers a versatile waterfront location ideal for smuggling operations, clandestine meetings, coastal investigations, leisure scenes, or high-stakes chases across docks and open water.

This pack features a detailed modern marina presented with and without yachts, allowing you to depict anything from a quiet harbor to a busy, high-value docking area. Both calm and rough water variants are included, making it easy to shift the mood from serene coastal downtime to dangerous, storm-tossed encounters.

To enhance flexibility, the pack also includes yacht overlay tiles, letting you customize dock layouts, control traffic density, or introduce specific vessels tied to your story.

Whether used as a luxury destination, a criminal rendezvous point, or the launch site for maritime adventures, Modern Marina | Map Pack provides a dynamic and adaptable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Marina - with & without yachts, calm & rough waters

We also include overlay tiles for:
- Yachts

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
