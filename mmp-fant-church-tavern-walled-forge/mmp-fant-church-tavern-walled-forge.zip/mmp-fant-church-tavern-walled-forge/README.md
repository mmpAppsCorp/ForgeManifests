# Fantasy Church Tavern | Map Pack (Walled)

Church Tavern | Map Pack presents a unique and atmospheric location where faith and fellowship collide—perfect for intrigue-heavy encounters, secret meetings, or morally gray adventures.

This pack features a two-level tavern built within (or repurposing) a church structure, blending sacred architecture with the warmth and wear of a public house. High ceilings, stone walls, former chapels turned common rooms, and upper-level spaces create a setting rich with character and narrative tension.

Whether used as a quiet refuge, a controversial community hub, or a front hiding darker secrets beneath holy symbols, Church Tavern | Map Pack offers a memorable and flexible location for fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Church Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
