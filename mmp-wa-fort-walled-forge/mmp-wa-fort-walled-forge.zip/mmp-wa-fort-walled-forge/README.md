# Western Adventures - Fort | Map Pack (Walled)

Western Adventures | Fort delivers a classic wooden frontier stronghold ideal for military standoffs, sieges, rescues, and last-stand scenarios in the Old West.

This pack features a full wooden frontier fort presented as four distinct quadrants, allowing you to stage focused encounters or combine sections into a complete defensive installation. Palisade walls, watch positions, interior yards, and support structures provide clear sightlines and tactical choke points for combat-driven scenes.

Whether used as an army outpost, a besieged frontier defense, a bandit stronghold, or a remote military installation on the edge of civilization, Western Adventures | Fort offers a versatile and atmospheric setting for Western campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fort - four quadrants of a wooden frontier fort

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
