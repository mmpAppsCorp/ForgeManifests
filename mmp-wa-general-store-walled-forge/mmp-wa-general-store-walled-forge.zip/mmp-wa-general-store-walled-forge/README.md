# Western Adventures - General Stores | Map Pack (Walled)

Western Adventures | General Stores | Map Pack delivers an essential frontier business at the heart of any Wild West town, perfect for everyday commerce, tense encounters, robberies, and community-driven scenes.

This pack includes both a Large General Store and a Small General Store, each provided in summer and winter settings, allowing you to reflect seasonal changes, harsh weather, or shifting story tone. Interiors feature retail floors, counters, storage areas, and back rooms suited for negotiations, supply shortages, or sudden violence.

Whether serving as a lifeline for settlers, a target for bandits, or a hub of local gossip, Western Adventures | General Stores | Map Pack provides a versatile and atmospheric setting for classic frontier campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large General Store / Small General Store - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
