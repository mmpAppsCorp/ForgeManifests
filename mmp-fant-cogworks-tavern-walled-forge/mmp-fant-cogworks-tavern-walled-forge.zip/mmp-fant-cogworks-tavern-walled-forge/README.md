# Cogworks Taverns | Map Pack (Walled)

Cogworks Tavern | Map Pack delivers a bustling, gear-filled gathering place designed specifically for gnome tinkerers, inventors, and eccentric minds where ale flows as freely as inspiration.

This pack features the Cogworks Tavern, a multi-level establishment packed with whirring contraptions, workshop corners, and communal spaces where experiments, negotiations, and accidents are equally likely. The ground floor serves as the lively public tavern, the upper floor houses private tables and tinkering nooks, and the council floor provides a more formal space for guild meetings, secret plots, or high-level engineering debates.

Whether used as a social hub for clever gnomes, a neutral meeting ground for rival inventors, or the starting point for mechanical mishaps and daring schemes, Cogworks Tavern | Map Pack offers a distinctive and character-rich location for fantasy campaigns that lean into ingenuity and controlled chaos.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Cogworks Taverns - ground, upper, council floors

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
