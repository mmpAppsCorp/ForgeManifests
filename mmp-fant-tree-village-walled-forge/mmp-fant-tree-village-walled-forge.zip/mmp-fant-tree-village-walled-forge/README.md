# Elarwood - Elf Tree Village | Map Pack (Walled)

Elarwood – Elf Tree Village | Map Pack presents a living woodland settlement built high among ancient trees, perfect for diplomatic encounters, secret councils, ritual gatherings, or moments of quiet beauty in a fantasy campaign.

This pack centers on Elarwood, an elevated elven village where daily life unfolds across interconnected tree structures. Locations include a Meeting Tree for councils and ceremonies, Cooking, Crafting, Eating, and Sleeping Trees that showcase communal elven culture, and an Entrance Tree featuring both ground-level access and elevated village connections—ideal for guarded approaches or dramatic arrivals.

Designed to feel organic and harmonious with nature, Elarwood works equally well as a peaceful sanctuary, a hidden stronghold, or a location threatened by outside forces. Whether your party arrives as honored guests, uneasy allies, or intruders in the canopy, Elarwood – Elf Tree Village | Map Pack provides a distinctive and atmospheric setting for forest-based adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Elarwood - Elf Tree Village
  - Meeting Tree
  - Cooking Tree
  - Crafting Tree
  - Eating Tree
  - Sleeping Tree
  - Entrance Tree - ground & tree levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
