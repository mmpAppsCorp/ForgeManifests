# Modern Hostel | Map Pack (Walled)

Modern Hostel | Map Pack provides a compact, high-traffic lodging environment ideal for modern campaigns focused on travel, investigation, social encounters, or urban survival.

This pack features a two-floor hostel layout designed around shared living: communal areas for interaction, practical sleeping arrangements, and the kind of tight quarters where secrets travel fast and tensions escalate quickly. It works equally well as a budget stopover, a transient safehouse, or a place where unrelated story threads collide.

Whether your scenario involves backpackers, fugitives, undercover agents, or everyday civilians caught in the wrong place at the wrong time, Modern Hostel | Map Pack offers a grounded, flexible setting built for modern storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hostel - two floors

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
