# Gun Shop | Map Pack (Walled)

Gun Shop | Map Pack delivers a high-security modern retail location perfect for tactical encounters, criminal investigations, arms deals, or law-enforcement operations.

This pack includes a detailed Gun Shop interior, featuring display cases, counters, storage areas, and security features, as well as an attached Shooting Range—ideal for training scenes, tense negotiations, or combat encounters that escalate fast.

Whether used as a legitimate business, a front for illegal activity, or the site of a dramatic raid, Gun Shop | Map Pack provides a versatile and immersive setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Gun Shop - store & shooting range

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
