# Fantasy Market Tavern | Map Pack (Walled)

Market Tavern | Map Pack centers on a bustling tavern set at the heart of a busy trade district, where merchants, travelers, laborers, and opportunists all cross paths.

This pack features a four-level Market Tavern designed to support a wide range of scenes—from loud ground-floor drinking halls and merchant back rooms to upper-level lodging, private meeting spaces, and hidden corners perfect for deals that shouldn’t be overheard.

Whether used as a social hub, a neutral meeting place for rival factions, or the starting point for rumors and intrigue, Market Tavern | Map Pack provides a flexible, lived-in environment ideal for urban adventures and commerce-driven stories.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Market Tavern - four levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
