# Modern Prison | Map Pack (Walled)

Modern Prison | Map Pack provides a secure, contemporary correctional facility designed for tense investigations, high-risk breakouts, prisoner transfers, riots, or institutional power struggles.

This pack features a fully realized prison complex, including multi-level Cell Blocks, controlled Entrances, functional Work Blocks, and an exposed Prison Yard—each offering clear sightlines, choke points, and layered security ideal for tactical encounters and narrative drama.

Whether your scenario involves an inmate uprising, an undercover operation, a daring escape, or the daily grind of institutional control, Modern Prison | Map Pack delivers a grounded, flexible environment ready for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Prison
  - Cell Block - ground, upper
  - Entrance
  - Work Block - ground, upper
  - Prison Yard

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
