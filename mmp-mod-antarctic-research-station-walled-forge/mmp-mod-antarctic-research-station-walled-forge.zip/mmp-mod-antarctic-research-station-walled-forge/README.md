# Antarctic Research Station | Map Pack (Walled)

Antarctic Research Station | Map Pack delivers a remote, high-tension scientific facility set at the edge of the world—perfect for survival horror, isolation-driven mysteries, covert operations, or science-gone-wrong scenarios.

This pack features a fully realized Antarctic Research Station designed to support long-term habitation and research in extreme conditions. The layout provides a believable mix of laboratories, living spaces, and operational areas, making it ideal for investigations, emergencies, or escalating threats where help is days—or weeks—away.

Whether your story involves classified experiments, first contact, environmental disasters, or something stalking the ice, Antarctic Research Station | Map Pack offers a stark, atmospheric setting built to amplify tension and narrative stakes.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Antarctic Research Station

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
