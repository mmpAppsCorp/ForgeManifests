# Western Adventures - Stables | Map Pack (Walled)

Western Adventures | Stables delivers authentic frontier-era horse facilities essential to life in the Old West, perfect for travel scenes, livestock disputes, late-night ambushes, or quiet moments of preparation before the next journey.

This pack includes both Large and Small Stables, each provided in summer and winter settings, featuring stalls, tack areas, feed storage, and working spaces that reflect the practical realities of frontier towns and homesteads.

Whether used as a stopover for weary travelers, the site of a theft or showdown, or a background location that grounds your town in daily life, Western Adventures | Stables provides a flexible and atmospheric setting for any western campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Stable / Small Stable - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
