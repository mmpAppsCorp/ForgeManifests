# Corporate Research Lab | Map Pack (Walled)

Corporate Research Lab | Map Pack delivers a modern, high-security scientific facility ideal for corporate espionage, experimental breakthroughs, containment failures, or covert operations.

This pack features a fully realized five-floor Corporate Research Lab, with layered layouts designed to support a wide range of scenarios—from sterile laboratories and secured offices to restricted research zones and critical infrastructure areas. The vertical design makes it perfect for tense infiltrations, emergency lockdowns, or multi-stage encounters that unfold floor by floor.

Whether your campaign centers on cutting-edge technology, unethical experiments, rival megacorporations, or disaster containment, Corporate Research Lab | Map Pack provides a flexible and immersive environment for modern and near-future adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Corporate Research Lab - five floors

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
