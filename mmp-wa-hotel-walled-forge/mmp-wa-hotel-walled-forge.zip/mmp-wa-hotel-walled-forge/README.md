# Western Adventures - Hotels | Map Pack (Walled)

Western Adventures | Hotels delivers classic frontier lodging perfect for Western towns, rail stops, boom settlements, and dusty crossroads where travelers, drifters, and trouble inevitably collide.

This pack includes both a Corner Hotel and a Standard Hotel, each presented in summer and winter settings, capturing the contrast between bustling high seasons and harsh frontier cold. Interiors provide guest rooms, common areas, and service spaces ideal for investigations, ambushes, secret meetings, or tense overnight stays.

Whether serving as respectable accommodations, a temporary hideout, or the scene of a late-night confrontation, Western Adventures | Hotels offers versatile, atmospheric locations ready for classic Western storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Corner Hotel / Standard Hotel - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
