# Viking Village - Burial Barrow | Map Pack (Walled)

Viking Village – Burial Barrow | Map Pack delivers a somber and atmospheric sacred site steeped in Norse tradition, ideal for funerary rites, ancestral mysteries, tomb raids, or encounters with the restless dead.

This pack includes a detailed Burial Barrow, presented with both interior and exterior maps, allowing you to stage scenes ranging from ceremonial farewells to tense explorations beneath ancient earth and stone. The exterior evokes a windswept mound shaped by generations, while the interior offers a confined, evocative space perfect for secrets, treasures, or supernatural threats.

All land maps are provided in summer and winter environments, making the barrow equally suitable for harsh northern winters or quieter seasons of remembrance and pilgrimage.

Whether used as a place of honor, a forgotten tomb, or the entrance to darker legends, Viking Village – Burial Barrow | Map Pack adds weight, history, and atmosphere to any Viking-era campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Burial Barrow - interior, exterior

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
