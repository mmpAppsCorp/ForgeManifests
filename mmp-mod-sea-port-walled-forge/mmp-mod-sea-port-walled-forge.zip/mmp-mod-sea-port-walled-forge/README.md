# Sea Port & Container Ship | Map Pack (Walled)

Sea Port & Container Ship | Map Pack delivers a large-scale industrial maritime setting ideal for smuggling operations, covert extractions, labor disputes, sabotage missions, or high-risk tactical encounters.

This pack includes a detailed Sea Port, presented both empty and active with a docked ship, with aft, mid, and fore configurations that support ship boarding, cargo transfers, inspections, and waterfront confrontations. The layout is designed to handle everything from quiet nighttime infiltrations to chaotic, multi-faction engagements.

Also included is a fully realized Container Ship, mapped across below-deck cargo areas, open deck sections (aft, mid, fore), the bridge deck, and upper deck—perfect for shipboard combat, hostage situations, hidden cargo discoveries, or long-haul maritime storylines.

Whether your scenario centers on international crime, military interdiction, corporate espionage, or desperate escapes across open water, Sea Port & Container Ship | Map Pack provides a versatile and immersive maritime environment for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Sea Port - no ship, ship (aft, mid, fore)
- Container Ship - below deck & deck (aft, mid, fore), bridge deck, upper deck

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
