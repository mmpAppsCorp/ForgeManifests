# Viking Village - Animal Pens | Map Pack (Walled)

Viking Village – Animal Pens | Map Pack provides a rugged agricultural space at the heart of Norse village life, perfect for scenes involving livestock, trade, survival, or sudden danger.

This pack features a two-level Animal Pens area, including fenced enclosures, storage spaces, and working platforms that reflect the daily realities of animal husbandry in a Viking settlement. The layout supports everything from routine village activity to raids, escapes, and desperate last stands among panicked livestock.

All land maps are provided in both summer and winter environments, allowing the pens to shift from muddy, hard-worked ground to snow-choked enclosures where visibility is low and conditions are harsh. Viking Village – Animal Pens | Map Pack is an essential setting for grounded, lived-in encounters that make your Norse world feel authentic and alive.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Animal Pens - two levels

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
