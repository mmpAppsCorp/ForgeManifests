# Vegas Casino | Map Pack (Walled)

Vegas Casino | Map Pack delivers a sprawling, high-energy casino environment designed for big stakes, bigger crowds, and even bigger trouble—perfect for heists, investigations, organized crime, celebrity drama, or chaotic action scenes.

Built as four massive interconnected quadrants, this casino complex features a grand Lobby for first impressions and confrontations, expansive Slots and Table Games floors packed with opportunity and danger, and a lavish Show Lounge ideal for performances, VIP encounters, or distractions while plans unfold elsewhere.

Whether your story centers on a daring robbery, a covert meeting amid flashing lights, or a situation spiraling out of control under neon glow, Vegas Casino | Map Pack provides a bold, cinematic setting ready for high-risk, high-reward modern campaigns.

Whether your adventure involves undercover stings, heist planning, gang conflicts, missing-person investigations, or neon-soaked nightlife vignettes, Modern Adult Entertainment | Map Pack gives you immersive modern environments ready for any storyline.

---

## Included Maps

This pack contains the following locations:

- Vegas Casino - lobby, slots, table games, show lounge

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
