# Redrum Strip Club | Map Pack (Walled)

Redrum Strip Club | Map Pack delivers a dark, unsettling adult entertainment venue twisted into a full-spectrum horror location, perfect for supernatural investigations, cult activity, psychological terror, or violent confrontations in modern horror campaigns.

This pack features a detailed Strip Club interior and exterior, with multiple themed variations that transform familiar spaces into nightmarish scenes. Lap Dance Rooms, the main Stage, Offices, Kitchen, Bathroom, and Dressing Room are each presented in disturbing states—ranging from subtle wrongness to outright brutality—supporting scenarios involving possession, ritual murder, summoning events, or reality fractures.

Whether the location serves as a corrupted business hiding unspeakable secrets, a ritual site masquerading as nightlife, or the setting for a sudden descent into violence and terror, Redrum Strip Club | Map Pack provides an atmospheric and flexible environment designed to escalate tension and horror fast.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Strip Club
  - Interior
  - Exterior
  - Lap Dance Rooms - normal, creepy kids, frozen, kinky, lightning, murder, portal, summoning, torture
  - Stage - normal, execution, murder, red, rift, torture
  - Office - normal, headshot, portal, rift
  - Kitchen - normal, murder
  - Bathroom - normal, murder
  - Dressing Room - normal, blood bath, headshot

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
