# Secure Facility Construction | Map Pack (Walled)

Secure Facility Construction | Map Pack delivers a high-security worksite designed for modern thrillers, espionage campaigns, military operations, or near-future scenarios where something sensitive is being built—or breached.

This pack features a secure facility mid-construction, presented in two distinct versions, showcasing reinforced structures, restricted zones, and partially completed interiors. These maps are ideal for infiltration missions, sabotage attempts, covert surveillance, or tense standoffs before a facility becomes fully operational.

Whether your story involves stopping a secret project, defending a classified build site, or uncovering what’s being constructed behind locked fences and armed guards, Secure Facility Construction | Map Pack provides a flexible and atmospheric setting for high-stakes encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Secure Facility Construction - two versions

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
