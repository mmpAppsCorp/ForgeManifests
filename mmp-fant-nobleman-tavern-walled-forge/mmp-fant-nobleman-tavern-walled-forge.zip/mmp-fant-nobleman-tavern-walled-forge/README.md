# Fantasy Nobleman Tavern | Map Pack (Walled)

Nobleman Tavern | Map Pack presents an upscale social venue where wealth, influence, and quiet intrigue shape every conversation.

This pack features a refined two-level tavern designed for elite patrons, with elegant furnishings, private spaces, and an atmosphere suited to political maneuvering, discreet meetings, or high-stakes negotiations. It’s a place where deals are struck over fine drink rather than spilled ale.

Whether serving as a neutral ground for rival factions, a front for subtle conspiracies, or a rare haven of luxury in an otherwise rough city, Nobleman Tavern | Map Pack provides a polished setting for more sophisticated fantasy encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Nobleman Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
