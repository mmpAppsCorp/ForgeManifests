# Vet Clinic | Map Pack (Walled)

Vet Clinic | Map Pack delivers a fully realized modern veterinary facility ideal for investigative scenes, emergency care scenarios, slice-of-life moments, or unexpected encounters in contemporary campaigns.

This pack features a detailed Vet Clinic layout designed to support both routine operations and high-stress situations, making it suitable for everything from animal rescues and medical emergencies to tense confrontations or covert activity after hours.

Whether used as a place of healing, a community hub, or the backdrop for something far more dangerous, Vet Clinic | Map Pack provides a grounded, versatile setting that fits seamlessly into modern adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Vet Clinic

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
