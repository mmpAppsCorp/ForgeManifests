# Viking Village - Bathhouse | Map Pack (Walled)

Viking Village – Bathhouse | Map Pack brings a vital piece of Norse daily life to your tabletop, blending ritual, social gathering, and quiet intrigue in a single grounded location.

This pack features a detailed Viking Bathhouse designed for roleplay-heavy scenes, secret meetings, cultural rituals, or moments of vulnerability where weapons are set aside and tensions simmer beneath the steam. Whether used as a communal gathering place, a site of healing, or the backdrop for whispered conspiracies, the bathhouse offers rich narrative potential.

All land maps are provided in summer and winter environments, making this location equally suited to harsh northern winters or the brief warmth of the thawing season.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bathhouse

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
