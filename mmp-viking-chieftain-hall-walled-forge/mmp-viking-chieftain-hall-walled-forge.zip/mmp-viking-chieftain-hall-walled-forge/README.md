# Viking Village - Chieftain Hall | Map Pack (Walled)

Viking Village – Chieftain Hall | Map Pack centers on the political and social heart of a Norse settlement, where leadership is asserted, disputes are settled, and great feasts are held beneath heavy timber beams.

This pack includes a detailed Chieftain Hall, presented as both a formal meeting hall and a lively feast hall, allowing you to shift seamlessly between tense negotiations, council gatherings, celebrations, or betrayals carried out over mead and firelight.

Whether used for oaths, judgments, alliances, or legendary revels, Viking Village – Chieftain Hall | Map Pack provides an atmospheric and authentic setting for intrigue, authority, and drama at the center of Viking life.

All land maps are provided in both summer and winter environments, making the hall equally suited for seasonal campaigns and harsh northern climates.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Chieftain Hall - meeting hall, feast hall

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
