# Fantasy Castle Inn | Map Pack (Walled)

Fantasy Castle Inn | Map Pack delivers a fortified roadside stronghold turned welcoming inn, perfect for travel stops, political intrigue, secret meetings, or sieges that turn violent.

This pack features a stone Castle Inn with a public ground-floor tavern, an upper floor housing staff quarters and the owner’s suite, and a detailed basement containing common rooms, kitchen, storage, privy, and a hidden secret tunnel, with versions both with and without a teleportation circle. Exterior grounds show a road and river passing the inn, ideal for ambushes, caravans, or arriving guests.

All maps are provided in arctic, desert, and forest environments, allowing the inn to serve as a frontier bastion, mountain refuge, or wilderness waystation across a wide range of fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy Castle Inn
  - Ground Floor - pub
  - Upper Floor - staff quarters & owner's suite
  - Basement - common room, kitchen, storage, privy, secret tunnel, with and without teleportation circle
  - Grounds - road and river passing by inn

All are provided in arctic, desert, and forest environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
