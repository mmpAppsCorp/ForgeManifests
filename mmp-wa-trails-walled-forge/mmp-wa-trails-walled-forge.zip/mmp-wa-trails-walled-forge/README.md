# Western Adventures - Trails | Map Pack (Walled)

Western Adventures – Trails | Map Pack delivers rugged wilderness routes perfect for ambushes, pursuits, secret meetings, and long journeys across the frontier.

This pack features Trails in the Wild West, presented in both summer and winter settings, capturing everything from dusty wagon paths to snow-covered tracks cutting through open country. These maps are ideal for travel encounters, scouting missions, bandit attacks, or quiet moments between towns.

Whether your party is tracking outlaws, escorting a wagon train, or riding hard through hostile territory, Western Adventures – Trails | Map Pack provides atmospheric outdoor routes that bring the dangers and isolation of the frontier to life.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Trails in the Wild West - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
