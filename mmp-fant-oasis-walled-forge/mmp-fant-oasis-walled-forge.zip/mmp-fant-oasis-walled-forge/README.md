# Dunewater - Nomad Oasis Village | Map Pack (Walled)

Dunewater – Nomad Oasis Village | Map Pack brings a vital desert crossroads to life, perfect for survival-focused adventures, trade encounters, political intrigue, or sudden conflict in harsh environments.

This pack centers on a compact nomadic oasis settlement, featuring the main village layout alongside dedicated Sleeping Tents and Storage Tents. The maps reflect a functional, lived-in community built around water, shelter, and trade, making it ideal for negotiations, ambushes, secret meetings, or desperate resupply stops.

Whether Dunewater serves as a fragile refuge, a neutral meeting ground between rival factions, or a target worth fighting over, this map pack provides a grounded and atmospheric setting for desert-based campaigns and wilderness travel.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dunewater - Nomad Oasis Village
  - Village
  - Sleeping Tent
  - Storage Tent

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
