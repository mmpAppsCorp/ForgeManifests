# Fraternity & Sorority | Map Pack (Walled)

Fraternity & Sorority | Map Pack delivers a collection of modern campus social spaces ideal for college-set campaigns, investigations, rivalries, secret societies, or chaotic party nights that spiral out of control.

This pack features multiple fraternity and sorority houses, each mapped across three floors and provided in both furnished and unfurnished versions to support everything from normal student life to crime scenes, hazing rituals, or covert operations. The Party Frat House emphasizes excess and disorder, while the Classy Frat House presents a polished academic façade—complete with a hidden initiation room for darker secrets. The Sorority House offers a refined residential setting perfect for social drama, infiltration, or high-stakes confrontations.

Whether your story centers on campus intrigue, undercover work, cult-like traditions, or a party that goes very wrong, Fraternity & Sorority | Map Pack provides flexible, story-rich locations ready for modern adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Party Frat House - three floors of debauchery, furnished & unfurnished
- Classy Frat House - three floors of academic excellence (and a hidden initiation room), furnished & unfurnished
- Sorority House - three floors of unobtainable beauty, furnished & unfurnished

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
