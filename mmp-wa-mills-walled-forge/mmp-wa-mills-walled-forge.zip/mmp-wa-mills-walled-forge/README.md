# Western Adventures - Mills | Map Pack (Walled)

Western Adventures - Mills | Map Pack delivers classic frontier industry essential to life on the edge of civilization, perfect for Western campaigns, frontier towns, outlaw ambushes, or hard-won economic survival.

This pack includes a Water Mill and a Windmill, each designed as functional working structures rather than simple scenery. These locations work equally well as peaceful rural backdrops, strategic choke points, or tense encounter sites where isolation and machinery add danger and atmosphere.

Whether serving as a vital town resource, a meeting place far from the law, or a landmark worth defending—or sabotaging—Western Adventures - Mills | Map Pack provides grounded, versatile environments that bring authenticity and story hooks to any Western setting.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Water Mill
- Windmill

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
