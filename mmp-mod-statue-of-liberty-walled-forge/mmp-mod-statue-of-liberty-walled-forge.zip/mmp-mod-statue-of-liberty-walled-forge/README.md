# Statue of Liberty | Map Pack (Walled)*

**Statue of Liberty | Map Pack** provides a detailed, explorable recreation of one of the world’s most iconic landmarks, designed for modern adventures, investigations, thrillers, conspiracies, and high-stakes action scenarios.

Explore Liberty Island and move deep inside the monument itself, from the massive pedestal levels to the narrow internal passages winding upward through the statue. The pack includes every major structural layer, allowing scenes to unfold across public spaces, restricted areas, and vertigo-inducing heights.

Navigate the Star Pedestal across three floors, then continue upward through the Square Pedestal, mapped across six levels that showcase the monument’s scale and interior complexity. Ascend through internal stairways to reach Shoulder Level, the Crown Deck, and finally the Torch Deck, perfect for tense confrontations, rescues, or dramatic reveals overlooking the harbor.

Each map is built with gameplay flexibility in mind, supporting infiltration, defense, evacuations, and cinematic encounters inside and around the statue.

GM Notes are provided as overlay tiles, allowing you to reveal or hide information as needed without altering the base maps.

Whether your story involves espionage, supernatural secrets, or modern action set pieces, **Statue of Liberty | Map Pack** delivers an iconic location ready for unforgettable encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

**Statue of Liberty**

- Liberty Island
- Star Pedestal - 1st Floor
- Star Pedestal - 2nd Floor
- Star Pedestal - 3rd Floor
- Square Pedestal - 1st and 2nd Floor
- Square Pedestal - 3rd Floor
- Square Pedestal - 4th Floor
- Square Pedestal - 5th Floor
- Square Pedestal - 6th Floor
- Statue Internal
- Statue Internal - Shoulder Level
- Statue Crown Deck
- Statue Torch Deck

GM Notes are overlayed as tiles.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
