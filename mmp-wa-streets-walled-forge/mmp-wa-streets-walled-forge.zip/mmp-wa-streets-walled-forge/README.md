# Western Adventures - Streets | Map Pack (Walled)

Western Adventures – Streets | Map Pack delivers classic frontier streets designed for duels at high noon, tense standoffs, traveling caravans, and everyday life in a developing Western town.

This pack features typical frontier town streets presented in both summer and winter settings, capturing dusty main roads, wooden boardwalks, snow-covered thoroughfares, and the open spaces where lawmen, outlaws, merchants, and townsfolk inevitably cross paths.

Whether used for shootouts, pursuits, public hangings, parades, or quiet moments before trouble arrives, Western Adventures – Streets | Map Pack provides a flexible and atmospheric backdrop for any Wild West campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Typical Frontier Town Streets - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
