# Chapel & Cemetery | Map Pack (Walled)

Chapel & Cemetery | Map Pack delivers a somber and atmospheric sacred site ideal for mystery, horror, investigation, dark fantasy, or supernatural encounters.

This pack features a multi-level Chapel complex presented across grass, dirt, and snow environments, allowing the location to fit seamlessly into a wide range of climates and settings. The structure includes multiple above-ground levels along with four distinct basement variants, giving you flexibility to portray anything from quiet sanctuaries to hidden crypts or corrupted holy ground.

Surrounding the chapel is a fully realized Graveyard, also provided in grass, dirt, and snow versions—perfect for night vigils, grave robberies, undead risings, or tense confrontations among the tombstones. Beneath it all lie Catacombs, offering winding underground passages ideal for secret rituals, forgotten burials, or horrifying discoveries.

Whether used as a place of worship, a forgotten burial site, or the center of an unholy mystery, Chapel & Cemetery | Map Pack provides a richly layered location ready to support grim stories and eerie encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Chapel & Cemetery
  - Three levels in grass, dirt, snow environments
  - Four versions of basement level
  - Graveyard in grass, dirt, snow environments
  - Catacombs

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
