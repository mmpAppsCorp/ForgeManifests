# Seedy Strip Club | Map Pack (Walled)

Seedy Strip Club | Map Pack delivers a gritty, low-rent nightlife location ideal for crime stories, undercover operations, corruption investigations, or encounters that spiral out of control.

This pack features a rundown strip club interior filled with worn furnishings, shadowy corners, backroom vibes, and questionable security, paired with an exterior map perfect for stakeouts, arrivals, or sudden escapes. The space works equally well as a front for illegal activity, a meeting place for unsavory characters, or the backdrop for a tense confrontation.

Whether your scene involves organized crime, desperate negotiations, or violence waiting to happen, Seedy Strip Club | Map Pack provides an atmospheric setting that emphasizes danger, decay, and moral ambiguity in modern campaigns.

Whether your adventure involves undercover stings, heist planning, gang conflicts, missing-person investigations, or neon-soaked nightlife vignettes, Modern Adult Entertainment | Map Pack gives you immersive modern environments ready for any storyline.

---

## Included Maps

This pack contains the following locations:

- Seedy Strip Club - club, exterior

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
