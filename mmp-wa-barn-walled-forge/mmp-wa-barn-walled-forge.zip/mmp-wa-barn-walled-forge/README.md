# Western Adventures - Barns | Map Pack (Walled)

Western Adventures | Barns provides classic frontier farm structures ideal for rural encounters, investigations, ambushes, or dramatic showdowns on the edge of town.

This pack includes both Large Barn and Small Barn layouts, each presented in summer and winter settings, allowing you to reflect seasonal changes or shifting story conditions. Spacious interiors, loft areas, and exterior approaches make these barns perfect for hiding contraband, staging gunfights, sheltering livestock, or uncovering secrets in the countryside.

Whether used as working farm buildings, abandoned hideouts, or improvised battlegrounds, Western Adventures | Barns delivers flexible, authentic locations ready for any Wild West campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Barn / Small Barn - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
