# Backwater Town - Houses | Map Pack (Walled)

Backwater Town – Houses | Map Pack delivers a collection of rough, lived-in dwellings perfect for frontier settlements, outer-rim towns, or lawless desert communities where survival comes before comfort.

This pack includes a Flophouse, ideal for drifters, criminals, and desperate locals; a Hermit House, isolated and sparse, perfect for recluses or secretive NPCs; and a Typical House spanning two levels, suitable for everyday residents caught between hardship and hope.

All locations are provided in arctic, desert, and grassland environments, allowing the same structures to be reused across vastly different regions and climates. Each map is included in both furnished and unfurnished versions, giving you full control over storytelling, occupation, and encounter design.

Whether these homes serve as safe havens, places of intrigue, or targets in a larger conflict, Backwater Town – Houses | Map Pack provides flexible, atmospheric interiors ready for gritty adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Flophouse
- Hermit House
- Typical House - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
