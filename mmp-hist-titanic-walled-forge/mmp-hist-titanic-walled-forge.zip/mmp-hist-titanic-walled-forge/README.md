# The Titanic | Map Pack (Walled)

The Titanic | Map Pack delivers an expansive and atmospheric recreation of one of the most iconic ships ever built, ideal for historical adventures, mystery, horror, disaster scenarios, or dramatic investigations at sea.

This pack provides a comprehensive set of detailed ship interiors and decks, spanning luxury first-class spaces, working crew areas, and crowded steerage sections. From the elegance of the Grand Staircase and First-Class Promenade to the grit of the Cargo and Utility Decks, every area supports exploration, intrigue, and rising tension.

Dynamic Water Overlay tiles are included, allowing you to stage flooding, structural collapse, and desperate escapes as events unfold—perfect for sinking-ship drama or alternate-history twists.

Whether your story focuses on high society, survival, sabotage, or tragedy, The Titanic | Map Pack offers a richly detailed setting ready for unforgettable moments on the open sea.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Titanic
  - Bridge
  - Boat Deck
  - Cargo Deck
  - First-Class Cabins
  - First-Class Dining
  - First-Class Promenade
  - Grand Staircase
  - Smoking Room
  - Forecastle Deck
  - Poop Deck
  - Steerage Cabins
  - Steerage Promenade
  - Steerage Dining
  - Utility Deck
  - Water Overlays - for sinking drama

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
