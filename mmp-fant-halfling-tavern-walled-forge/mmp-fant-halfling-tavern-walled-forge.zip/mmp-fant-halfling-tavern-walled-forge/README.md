# 13 Halfling Tavern | Map Pack (Walled)

Halfling Tavern | Map Pack delivers a warm, welcoming countryside tavern perfect for lighthearted roleplay, secret meetings, or deceptively cozy adventures that hide more than they reveal.

This pack features a fully realized Halfling Tavern spread across multiple levels, including a lively tavern floor, a bustling kitchen, and a basement ideal for storage, hidden dealings, or unexpected trouble. The layout emphasizes comfort, practicality, and the close-knit feel of a halfling-run establishment, with plenty of nooks for conversation and mischief alike.

Whether serving as a beloved local gathering spot, a roadside inn with a few secrets, or the calm before chaos, Halfling Tavern | Map Pack provides a charming and versatile setting for fantasy campaigns of any tone.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Halfling Tavern - tavern, kitchen, basement levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
