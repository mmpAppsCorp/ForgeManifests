# Forgeton - Dwarf Village| Map Pack (Walled)

Forgeton – Dwarf Village | Map Pack delivers a fully realized subterranean dwarven settlement designed for political intrigue, industrial conflict, religious tensions, or classic fantasy role-play centered on clan, craft, and stone.

This pack presents Forgeton as a structured dwarven city divided into distinct functional quarters. The Royal Quarter serves as the seat of authority and tradition, while the Market Quarter bustles with trade, negotiation, and guild activity. The Mine Quarter showcases the industrial heart of the settlement—perfect for labor disputes, sabotage, or monster incursions from below—while the Chapel Quarter provides a sacred space for dwarven rites, oaths, and ancient secrets carved into stone.

Whether used as a thriving stronghold, a city on the brink of collapse, or a fallen hold ripe for exploration, Forgeton – Dwarf Village | Map Pack offers a cohesive and immersive dwarven environment ready for deep narrative play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Forgeton - Dwarf Village
  - Royal Quarter
  - Market Quarter
  - Mine Quarter
  - Chapel Quarter

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
