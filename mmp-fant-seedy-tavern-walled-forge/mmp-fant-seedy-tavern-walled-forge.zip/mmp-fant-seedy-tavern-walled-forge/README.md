# Fantasy Seedy Tavern | Map Pack (Walled)

Scottish Tavern | Map Pack delivers a rugged, atmospheric drinking hall inspired by the stone-built inns and clan taverns of the Highlands, perfect for fantasy campaigns rooted in tradition, feuds, and hard-earned hospitality.

This pack features a two-level Scottish Tavern, with a sturdy ground floor for communal drinking, music, and heated arguments, and an upper level suited for private rooms, storage, or quiet conspiracies away from the hearth. Thick stone walls, heavy timbers, and a practical layout make it ideal for brawls, negotiations, or secret meetings.

Whether serving as a clan gathering place, a roadside refuge from harsh weather, or a neutral ground between rivals, Scottish Tavern | Map Pack provides a grounded, character-rich location for classic fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Seedy Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
