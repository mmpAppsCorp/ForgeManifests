# Summer Camp - Lodge | Map Pack (Walled)

Summer Camp – Lodge | Map Pack delivers a classic camp centerpiece ideal for social scenes, mysteries, emergencies, or late-night encounters in a rustic setting.

This pack includes a detailed Lodge mapped across the ground level, roof, and underneath, providing flexible spaces for gatherings, planning sessions, hidden discoveries, or tense confrontations. The multi-level layout supports both everyday camp activity and darker, story-driven moments.

Whether used as a welcoming communal hall, an abandoned retreat, or the heart of a suspenseful scenario, Summer Camp – Lodge | Map Pack offers a versatile and atmospheric location ready for a wide range of modern or horror-themed campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Lodge - ground, roof & underneath

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
