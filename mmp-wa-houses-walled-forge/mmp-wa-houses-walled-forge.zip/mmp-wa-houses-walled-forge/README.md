# Western Adventures - Houses | Map Pack (Walled)

Western Adventures | Houses delivers authentic frontier-era homes designed to bring everyday life in the Old West to your tabletop.

This map pack includes a range of residential buildings, from modest frontier dwellings to elegant homes of the town’s elite. Each house is carefully detailed to support domestic scenes, investigations, social encounters, or sudden violence when trouble comes knocking.

Both wealthy and humble homes are provided in summer and winter settings, allowing you to reflect seasonal hardship, isolation, or prosperity in your campaign.

Whether your story involves respected citizens, struggling settlers, or secrets hidden behind closed doors, Western Adventures | Houses provides grounded, versatile locations that make frontier towns feel lived-in and real.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Typical Wealthy House / Fancy Wealthy House - summer & winter settings
- Typical Small House / Typical Simple House - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
