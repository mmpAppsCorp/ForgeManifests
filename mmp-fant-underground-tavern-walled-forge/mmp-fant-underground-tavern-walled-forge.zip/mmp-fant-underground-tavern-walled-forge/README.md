# Underground Tavern | Map Pack (Walled)

Underground Tavern | Map Pack delivers a hidden, subterranean gathering place carved deep within stone—perfect for secret meetings, criminal dealings, monster negotiations, or weary adventurers seeking refuge far from the surface.

Set entirely below ground, this tavern blends rough-hewn caverns with functional drinking halls, shadowed corners, and natural choke points that make it ideal for tense roleplay, ambushes, or clandestine encounters. Its isolation and enclosed layout naturally heighten atmosphere, danger, and intrigue.

Whether used as a neutral meeting ground, a criminal hideout, a monster-run establishment, or a last safe stop before descending deeper into a dungeon, Underground Tavern | Map Pack provides a moody and versatile setting for fantasy campaigns that thrive in darkness.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Underground Tavern - deep inside a cave or dungeon

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
