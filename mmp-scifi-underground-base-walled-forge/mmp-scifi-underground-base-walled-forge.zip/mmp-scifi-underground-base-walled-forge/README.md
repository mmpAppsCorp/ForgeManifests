# Underground Hidden Base | Map Pack (Walled)

Underground Hidden Base | Map Pack delivers a fully realized secret installation designed for covert operations, rebel strongholds, clandestine research, or last-stand defenses hidden far from prying eyes.

This pack centers on a sprawling underground base carved into hostile terrain, with variants set in arctic, dirt, rocky, and swamp environments, allowing the same facility to serve wildly different worlds and climates. From fortified entrances to concealed exits, every area supports stealth, infiltration, and large-scale conflict.

Inside, the base features a complete operational layout including barracks, command and briefing spaces, engineering and medical facilities, kitchens and mess halls, storage areas, and security checkpoints. Multiple hallways—both clear and blocked—support dynamic encounters, ambushes, and emergency lockdown scenarios.

Air and vehicle operations are fully supported with large and small hangar bays, each provided with open and closed door variants, along with dedicated hangar control rooms. Defensive capabilities are represented by cannon emplacements and control stations, while animal pens, work areas, and service rooms add lived-in realism.

Whether used as a rebel headquarters, secret military outpost, hidden cult compound, or villainous lair, Underground Hidden Base | Map Pack provides a versatile, cinematic environment built for tense missions, daring assaults, and dramatic last stands.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Underground Hidden Base - in arctic, dirt, rocky, and swamp environments
  - Animal Pens
  - Barracks
  - Hallway (clear & blocked)
  - Briefing Room
  - Cannon Control
  - Cannon
  - Command Center
  - Engineering
  - Kitchen & Mess
  - Large Hanger Bay (open & closed door)
  - Large Hanger Bay Control (open & closed door)
  - Lavatory
  - Medical Center
  - Security
  - Small Hanger Bay (open & closed door)
  - Small Hanger Bay Control (open & closed door)
  - Store Room
  - Walk-out Exit

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
