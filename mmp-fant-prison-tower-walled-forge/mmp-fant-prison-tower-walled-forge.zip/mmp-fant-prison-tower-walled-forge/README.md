# Fantasy Prison Tower | Map Pack (Walled)

Fantasy Prison Tower | Map Pack delivers a towering vertical dungeon designed for captivity, interrogation, dark justice, and daring escapes in fantasy campaigns.

This pack features a massive eight-level prison tower, rising floor by floor from secure holding areas to heavily guarded upper levels. Each level is designed to support incarceration, punishment, secret dealings, and high-stakes breakouts, making it ideal for political intrigue, villain strongholds, or last-stand rescues.

Whether serving as a royal prison, mage containment facility, or tyrant’s instrument of fear, Fantasy Prison Tower | Map Pack provides a grim, imposing structure ready to anchor dramatic encounters and memorable story moments.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy Prison Tower - eight levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
