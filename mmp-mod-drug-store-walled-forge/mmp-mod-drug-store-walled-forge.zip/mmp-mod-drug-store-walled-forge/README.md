# Drug Store | Map Pack (Walled)

Drug Store | Map Pack delivers a familiar modern retail location ideal for investigations, robberies, undercover surveillance, or everyday urban encounters that take a sudden turn.

This pack includes a detailed Drug Store interior with aisles, counters, pharmacy areas, and back rooms, along with a rooftop map suitable for chases, stakeouts, or rooftop access during escalating situations.

Whether serving as an ordinary neighborhood business, a late-night crime scene, or a front for something more suspicious, Drug Store | Map Pack provides a flexible and believable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Drug Store - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
