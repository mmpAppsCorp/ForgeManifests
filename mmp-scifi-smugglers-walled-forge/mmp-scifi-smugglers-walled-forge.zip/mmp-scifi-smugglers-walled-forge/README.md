# Smuggler Freighters | Map Pack (Walled)

Smuggler Freighters | Map Pack delivers rugged, versatile spacecraft interiors perfect for illicit trade, covert transport, daring escapes, and life on the fringe of interstellar society.

This pack includes three distinct Smuggler Freighters, each mapped across the Upper Hull, Lower Hull, Main Deck, and Lower Deck, providing layered environments for crew quarters, cargo runs, secret compartments, and high-stakes confrontations.

To maximize flexibility, every freighter is provided in multiple environments—landed in arctic, desert, grass, metal, and pavement settings, as well as in flight through open space or atmosphere—allowing you to seamlessly move from planetary jobs to deep-space chases.

Whether serving as a player ship, a rival crew’s freighter, or a floating den of secrets and contraband, Smuggler Freighters | Map Pack offers a gritty, adaptable backdrop for space-faring adventures where profit always comes with risk.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Three Smuggler Freighters
  - Upper Hull
  - Lower Hull
  - Main Deck
  - Lower Deck

Provided in six environments
  - Landed Arctic
  - Landed Desert
  - Landed Grass
  - Landed Metal
  - Landed Pavement
  - Flying Space
  - Flying Sky

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
