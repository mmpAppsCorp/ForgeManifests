# Modern Factory | Map Pack (Walled)

Modern Factory | Map Pack delivers an industrial environment ideal for modern action, espionage, labor disputes, industrial accidents, or covert operations set amid heavy machinery and tight catwalks.

This pack features a detailed factory floor filled with production equipment, work zones, and moving parts, paired with an elevated mezzanine that overlooks the operation—perfect for surveillance, ambushes, or tense vertical encounters. An exterior factory map rounds out the location, supporting perimeter breaches, deliveries, protests, or emergency responses.

Whether the factory is a legitimate workplace, a front for illegal activity, or the site of a high-stakes confrontation, Modern Factory | Map Pack provides a flexible, gritty setting ready for modern campaigns.

---

## Included Maps

This pack contains the following locations:

- Factory - floor, mezzanine, exterior

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
