# Speakeasy | Map Pack (Walled)

Speakeasy | Map Pack delivers a richly detailed Prohibition-era location ideal for noir investigations, criminal dealings, secret meetings, or stylish underground escapades.

This pack features a hidden Basement Pub, complete with furnished and unfurnished versions for both lively nights and abandoned scenes, alongside a Ground Floor Hotel cleverly disguising a secret entrance through a bookstore—perfect for covert access and tense discoveries. An Upper Floor expands the setting with additional furnished and unfurnished spaces, while Rooftop maps provide opportunities for escapes, surveillance, or dramatic confrontations under the city lights.

Whether your story centers on bootleggers, private detectives, political conspiracies, or glamorous criminals, Speakeasy | Map Pack provides a versatile and atmospheric setting steeped in secrecy and intrigue.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Speakeasy
  - Hidden Basement Pub - furnished & unfurnished
  - Ground Floor Hotel with Bookstore Secret Entrance - furnished & unfurnished
  - Upper Floor - furnished & unfurnished
  - Rooftops

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
