# Massive Spherical Battle Station | Map Pack (Walled)

Massive Spherical Battle Station | Map Pack delivers an enormous spaceborne installation designed for epic confrontations, infiltration missions, desperate escapes, and galaxy-shaking power struggles.

This pack presents a fully realized spherical battle station interior, featuring command and control spaces such as the Bridge, Boardroom, Throne Room, and Omnilift Central, alongside extensive military and operational areas including Barracks, Detention Center, Medical, Armoury support spaces, and multiple Maintenance Sections.

Industrial and combat-focused zones include Fighter Launch bays (both full and empty), active and inactive Firing Chambers, Gun Towers, Escape Pods, Freight and Hangar facilities, and vast Corridors that support everything from stealth operations to large-scale firefights. Civil and administrative spaces like Auditoriums, Mess Halls, Officer’s Quarters, and the Quartermaster round out the station’s lived-in feel.

Whether serving as an ultimate enemy stronghold, a seat of tyrannical power, or the setting for a climactic final act, Massive Spherical Battle Station | Map Pack provides a monumental sci-fi environment built for high-stakes storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Massive Spherical Battle Station
  - Bridge
  - Boardroom
  - Barracks
  - Trash Compactor
  - Auditorium
  - Corridors
  - Detention Center
  - Escape Pods
  - Fighter Launch - full & empty
  - Firing Chamber - active & inactive
  - Gun Tower
  - Hanger Bay - docking bay, control, entrance
  - Three Maintenance Sections
  - Medical
  - Mess & Kitchen
  - Officer's Mess
  - Officer's Quarters
  - Omnilift Central
  - Quartermaster
  - Throne Room

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
