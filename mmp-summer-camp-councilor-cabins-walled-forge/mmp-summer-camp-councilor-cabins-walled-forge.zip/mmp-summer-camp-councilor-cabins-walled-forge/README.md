# Summer Camp - Counselor Cabins | Map Pack (Walled)

Counselor Cabins | Map Pack delivers a secluded residential setting ideal for leadership intrigue, late-night conversations, secrets overheard through thin walls, or moments of tension away from the campers.

This pack features detailed Counselor Cabins presented across the ground level, rooftop, and underneath spaces, allowing for both everyday camp life and hidden activity below the surface. These maps work equally well for peaceful downtime, investigations, or suspenseful encounters after lights-out.

Whether used as trusted living quarters, a place for whispered plans, or the backdrop for something going wrong at camp, Counselor Cabins | Map Pack provides a versatile and atmospheric setting for modern, horror, or adventure campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Counselor Cabins - ground, roof & underneath

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
