# Shopping Mall | Map Pack (Walled)

Shopping Mall | Map Pack delivers a sprawling, multi-level commercial environment designed for action-packed encounters, investigations, heists, or large-scale civilian scenarios.

This pack includes a welcoming main entrance, a busy escalator intersection connecting key areas, a food court filled with seating and vendor spaces, expansive store halls ideal for pursuits and ambushes, and behind-the-scenes utility halls that provide alternate routes for stealthy movement or tactical flanking.

From crowded daytime chaos to after-hours infiltration, Shopping Mall | Map Pack offers a versatile and immersive setting that supports everything from casual role-play to high-intensity modern adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Shopping Mall - entrance, escalator intersection, food court, store hall, utility hall

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
