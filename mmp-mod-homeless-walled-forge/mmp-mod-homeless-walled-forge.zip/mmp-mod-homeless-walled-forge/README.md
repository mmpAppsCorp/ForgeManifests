# Modern Homeless | Map Pack (Walled)

Modern Homeless | Map Pack delivers grounded, realistic environments suited for urban dramas, investigative campaigns, survival scenarios, and socially driven storytelling.

This pack includes a Homeless Encampment, capturing the improvised layouts, tents, belongings, and lived-in chaos of people surviving on the margins, as well as a Homeless Shelter, providing a structured contrast with communal sleeping areas, intake spaces, and support facilities.

Whether used as the backdrop for outreach efforts, tense confrontations, missing-person investigations, or stories that explore life on the edge of society, Modern Homeless | Map Pack offers respectful, immersive locations that add emotional weight and realism to modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Homeless Encampment
- Homeless Shelter

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
