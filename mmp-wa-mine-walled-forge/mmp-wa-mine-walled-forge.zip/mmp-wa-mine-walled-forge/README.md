# Western Adventures - Mine | Map Pack (Walled)

Mine & Gold Buyer’s Shack | Map Pack delivers a rugged frontier setting ideal for prospecting expeditions, labor disputes, criminal schemes, or high-stakes negotiations fueled by greed and desperation.

This pack features a detailed Mine, suitable for excavation scenes, dangerous collapses, secret tunnels, or violent confrontations deep underground, paired with a Gold Buyer’s Shack—a small but critical hub where fortunes are weighed, deals are struck, and betrayals are made.

Whether used as the backbone of a boomtown economy, the center of a mining dispute, or the stage for outlaw ambushes and double-crosses, Mine & Gold Buyer’s Shack | Map Pack provides an authentic and versatile environment for Western adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Mine
- Gold Buyer's Shack

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
