# Modern Truck Stop | Map Pack (Walled)

Modern Truck Stop | Map Pack delivers a versatile roadside location ideal for travel encounters, criminal activity, tense standoffs, or brief moments of rest between missions.

This pack features a detailed Truck Stop interior, including the convenience store layout, counters, aisles, and service areas, along with a fully mapped Roof—perfect for surveillance, ambushes, rooftop chases, or covert overwatch.

Whether it’s a neutral meeting place, a refueling stop gone wrong, or a hotspot for smugglers, drifters, and law enforcement, Modern Truck Stop | Map Pack provides a flexible and atmospheric setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Truck Stop - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
