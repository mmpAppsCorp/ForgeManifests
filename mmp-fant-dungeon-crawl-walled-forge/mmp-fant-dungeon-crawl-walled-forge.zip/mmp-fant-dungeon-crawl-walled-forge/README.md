# Dungeon Crawl  | Map Pack  (Walled)

Dungeon Crawl | Map Pack delivers a classic fantasy dungeon experience built for exploration, danger, and memorable encounters deep beneath the surface.

This pack provides a wide range of interconnected dungeon environments, from natural caverns and underground rivers to ancient crypts, forgotten temples, and lairs claimed by monsters and dark cults. Each area is designed to support tactical combat, tense exploration, and narrative discovery, whether the party is delving for treasure, hunting a specific threat, or uncovering long-buried secrets.

With dedicated lairs for dragons, giants, humanoid factions, mages, minotaurs, and spiders, Dungeon Crawl | Map Pack gives you flexible, reusable dungeon spaces that can anchor one-shot adventures or serve as the backbone of an extended underground campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Classic Dungeon
  - Cave
  - Chasm
  - Crypt
  - Cultist's Lair
  - Dragon's Lair
  - Entrance
  - Giant's Lair
  - Humanoid Species Lair
  - Mage Lair
  - Minotaur Lair
  - Underground River
  - Spider Lair
  - Temple

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
