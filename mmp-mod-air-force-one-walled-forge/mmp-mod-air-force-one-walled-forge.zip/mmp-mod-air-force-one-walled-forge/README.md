# Modern America | Map Pack (Walled)*

**Air Force One | Map Pack** delivers a detailed, cinematic take on one of the most iconic aircraft in the world, designed for modern political thrillers, espionage campaigns, crisis scenarios, and high-stakes diplomatic drama.

Explore the aircraft across three fully mapped decks—Main Deck, Cargo Deck, and Top Deck—each presented in both flying and landed configurations. This allows you to seamlessly transition between tense in-air negotiations, emergency situations at altitude, and secure ground operations during arrivals, departures, or evacuations.

Whether your story involves covert meetings at 30,000 feet, an onboard security incident, a dramatic emergency landing, or a race against time on the tarmac, **Air Force One | Map Pack** provides a flexible, realistic setting ready to support presidential intrigue and global consequences.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

**Air Force One** - Each deck is shown in both flying and landed configurations.

- Main Deck
- Cargo Deck
- Top Deck

GM Notes are overlayed as tiles.

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
