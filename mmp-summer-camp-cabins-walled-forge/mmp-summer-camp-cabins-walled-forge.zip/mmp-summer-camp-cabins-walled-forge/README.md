# Summer Camp Camper Cabins | Map Pack (Walled)

Camper Cabins | Map Pack delivers a classic camp lodging environment ideal for summer camp stories, wilderness adventures, mysteries, or horror scenarios where isolation and close quarters matter.

This pack includes detailed Camper Cabins mapped across the ground level, roof, and underneath, allowing you to stage scenes inside cramped sleeping quarters, on creaking rooftops, or beneath the cabins where secrets, supplies, or dangers may be hidden.

Whether used for wholesome camp activities, tense investigations, or something far darker after nightfall, Camper Cabins | Map Pack provides a flexible and atmospheric setting that fits perfectly into outdoor and survival-focused campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Cabins - ground, roof & underneath

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
