# Luxury Pods | Map Pack (Walled)

Luxury Pods | Map Pack delivers a collection of high-end modular environments designed for elite travel, secret meetings, decadent leisure, and zero-gravity chaos across a wide range of sci-fi settings.

This pack features a versatile system of Luxury Pods that can exist floating in open air, deep space, on the surface of the water, or fully submerged underwater. Each pod serves a distinct purpose, from refined living quarters and entertainment spaces to medical facilities, combat arenas, and operational hubs—allowing you to assemble anything from a drifting pleasure palace to a clandestine mobile base.

With pods dedicated to bridges, hangars, casinos, spas, nightclubs, dining areas, theaters, and more, this pack supports stories of political intrigue, criminal excess, VIP protection, espionage, or sudden violence in controlled, enclosed environments. A Blank Pod and Generic Sub-Level are included to let you customize layouts for your own unique scenarios.

Whether your campaign calls for luxury amid isolation, covert operations hidden behind opulence, or brutal confrontations in zero-G, Luxury Pods | Map Pack provides flexible, cinematic settings ready to drop into any sci-fi adventure.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Luxury Pods - floating in air, space, on water, and underwater
  - Blank Pod (for you to customize)
  - Bridge Pod
  - Casino Pod
  - Crew Quarters Pod
  - Deluxe Rooms Pod
  - Dining Pod
  - Fencing Pod
  - Hanger Pod - three levels
  - Kitchen Pod
  - Medical Pod
  - Mess Pod
  - Nightclub Pod
  - Pool Pod
  - Spa Pod
  - Generic Sub-Level
  - Theater Pod
  - Toilet Pod
  - Typical Room Pod
  - Zero-G Brawling Pod

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
