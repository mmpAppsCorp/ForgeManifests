# Western Adventures - Flophouse & Empty Buildings | Map Pack (Walled)

Western Adventures | Flophouse & Empty Buildings provides gritty, flexible locations ideal for stories on the rough edges of frontier life, where desperation, secrecy, and opportunity often intersect.

This pack includes a detailed Flophouse, capturing the harsh reality of cheap lodging for vagrants, drifters, fugitives, and those down on their luck—perfect for investigations, tense confrontations, or morally complex encounters. Narrow rooms, communal spaces, and worn interiors create a setting steeped in hardship and suspicion.

Also included are Empty Frontier Buildings, intentionally left unoccupied and customizable. These spaces can be transformed into hidden gang hideouts, temporary headquarters, abandoned businesses, or improvised safehouses, giving Game Masters maximum flexibility to tailor them to the needs of any scenario.

Whether your story focuses on survival, crime, or the unseen side of a frontier town, Western Adventures | Flophouse & Empty Buildings offers atmospheric locations ready to shape your narrative.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Flophouse - where vagrants and drifters stay
- Empty Buildings - for you to customize to your needs

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
