# The White House | Map Pack (Walled)*

**The White House | Map Pack** delivers a comprehensive, highly detailed recreation of one of the most iconic government complexes in the world, designed for modern political thrillers, espionage campaigns, investigative scenarios, and high-stakes action adventures.

This pack provides a full interior and exterior breakdown of the White House, with every major area mapped across multiple floors and functional zones. Each interior map is included in both furnished and unfurnished versions, allowing GMs to tailor scenes for official operations, emergencies, alternate histories, or fictional administrations.

Explore the full scope of the complex, including the West Wing, East Wing, and Residential levels, spanning from public-facing offices to restricted basements and sub-basements. Exterior areas such as the White House Grounds, South Lawn, Children’s Garden, and Swimming Pool provide space for ceremonies, infiltration attempts, public events, or covert extractions.

Security infrastructure is fully represented, with Road Checkpoints, Wall Checkpoints, and the Visitor’s Center mapped for crowd control, surveillance, and perimeter defense scenarios.

To support storytelling and scenario management, GM Notes are provided as overlay tiles, allowing sensitive information, triggers, or narrative cues to remain hidden from players until revealed.

Whether your game focuses on political intrigue, covert operations, disaster response, or alternate-reality conflicts, **The White House | Map Pack** offers a flexible and detailed setting ready to anchor modern and near-future adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

**White House** - each map is shown both furnished and unfurnished.

- West Wing Ground Floor
- West Wing Upper Floor
- West Wing Lower Floor
- East Wing Ground Floor
- East Wing Upper Floor
- East Wing Basement
- East Wing Sub-Basement
- Residence Ground Floor
- Residence 2nd Floor
- Residence 3rd Floor
- Residence 4th Floor
- Residence Basement
- Residence Sub-Basement
- White House Grounds
- South Lawn
- Children's Garden
- Road Checkpoint
- Swimming Pool
- Visitor's Center
- Wall Checkpoint

GM Notes are overlayed as tiles.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
