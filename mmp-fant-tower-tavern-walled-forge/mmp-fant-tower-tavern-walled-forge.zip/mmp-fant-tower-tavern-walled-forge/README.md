# Fantasy Tower Tavern | Map Pack (Walled)

Tower Tavern | Map Pack presents a distinctive vertical tavern built into a towering structure, ideal for fantasy campaigns that favor intrigue, social hierarchy, and layered encounters.

This pack features a six-level tavern, with each floor offering its own atmosphere—ranging from noisy public drinking halls to quieter upper levels suited for private meetings, clandestine dealings, or elite patrons. The vertical layout naturally supports ambushes, chases up stairwells, hidden rooms, and dramatic multi-level confrontations.

Whether the tower serves as a landmark inn for travelers, a neutral meeting ground for rival factions, or a hub of secrets stacked floor by floor, Tower Tavern | Map Pack provides a memorable and tactically rich setting for fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tower Tavern - six levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
