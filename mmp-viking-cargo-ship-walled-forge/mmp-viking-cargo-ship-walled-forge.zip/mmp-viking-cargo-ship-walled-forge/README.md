# Viking Village - Cargo Ship | Map Pack (Walled)

Viking Village – Cargo Ship | Map Pack brings the lifeblood of Norse trade, travel, and raiding to your table, centered on a rugged Viking cargo vessel built for long journeys across hostile seas.

This pack features a detailed Cargo Ship presented in both full and empty configurations, allowing you to stage tense negotiations, desperate resupply missions, hidden contraband discoveries, or brutal boarding actions. The ship is shown with oars up and oars out, supporting scenes of quiet harbor approaches or all-hands rowing under pressure.

To match the unforgiving northern world, the ship is provided in multiple water conditions: calm seas, rough waters, and ice-choked routes, making it equally suited for peaceful trade runs, storm-lashed voyages, or perilous journeys through frozen fjords.

Whether used for commerce, exploration, migration, or war, Viking Village – Cargo Ship | Map Pack delivers an authentic and flexible maritime setting for Viking-era adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Cargo Ship
  - Full & empty
  - Oars up, oars out
  - Calm, rough, iced waters

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
