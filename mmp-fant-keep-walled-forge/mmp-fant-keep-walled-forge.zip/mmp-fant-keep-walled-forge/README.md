# Fantasy Keep | Map Pack (Walled)

Fantasy Keep | Map Pack delivers a classic fortified stronghold designed for sieges, political intrigue, desperate defenses, or long-abandoned ruins reclaimed by new powers.

This pack features a fully realized Fantasy Keep spanning four detailed levels, allowing play to flow seamlessly from outer defenses to inner halls and command spaces. The keep is provided in both arctic and forest environments, making it equally suited for frozen borderlands, mountain passes, or temperate kingdoms.

Included tile overlays allow the drawbridge to be opened or closed, giving you direct control over access, defenses, and the tone of an encounter—whether the gates are raised against an attacking army or lowered to welcome allies under uneasy truce.

Whether used as a ruling lord’s seat, a besieged fortress, a bandit stronghold, or a forgotten relic of a fallen realm, Fantasy Keep | Map Pack provides a versatile and atmospheric centerpiece for fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy Keep
  - Four levels
  - Arctic & forest environments
  - Tile overlays to close drawbridge

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
