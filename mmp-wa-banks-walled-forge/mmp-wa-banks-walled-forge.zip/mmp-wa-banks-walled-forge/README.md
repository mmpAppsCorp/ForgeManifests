# Western Adventures - Banks | Map Pack (Walled)

**Western Adventures – Banks | Map Pack** brings financial intrigue and high-stakes drama to the heart of the frontier. Whether your story involves a bold daylight robbery, a tense standoff with the sheriff, secret dealings in a back office, or a desperate last stand behind a teller counter, these maps provide the perfect backdrop for classic Wild West encounters.

This pack includes both Large Bank and Small Bank layouts, each carefully designed to reflect the architecture and function of frontier financial institutions. Every bank is provided in summer and winter settings, allowing you to seamlessly shift the season, mood, and narrative tone of your campaign.

From dusty boomtowns to snowbound settlements, **Western Adventures – Banks | Map Pack** equips your table with versatile, atmospheric locations ideal for heists, investigations, shootouts, and moral dilemmas where money—and lives—are on the line.

---

## Included Maps

This pack contains the following locations:

- Large Bank / Small Bank - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
