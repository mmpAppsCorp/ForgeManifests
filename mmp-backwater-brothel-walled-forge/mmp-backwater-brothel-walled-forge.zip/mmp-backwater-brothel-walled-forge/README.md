# Backwater Town - Brothel | Map Pack (Walled)

manipulation, or morally complex encounters in frontier or sci-fi border settlements.

This pack features a fully detailed two-level brothel, designed with private rooms, shared spaces, and staff areas that support scenes ranging from quiet information gathering to sudden violence or dramatic revelations. The layout works equally well as a legitimate business, a criminal front, or a location hiding secrets far more dangerous than it appears.

All maps are provided in arctic, desert, and grassland environments, and each version is available furnished and unfurnished, giving GMs full control over tone, occupancy, and narrative use. Backwater Town – Brothel | Map Pack offers a flexible, story-driven setting for campaigns that thrive on secrets, leverage, and blurred lines.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Brothel - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
