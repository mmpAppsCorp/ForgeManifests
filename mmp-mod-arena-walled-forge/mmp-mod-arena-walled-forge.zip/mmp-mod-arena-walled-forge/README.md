# Sports Arena | Map Pack (Walled)

Sports Arena | Map Pack delivers a large, multi-purpose modern venue designed for high-energy competitions, media events, riots, chases, and behind-the-scenes drama.

This pack includes a fully realized Sports Arena with configurable spaces for basketball, hockey, boxing, and MMA, along with all the supporting infrastructure that makes the venue feel alive. Explore crowded concourse areas, tense locker rooms, elevated press boxes, and layered lower and upper seating that support everything from packed championship nights to empty, echoing off-hours scenes.

Exclusive VIP Boxes provide an ideal setting for power brokers, secret meetings, or protected targets, while the arena floor itself supports fast-moving action, crowd control scenarios, and cinematic combat.

Whether your story centers on a championship bout, a media spectacle gone wrong, or a covert operation hidden inside a massive public event, Sports Arena | Map Pack offers a flexible, high-impact location built for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Sports Arena
  - Basketball
  - Boxing
  - Concourse
  - Hockey
  - Locker Rooms
  - MMA
  - Press Boxes
  - Seating Lower
  - Seating Upper
  - VIP Boxes

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
