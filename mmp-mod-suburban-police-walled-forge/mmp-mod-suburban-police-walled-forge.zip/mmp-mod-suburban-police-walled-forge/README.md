# Suburban Police Station | Map Pack (Walled)

Suburban Police Station | Map Pack delivers a clean, modern law-enforcement facility ideal for investigations, patrol-based campaigns, small-town crime, or tense standoffs away from the urban core.

This pack features a detailed Suburban Police Station interior with offices, holding areas, and operational spaces, paired with an accessible roof—perfect for surveillance, rooftop encounters, or dramatic arrivals.

Whether used as a community-focused precinct, a last line of defense during a crisis, or the center of a procedural investigation, Suburban Police Station | Map Pack provides a versatile and grounded setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Suburban Police Station - station, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
