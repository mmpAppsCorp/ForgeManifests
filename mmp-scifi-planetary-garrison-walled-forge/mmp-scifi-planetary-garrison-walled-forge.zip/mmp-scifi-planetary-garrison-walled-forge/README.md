# SciFi Planetary Garrison | Map Pack (Walled)

SciFi Planetary Garrison | Map Pack delivers a fortified military installation designed for holding territory, projecting power, and defending key locations across hostile worlds.

This pack features a fully realized Planetary Garrison mapped across three functional levels, with each layout provided in arctic, desert, grassland, water, and swamp environments. The modular design makes it easy to represent frontline bases, occupation forces, remote outposts, or heavily guarded research and logistics hubs.

Whether your campaign involves planetary invasions, resistance movements, covert raids, or last-stand defenses, SciFi Planetary Garrison | Map Pack provides a flexible, battle-ready setting adaptable to nearly any sci-fi scenario.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Planetary Garrison
  - Three levels in arctic, desert, grassland, water and swamp

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
