# Luxury Hotel | Map Pack (Walled)

Luxury Hotel | Map Pack delivers an upscale, modern lodging environment ideal for high-stakes intrigue, corporate drama, covert operations, social encounters, or sudden violence beneath polished surfaces.

This pack features a fully realized Luxury Hotel with elegant public spaces and private areas, including a refined Lobby and Lounge, a stylish Restaurant, and a Pool presented in summer, winter, and winter-empty configurations. Guest areas are divided into dedicated Rooms and Suites Wings, while behind-the-scenes locations such as the Kitchen and Employee Suite allow stories to unfold beyond the public eye.

Whether hosting clandestine meetings, dramatic confrontations, or quiet surveillance in a place where appearances matter, Luxury Hotel | Map Pack provides a versatile and immersive setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Luxury Hotel
  - Lounge
  - Lobby
  - Pool, summer, winter, winter empty
  - Restaurant
  - Rooms Wing
  - Suites Wing
  - Kitchen
  - Employee Suite

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
