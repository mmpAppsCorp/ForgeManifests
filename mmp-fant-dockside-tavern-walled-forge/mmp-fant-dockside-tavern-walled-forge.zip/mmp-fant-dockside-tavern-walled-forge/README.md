# Fantasy Dockside Tavern | Map Pack (Walled)

Dockside Tavern | Map Pack delivers a gritty waterfront drinking hole ideal for smuggling deals, sailor brawls, clandestine meetings, or rumors that arrive by tide.

This pack features a three-level Dockside Tavern, combining rough-and-tumble public spaces with upper rooms and back areas perfect for shady negotiations, hidden cargo, or sudden violence. Its placement along the docks makes it a natural crossroads for merchants, sailors, criminals, and adventurers alike.

Whether used as a neutral meeting ground, a den of vice, or the spark point for a larger waterfront conflict, Dockside Tavern | Map Pack provides a flexible and atmospheric setting for fantasy campaigns that thrive on intrigue and danger.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dockside Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
