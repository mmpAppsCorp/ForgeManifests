# Fantasy Circus Tavern | Map Pack (Walled)

Circus Tavern | Map Pack delivers a lively, unconventional gathering place where performers, drifters, and troublemakers cross paths beneath canvas and torchlight.

This pack features a two-level Circus Tavern, blending the atmosphere of a traveling carnival with a functioning tavern. Expect makeshift construction, colorful décor, and spaces suited for drinking, plotting, gambling, or backstage intrigue—perfect for encounters that feel chaotic, loud, and unpredictable.

Whether used as a neutral meeting ground, a hub for performers and rogues, or the backdrop for a bar fight that spills into the night, Circus Tavern | Map Pack provides a distinctive and memorable setting for fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Circus Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
