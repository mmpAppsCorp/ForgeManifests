# Viking Village - Craftsman Huts | Map Pack (Walled)

Viking Village – Craftsmen Huts | Map Pack delivers a cluster of working huts at the heart of a Norse settlement, ideal for scenes focused on trade, daily life, craftsmanship, or local intrigue.

This pack features detailed Craftsmen Huts, designed to represent the workshops and living spaces of smiths, woodworkers, leatherworkers, and other village artisans. The layout supports roleplay-heavy encounters, quiet investigations, or conflicts that erupt in the middle of everyday labor.

All land maps are provided in summer and winter environments, allowing you to shift the tone from bustling seasonal activity to harsh, snowbound survival. Whether your story involves trade disputes, hidden contraband, or the vital backbone of a Viking economy, Viking Village – Craftsmen Huts | Map Pack offers a grounded and atmospheric setting for Norse adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Craftsmen Huts

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
