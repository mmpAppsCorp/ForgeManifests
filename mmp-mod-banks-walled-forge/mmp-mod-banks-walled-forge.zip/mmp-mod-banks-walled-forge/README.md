# Two Modern Banks | Map Pack (Walled)

Two Modern Banks | Map Pack delivers a pair of contemporary financial locations ideal for heists, investigations, hostage situations, or high-stakes urban encounters.

This pack includes a Freestanding Bank, complete with interior banking spaces and a rooftop, as well as a Bank in a Mall, offering a very different layout and security profile shaped by shared public access and surrounding retail. Together, these maps support a wide range of scenarios—from quiet fraud investigations to fast-moving robberies or coordinated law-enforcement responses.

Whether your story calls for a carefully planned vault job, a tense standoff in a public space, or a covert operation hidden among everyday civilians, Two Modern Banks | Map Pack provides flexible, believable environments ready for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Freestanding Bank - bank & roof
- Bank in a Mall

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
