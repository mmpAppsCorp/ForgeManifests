# Mazes & Labyrinths  | Map Pack  (Walled)

Mazes & Labyrinths | Map Pack delivers a collection of disorienting, puzzle-driven environments designed to confuse, challenge, and test adventurers at every turn.

This pack includes both large and small mazes, built in a variety of thematic styles—arctic, funhouse, hedge, stone, and wood—making them equally suited for ancient ruins, cursed gardens, magical trials, or deadly traps. Each layout is crafted to support exploration, ambushes, time pressure, and mind-bending navigation.

Whether your party is racing against the clock, hunting something unseen, or slowly realizing they are hopelessly lost, Mazes & Labyrinths | Map Pack provides flexible, atmospheric maps that turn movement itself into the challenge.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Mazes & Labyrinths
  - Large & small
  - Arctic, funhouse, hedge, stone, wood versions

The teleportation circles are of the same design as those found in our other fantasy map packs, like Fantasy City, 6 Fantasy Villages and Places of Worship.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
