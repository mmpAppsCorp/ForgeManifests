# House Construction | Map Pack (Walled)

House Construction | Map Pack delivers an active residential build site ideal for modern investigations, criminal activity, accidents, surveillance, or tense confrontations amid unfinished structures.

This map depicts a partially constructed house, featuring exposed framing, incomplete rooms, construction materials, and work-in-progress details that create natural cover, vertical movement, and environmental hazards. It’s well suited for scenes involving break-ins, sabotage, inspections gone wrong, or encounters that unfold before the walls are even finished.

Whether used as a quiet neighborhood project or a risky construction zone hiding something illicit, House Construction | Map Pack provides a grounded, flexible setting for modern campaigns that need realism and tension without finished comforts.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- House Construction

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
