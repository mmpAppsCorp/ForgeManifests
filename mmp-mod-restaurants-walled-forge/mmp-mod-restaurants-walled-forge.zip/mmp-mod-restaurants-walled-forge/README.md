# Restaurants | Map Pack (Walled)

Restaurants | Map Pack offers a curated collection of distinct dining locations, each with its own atmosphere and storytelling possibilities.

Included are an Asian Restaurant, a cozy Pizzeria, an upscale Wine Bar, and a fast-paced Fast Food Restaurant—covering everything from quiet conversations and secret meetings to sudden violence or chaotic emergencies.

These locations work equally well for social scenes, investigations, criminal dealings, or action that erupts in public spaces. Restaurants | Map Pack adds grounded, recognizable settings that help anchor modern adventures in everyday life.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Asian Restaurant
- Pizzeria
- Wine Bar
- Fast Food Restaurant

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
