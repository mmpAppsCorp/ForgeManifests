# 13 Dark Elf Tavern | Map Pack (Walled)

Dark Elf Tavern | Map Pack delivers a shadowy, elegant gathering place steeped in intrigue, secrecy, and subterranean culture—perfect for intrigue-driven encounters, faction meetings, assassinations, or morally gray negotiations.

This pack features a three-level Dark Elf Tavern, blending refined architecture with ominous design elements. The layout supports layered gameplay, from public-facing social spaces to more private and dangerous upper or lower areas where plots unfold away from prying eyes.

Whether used as a neutral meeting ground, a den of conspiracies, or a deceptively civilized front for darker dealings, Dark Elf Tavern | Map Pack provides a richly atmospheric setting for fantasy campaigns that thrive in the shadows.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dark Elf Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
