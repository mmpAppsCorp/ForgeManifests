# Train Yard | Map Pack (Walled)

Train Yard | Map Pack delivers a sprawling industrial rail facility ideal for modern action, investigations, logistics-based missions, or large-scale encounters.

This pack features a detailed Train Yard presented across ground and upper levels, allowing you to stage scenes both on the tracks and from elevated vantage points. Rail lines, service areas, platforms, and surrounding infrastructure create a believable working yard suited for surveillance, ambushes, chases, or covert exchanges.

Whether your scenario involves freight transfers, criminal activity, sabotage, or tense confrontations amid moving trains and heavy equipment, Train Yard | Map Pack provides a flexible, atmospheric setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Train Yard - ground, upper

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
