# Naga Tavern | Map Pack (Walled)

Naga Tavern | Map Pack delivers an atmospheric, serpentine gathering place blending social space with ancient ritual—perfect for exotic encounters, hidden cults, uneasy alliances, or mythic intrigue.

This pack features a distinctive Naga Tavern where hospitality and worship intertwine. The tavern level serves as a meeting ground for travelers, mercenaries, and locals alike, while the temple levels below (or above) hint at deeper traditions, sacred rites, and secrets best kept from outsiders.

Whether used as a neutral meeting place, a religious stronghold, or the setting for tense negotiations with inhuman hosts, Naga Tavern | Map Pack provides a unique and evocative location for fantasy campaigns that venture beyond the familiar.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Naga Tavern - tavern, temple levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
