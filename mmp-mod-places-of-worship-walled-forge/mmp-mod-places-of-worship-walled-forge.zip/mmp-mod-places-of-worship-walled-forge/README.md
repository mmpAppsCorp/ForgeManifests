# Places of Worship | Map Pack (Walled)

Places of Worship | Map Pack brings together a diverse collection of sacred sites from across cultures and belief systems, ideal for spiritual journeys, political intrigue, hidden cults, investigations, or dramatic confrontations where faith and power intersect.

This pack features a range of distinct religious locations, including a serene Buddhist Temple, an expansive multi-level Hindu Temple, a detailed Mosque, a quiet Shinto Shrine, a contemplative Synagogue, and an open-air Pagan Grove. Each location is designed to support scenes of ceremony, refuge, secrecy, or conflict, with layouts that encourage exploration and meaningful encounters.

Whether your campaign centers on diplomacy, mystery, forbidden rituals, or the clash between belief and action, Places of Worship | Map Pack provides respectful, atmospheric environments that add depth and gravity to your world.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Buddhist Temple - two levels
- Hindu Temple - four levels
- Mosque - four levels
- Pagan Grove
- Shinto Shrine
- Synagogue - two levels and basement

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
