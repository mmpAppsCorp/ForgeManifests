# Department Store | Map Pack (Walled)

Department Store | Map Pack delivers a classic multi-level retail environment ideal for modern investigations, heists, chases, disasters, or everyday urban encounters.

This pack includes a fully realized Department Store spanning the basement, ground floor, upper floor, and roof, providing a wide variety of interconnected spaces—from sales floors and stock areas to service corridors and rooftop access. The vertical layout makes it especially well suited for pursuits, ambushes, and escalating encounters that move between levels.

Whether the store is bustling with shoppers, shuttered after hours, or the scene of a high-stakes operation, Department Store | Map Pack offers a flexible and immersive setting for modern and near-modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Department Store - basement, ground, upper, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
