# Modern Industrial | Map Pack (Walled)

Modern Industrial | Map Pack delivers a collection of gritty, utilitarian locations ideal for crime dramas, investigative campaigns, blue-collar settings, and high-risk urban encounters.

This pack covers a range of industrial and vehicle-focused sites, including an Auto Salvage Yard, Salvage Yard, Impound Lot, Car Dealership, and Storage Facility. Each location is designed to support scenarios involving theft, surveillance, interrogations, covert exchanges, chases, or large-scale confrontations amid machinery, vehicles, and fenced compounds.

Whether your story centers on organized crime, law enforcement operations, corporate secrets, or desperate last-stand battles in forgotten industrial zones, Modern Industrial | Map Pack provides flexible, realistic environments ready for modern adventures.

---

## Included Maps

This pack contains the following locations:

- Auto Salvage Yard
- Car Dealership
- Impound Lot
- Salvage Yard
- Storage Facility

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
