# Western Adventures - Sheriff Offices | Map Pack (Walled)

Sheriff Offices - Map Pack delivers an authentic frontier law-enforcement setting ideal for investigations, standoffs, jailbreaks, or tense negotiations at the heart of a Wild West town.

This pack includes both a Large Sheriff’s Office and a Small Sheriff’s Office, each provided in summer and winter settings. Interiors feature offices, holding cells, evidence areas, and public-facing spaces suited for interrogations, legal drama, or sudden violence.

All maps come with complete line-of-sight setup, with walls, doors, and windows already placed—ready for immediate play.

Whether serving as the last bastion of law, a corrupt authority hub, or the target of a daring rescue, Sheriff Offices - Map Pack provides a versatile and atmospheric location for Western adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Sheriff Office / Small Sheriff Office - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
