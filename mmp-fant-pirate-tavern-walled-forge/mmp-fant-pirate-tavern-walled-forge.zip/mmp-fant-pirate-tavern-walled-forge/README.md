# Fantasy Pirate Tavern | Map Pack (Walled)

Pirate Tavern | Map Pack delivers a lawless waterfront watering hole perfect for smugglers, cutthroats, privateers, and crews fresh off the sea.

This pack features a three-level Pirate Tavern, blending rough dockside drinking halls with shadowy back rooms and upper-level spaces where deals are made, maps are traded, and mutinies are planned. The layout supports brawls, secret meetings, hidden stashes, and sudden ambushes, making it ideal for high-energy encounters and morally questionable negotiations.

Whether serving as a neutral ground for rival crews, a base of operations for a pirate captain, or the spark point for chaos in a port city, Pirate Tavern | Map Pack provides a gritty, character-driven setting ready for adventure.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Pirate Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
