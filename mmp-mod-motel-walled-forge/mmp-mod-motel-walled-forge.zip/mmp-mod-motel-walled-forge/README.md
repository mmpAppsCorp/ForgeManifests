# Modern Motel | Map Pack (Walled)

Modern Motel | Map Pack delivers a classic roadside lodging location ideal for investigations, stakeouts, criminal hideouts, roadside encounters, or low-budget travel scenes in modern campaigns.

This pack features a two-floor Modern Motel, with exterior walkways, stair access, and room layouts that support tense surveillance, surprise confrontations, or quiet roleplay moments. The compact design makes it easy to run fast-moving scenes involving multiple rooms, exterior approaches, and line-of-sight play.

Whether it’s a temporary safehouse, a crime scene, a place to lay low, or the setting for an unexpected encounter, Modern Motel | Map Pack provides a familiar, flexible environment ready for modern storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Modern Motel - two floors

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
