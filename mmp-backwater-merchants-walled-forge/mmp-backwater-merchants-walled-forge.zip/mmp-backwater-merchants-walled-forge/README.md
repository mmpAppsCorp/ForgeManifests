# Backwater Town - Merchants | Map Pack (Walled)

Backwater Town – Market | Map Pack delivers a rough-and-tumble trading hub ideal for frontier settlements, desert outposts, or lawless edge-of-civilization towns.

This pack features a Tent Market filled with stalls, awnings, and open trading space, alongside a Merchant building mapped across two levels—perfect for bargaining scenes, shady deals, thefts, or sudden violence when negotiations go wrong.

All maps are provided in arctic, desert, and grassland environments and include both furnished and unfurnished versions, allowing you to tailor the market from a bustling trade center to a stripped-down, abandoned bazaar.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tent Market
- Merchant - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
