# Winter Tavern | Map Pack (Walled)

Winter Tavern | Map Pack delivers a remote, cold-weather refuge ideal for frontier journeys, mountain crossings, survival stories, or tense encounters far from civilization.

This pack features a two-level tavern built to withstand harsh winter conditions, with snow-covered exteriors and warm, fire-lit interiors that contrast sharply with the frozen world outside. It’s well suited for scenes involving stranded travelers, secret meetings, ambushes, or uneasy truces during brutal weather.

Whether serving as a last stop before the wilderness, a haven during a storm, or a dangerous gathering place in the dead of winter, Winter Tavern | Map Pack provides a focused and atmospheric setting for cold-climate fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Winter Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
