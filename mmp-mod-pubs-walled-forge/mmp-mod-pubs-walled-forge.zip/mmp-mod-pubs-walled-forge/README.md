# Pubs | Map Pack (Walled)

Pubs | Map Pack brings together a variety of nightlife and drinking establishments, each suited for roleplay-heavy scenes or explosive turning points.

This collection features a dueling piano bar, an Irish pub, a roadside roadhouse, a sports bar, and a wine bar. These maps are ideal for negotiations, bar fights, secret meetings, or tense social encounters where things can go wrong very quickly.

Perfect for modern, crime, urban fantasy, or horror campaigns that thrive on atmosphere and character interaction.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dueling Piano Bar
- Irish Pub
- Roadhouse Pub
- Sports Bar
- Wine Bar

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
