# Backwater Town - Crime Lord | Map Pack (Walled)

Backwater Town – Crime Lord Headquarters | Map Pack centers on the seat of power in a lawless frontier settlement, perfect for criminal empires, secret negotiations, daring infiltrations, or final showdowns with a syndicate boss.

This pack features a three-level Crime Lord Headquarters, designed with layered security, private quarters, and operational spaces that reflect both wealth and paranoia. It works equally well as a cartel command center, smuggler kingpin’s fortress, or the hidden nerve center of an outlaw town.

All maps are provided in arctic, desert, and grassland environments, and each version comes furnished and unfurnished, giving you full control over how opulent, fortified, or improvised the headquarters appears in your campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Crime Lord Headquarters - three levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
