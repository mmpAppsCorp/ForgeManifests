# Coffee Shop | Map Pack (Walled)

Coffee Shop | Map Pack delivers a modern, everyday location ideal for social encounters, investigations, casual meetings, or scenes that turn tense without warning.

This pack features a detailed Coffee Shop interior designed for contemporary settings, with service counters, seating areas, and back-of-house space that supports everything from quiet conversations and stakeouts to sudden confrontations or dramatic reveals.

Whether it’s a neutral meeting ground, a neighborhood hangout, or the starting point for a larger plot, Coffee Shop | Map Pack provides a flexible and believable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Coffee Shop

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
