# Viking Village - Hermit Hut | Map Pack (Walled)

Viking Village – Hermit Home | Map Pack delivers a quiet, isolated dwelling on the fringes of Norse society, perfect for encounters steeped in mystery, superstition, or hard-won wisdom.

This pack features a detailed Hermit Home set apart from the main village—ideal for seers, outcasts, healers, or those who have chosen solitude over the longhouse. The layout supports intimate roleplay, tense negotiations, secret meetings, or the discovery of hidden knowledge far from prying eyes.

All land maps are provided in summer and winter environments, allowing you to reflect seasonal hardship, isolation, or the slow passage of time.

Whether the hermit is a forgotten warrior, a keeper of ancient lore, or a reluctant ally, Viking Village – Hermit Home | Map Pack offers a focused, atmospheric setting for character-driven moments in Norse-inspired campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hermit Hut

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
