# Goblin Tavern | Map Pack (Walled)

Goblin Tavern | Map Pack delivers a chaotic, cramped, and dangerously lively drinking hole perfect for back-alley dealings, underworld intrigue, or unpredictable brawls in fantasy campaigns.

This pack features a ramshackle Goblin Tavern spread across three distinct levels: a cluttered tavern floor packed with mismatched furniture and questionable patrons, an attic level filled with hoarded junk, secret crawlspaces, and hidden loot, and an inn level offering crude sleeping quarters that are anything but safe or private.

Whether used as a criminal meeting spot, a den of rumors and extortion, or the starting point for a very bad night, Goblin Tavern | Map Pack provides a flavorful and volatile setting ideal for low-ceiling encounters, ambushes, and goblin-style hospitality gone wrong.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Goblin Tavern - tavern, attic, inn levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
