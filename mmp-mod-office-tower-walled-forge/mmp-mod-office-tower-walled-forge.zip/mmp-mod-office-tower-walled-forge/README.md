# Modern Office Tower | Map Pack (Walled)

Office Tower | Map Pack delivers a versatile modern high-rise setting ideal for corporate intrigue, espionage, heists, hostage situations, investigations, or high-stakes action in an urban environment.

This pack includes a detailed Office Tower featuring a public Lobby, two furnished Office Floors, an Empty Floor ready for customization, and a Rooftop suitable for escapes, landings, or confrontations. Each area is provided in both day and night environments, allowing you to easily shift tone from routine business hours to after-dark operations.

Whether the tower serves as a corporate headquarters, a shadowy front for illicit activity, or the centerpiece of a dramatic vertical showdown, Office Tower | Map Pack provides a flexible and atmospheric backdrop for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Office Tower - lobby, two office floors, empty floor, roof, in both day and night environments

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
