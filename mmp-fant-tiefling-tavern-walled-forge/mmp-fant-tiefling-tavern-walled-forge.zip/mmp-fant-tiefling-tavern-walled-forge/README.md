# Tiefling Taverns | Map Pack (Walled)

Tiefling Tavern | Map Pack delivers a decadent and dangerous nightlife location steeped in infernal influence, perfect for intrigue-heavy fantasy campaigns, criminal dealings, cult activity, or morally gray social encounters.

This pack features a multi-level Tiefling Tavern, blending dark elegance with subtle menace. The main tavern floor serves as a social hub for outsiders, warlocks, and power brokers, while the attached brothel introduces opportunities for secrets, leverage, and illicit negotiations. A rooftop level adds vertical gameplay space for clandestine meetings, escapes, or ritual activity under the open sky.

Whether used as neutral ground for rival factions, a front for darker operations, or a hotspot for temptation and betrayal, Tiefling Tavern | Map Pack provides a richly atmospheric setting tailored for high-stakes fantasy roleplay.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tiefling Tavern - tavern, brothel, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
