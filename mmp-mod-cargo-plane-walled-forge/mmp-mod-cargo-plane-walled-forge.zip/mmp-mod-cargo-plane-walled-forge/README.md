# Military Cargo Plane | Map Pack (Walled)

**Military Cargo Plane | Map Pack** provides versatile, high-detail environments built for modern and near-future military operations, emergency scenarios, and high-stakes action scenes. This collection is ideal for campaigns involving troop transport, evacuations, covert insertions, humanitarian missions, or desperate last-stand defenses.

At the center of the pack is a fully mapped Military Cargo Plane, presented in multiple operational configurations. Interior layouts include empty cargo, evacuation setups, and vehicle transport, allowing the aircraft to support a wide range of mission profiles. Each version is provided with the cargo hatch open and closed, enabling rapid deployments, mid-air emergencies, or secure transport scenarios. Exterior and interior scenes are available in flying day, flying night, and landed configurations, giving GMs full control over timing, atmosphere, and narrative tension.

To support ground-based operations, the pack also includes a Military Boot Camp, offered in arctic, desert, and grassland environments. Key training and operational facilities include an Admin Building, Barracks, Classroom, Firing Range, Mess & Kitchen, and an Obstacle Course—perfect for training sequences, inspections, sabotage missions, or surprise attacks on a secure installation.

Whether your story focuses on airborne operations, emergency extractions, military logistics, or life on the base between missions, **Military Cargo Plane | Map Pack** delivers flexible, realistic locations ready to drop directly into your campaign.

---

## Included Maps

This pack contains the following locations:

- Military Cargo Plane
  - Empty, evacuation, and vehicle cargo
  - All maps with hatch open, hatched closed
  - Flying day, flying night, and landed configurations

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
