# Inner-City Police Station | Map Pack (Walled)

Inner-City Police Station | Map Pack delivers a dense, multi-level law enforcement complex designed for investigations, raids, interrogations, and high-tension urban encounters.

This pack includes a fully realized Inner-City Police Station with ground, upper, lower, and rooftop levels, featuring offices, holding areas, corridors, and operational spaces suited for both routine policing and crisis scenarios. The layered layout supports pursuits across floors, covert infiltration, hostage situations, or last-stand rooftop confrontations.

Whether your story involves detectives chasing leads, criminals attempting a breakout, or authorities responding to a citywide emergency, Inner-City Police Station | Map Pack provides a gritty, versatile setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Inner-City Police Station - ground, upper, lower, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
