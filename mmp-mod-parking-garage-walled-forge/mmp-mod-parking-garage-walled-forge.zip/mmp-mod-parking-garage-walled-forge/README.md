# Parking Garage | Map Pack (Walled)

Parking Garage | Map Pack delivers a versatile multi-level urban structure ideal for chases, ambushes, investigations, covert meetings, or large-scale action scenes.

This pack features a detailed Parking Garage with both above-ground and underground levels, providing ramps, columns, stairwells, and sightline-breaking geometry that naturally supports tactical movement, stealth, and vertical play.

Included parked car overlay tiles allow you to quickly populate the garage, control visibility, create cover, or adjust traffic density to suit everything from quiet surveillance to explosive confrontations.

Whether used as a neutral transit space, a criminal rendezvous point, or the backdrop for high-speed pursuits and last-stand shootouts, Parking Garage | Map Pack offers a flexible and highly reusable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Parking Garage - above & below ground

We also include overlay tiles for:
- Parked Cars

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
