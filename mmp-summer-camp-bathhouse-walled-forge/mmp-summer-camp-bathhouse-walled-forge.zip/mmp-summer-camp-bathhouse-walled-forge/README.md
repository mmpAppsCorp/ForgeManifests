# Summer Camp - Bathhouse | Map Pack (Walled)

Summer Camp – Bathhouse | Map Pack delivers a classic camp essential perfect for coming-of-age stories, mystery scenarios, slasher horror, or nostalgic outdoor adventures.

This pack features a detailed Bathhouse, presented on both the ground level and roof, allowing for scenes that range from everyday camp routines to tense after-hours encounters. Lockers, showers, and shared facilities provide a familiar setting that can quickly turn dramatic, secretive, or dangerous depending on your campaign’s tone.

Whether used as a place for character interactions, hidden confrontations, or late-night exploration, Summer Camp – Bathhouse | Map Pack adds an atmospheric and story-rich location to any modern or horror-inspired game.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bathhouse - ground & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
