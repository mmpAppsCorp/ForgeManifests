# 13 Lizardfolk Taverns | Map Pack (Walled)

Lizardfolk Tavern | Map Pack delivers a distinctive swamp-bound gathering place ideal for tribal diplomacy, tense negotiations, secret meetings, or encounters deep within hostile wetlands.

This pack features a three-level Lizardfolk Tavern built to suit amphibious inhabitants, with organic architecture, damp stone and wood construction, and spaces designed for communal feasting, rest, and ritual. The layered layout supports vertical gameplay, ambushes, and hidden movement, making it well suited for both social and combat-focused scenes.

Whether used as a neutral meeting ground, a territorial stronghold, or a dangerous stop along a swamp journey, Lizardfolk Tavern | Map Pack provides a unique and atmospheric setting for fantasy campaigns that venture beyond civilized lands.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Lizardfolk Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
