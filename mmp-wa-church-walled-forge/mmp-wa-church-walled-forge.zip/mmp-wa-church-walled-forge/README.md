# Western Adventures - Church | Map Pack (Walled)

Western Adventures – Church | Map Pack delivers a classic frontier place of worship and reflection, ideal for sermons, funerals, secret meetings, or moments of quiet before violence breaks out.

This pack includes a Church and adjacent Cemetery, presented in both summer and winter settings, allowing you to shift tone from peaceful gatherings to grim, snow-covered burials or tense midnight encounters among the graves.

Whether serving as a moral center of town, the site of a dramatic funeral, a hiding place for secrets, or a backdrop for supernatural or outlaw intrigue, Western Adventures – Church | Map Pack provides an atmospheric and versatile location for Wild West campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Church & Cemetery - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
