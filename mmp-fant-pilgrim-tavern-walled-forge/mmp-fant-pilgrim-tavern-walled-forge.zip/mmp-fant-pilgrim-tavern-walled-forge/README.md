# Fantasy Pilgrim Taverns | Map Pack (Walled)

Pilgrim Tavern | Map Pack provides a humble roadside refuge designed for weary travelers, religious pilgrims, messengers, and wanderers making long journeys across dangerous lands.

This pack features a three-level Pilgrim Tavern built for practicality rather than luxury, with simple common areas, shared sleeping spaces, storage, and service rooms that reflect a place focused on shelter, food, and quiet reflection. Its layout makes it ideal for low-key social encounters, rumors and information exchange, or tense moments when strangers from many paths are forced under one roof.

Whether serving as a safe stop along a sacred route, a neutral meeting ground, or the backdrop for intrigue hiding behind modest walls, Pilgrim Tavern | Map Pack offers an atmospheric and versatile setting for fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Pilgrim Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
