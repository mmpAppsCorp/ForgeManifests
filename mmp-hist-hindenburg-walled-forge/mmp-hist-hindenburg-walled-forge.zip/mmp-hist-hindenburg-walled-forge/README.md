# The Hindenburg | Map Pack (Walled)

The Hindenburg | Map Pack brings one of history’s most iconic airships to life as a fully explorable setting for investigation, intrigue, disaster scenarios, or period adventures.

This pack recreates the Hindenburg in extensive detail, mapping everything from its internal structure to passenger spaces and engineering sections. Explore the Keel Plan and Maintenance areas, move through Crew Cabins and Cargo Sections, or stage tense scenes aboard the Gondola and Engine Cars, each presented in flying, landed, and night configurations.

Passenger areas are fully realized across both A Deck and B Deck, also shown in multiple states, allowing you to portray routine travel, high-society luxury, or escalating emergencies. The Fore Section and Command Crew areas provide ideal locations for command decisions, sabotage, or last-minute heroics.

Whether used for historical drama, alternate history, pulp adventure, or catastrophic mystery, The Hindenburg | Map Pack delivers a richly detailed airborne environment ready for unforgettable storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hindenburg
  - Keel Plan
  - Gondola - flying, landed, night
  - Crew Cabins
  - Maintenance Section
  - Engine Car - flying, landed, night
  - Cargo Section
  - Fore Section
  - Command Crew Section
  - A Deck - flying, landed, night
  - B Deck - flying, landed, night

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
