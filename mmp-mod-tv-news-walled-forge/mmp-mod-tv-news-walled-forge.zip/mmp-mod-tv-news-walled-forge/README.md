# TV News | Map Pack (Walled)

TV News | Map Pack delivers a modern broadcast environment ideal for investigative journalism, breaking-news chaos, political drama, media manipulation, or high-stakes action set during a live report.

This pack provides a detailed television news setting, featuring a professional news studio and supporting spaces designed for on-air broadcasts, behind-the-scenes tension, and rapid transitions from calm reporting to unfolding crisis.

Whether your scene involves exposing a conspiracy, staging a dramatic interruption, or navigating the pressure of live television, TV News | Map Pack offers a flexible, believable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- TV News Studio

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
