# Loading Dock | Map Pack (Walled)

Loading Dock | Map Pack delivers a flexible industrial setting ideal for deliveries, ambushes, investigations, and blue-collar drama in modern campaigns.

This pack includes a detailed Loading Dock environment presented in two variants—with and without a forklift—allowing you to quickly shift the tone from routine logistics to tense, high-risk encounters. The space is well suited for scenes involving cargo transfers, thefts in progress, undercover surveillance, or sudden confrontations amid pallets, bays, and industrial equipment.

Whether it’s a late-night shipment gone wrong or a critical choke point in a larger facility, Loading Dock | Map Pack provides a grounded, versatile location that fits seamlessly into warehouses, factories, ports, and urban backlots.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Loading Dock - with and without forklift

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
