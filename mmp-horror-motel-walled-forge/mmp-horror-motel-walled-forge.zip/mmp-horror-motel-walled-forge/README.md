# Redrum Motel | Map Pack (Walled)

Redrum Motel | Map Pack delivers a grim roadside location steeped in dread, perfect for horror investigations, cult activity, disappearances, or supernatural encounters where nothing is as mundane as it first appears.

This pack features a two-level Motel presented in multiple disturbing variants. Both the Ground Floor and Upper Floor are available in normal, emblem-marked, satanic, and void-portal versions, allowing the location to shift from unsettling to outright nightmarish. Individual Rooms escalate the horror further, offering scenes of execution, headshots, murder, torture, and active void portals—ideal for unraveling dark rituals or confronting unspeakable entities.

Whether used as a cursed stop along a lonely highway, a cult-controlled safehouse, or a gateway to something far worse, Redrum Motel | Map Pack provides a flexible and deeply unsettling setting for horror-focused campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Motel
  - Ground Floor - normal, emblem, satanic, void portal
  - Upper Floor - normal, emblem, satanic, void portal
  - Rooms - normal, execution, headshot, murder, torture, void portal

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
