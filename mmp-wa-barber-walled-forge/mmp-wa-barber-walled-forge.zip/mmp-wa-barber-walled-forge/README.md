# Western Adventures - Barbers | Map Pack (Walled)

Western Adventures – Barbers | Map Pack delivers an authentic slice of frontier life, perfect for social encounters, rumors, investigations, or the calm before a gunfight.

This pack includes both Large and Small Barber Shops, each provided in summer and winter settings. Inside you’ll find classic barbers’ chairs, mirrors, wash basins, waiting areas, and back rooms—ideal for overheard conversations, secret meetings, or unexpected trouble.

Whether serving as a community hub, a place to gather gossip, or the site of a sudden confrontation, Western Adventures – Barbers | Map Pack provides a grounded and versatile location for Wild West campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Barber / Small Barber - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
