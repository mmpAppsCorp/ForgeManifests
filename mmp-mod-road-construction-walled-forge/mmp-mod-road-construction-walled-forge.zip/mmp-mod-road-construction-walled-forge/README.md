# Road Construction | Map Pack (Walled)

Road Construction | Map Pack delivers an active, in-progress urban environment ideal for modern investigations, tactical encounters, chases, accidents, or scenes where everyday infrastructure becomes an unexpected obstacle.

This pack presents a detailed road construction site complete with barriers, equipment, disrupted traffic flow, and work zones, providing natural cover, bottlenecks, and visual storytelling opportunities. The unfinished terrain creates tension and movement challenges, making it well suited for pursuits, ambushes, emergency responses, or covert operations.

With 10 distinct environmental variants, Road Construction | Map Pack adapts easily to a wide range of settings—from quiet suburban projects to chaotic city repairs—giving you a flexible backdrop for modern campaigns where the road itself becomes part of the encounter.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Road Construction - 10 environments

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
