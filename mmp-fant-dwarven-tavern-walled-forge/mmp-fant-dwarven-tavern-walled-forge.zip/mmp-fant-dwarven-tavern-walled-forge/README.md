# Dwarven Tavern | Map Pack (Walled)

Dwarven Tavern | Map Pack delivers a rugged, stone-hewn gathering place carved deep into tradition, perfect for clan meetings, mercenary negotiations, underground brawls, or long nights of ale and song.

This pack features a two-level Dwarven Tavern, with a stout main hall built for heavy traffic and hard drinking, and an upper or lower level suited for private rooms, storage, or back-room dealings. Thick walls, heavy furniture, and a fortress-like layout give the tavern a defensible, lived-in feel that reflects dwarven craftsmanship and culture.

Whether serving as a neutral meeting ground, a stronghold within a mountain city, or the last stop before a dangerous delve, Dwarven Tavern | Map Pack provides a durable and atmospheric location for any fantasy campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dwarven Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
