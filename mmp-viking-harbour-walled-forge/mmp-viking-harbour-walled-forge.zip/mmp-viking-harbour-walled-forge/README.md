# Viking Village - Harbour | Map Pack (Walled)

Viking Village – Harbour | Map Pack delivers a rugged coastal hub essential to Norse life, trade, and raiding, perfect for seafaring adventures, tense negotiations, surprise attacks, or everyday village activity.

This pack features a detailed Viking harbour, designed to serve as the village’s connection to the wider world. Docks, shoreline access, and working waterfront spaces provide a natural setting for arriving longships, loading cargo, greeting traders, or launching raids at dawn.

With both summer and winter environments included, the harbour seamlessly shifts from busy trading season to icy, windswept isolation, allowing you to reflect the harsh realities of Viking life and the changing seasons.

Whether your story centers on commerce, diplomacy, exploration, or sudden violence from the sea, Viking Village – Harbour | Map Pack offers an atmospheric and versatile coastal location ready for Norse sagas.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Harbour

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
