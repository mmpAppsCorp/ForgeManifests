# Auto Mechanic | Map Pack (Walled)

Auto Mechanic | Map Pack delivers a functional, workmanlike service garage ideal for investigations, street-level crime, undercover meetings, or action scenes that turn violent fast.

This pack features a detailed Auto Mechanic location built around repair bays, tool areas, storage, and workspaces—perfect for ambushes between vehicles, evidence searches, or tense confrontations amid lifts, engines, and oil-stained concrete.

Whether it’s a legitimate repair shop, a criminal front, or the site of a sudden raid, Auto Mechanic | Map Pack provides a grounded, flexible setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Auto Mechanic

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
