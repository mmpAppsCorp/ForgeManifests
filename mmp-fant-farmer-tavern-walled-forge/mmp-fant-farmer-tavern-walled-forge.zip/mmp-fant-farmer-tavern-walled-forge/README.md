# Fantasy Farmer Tavern | Map Pack (Walled)

Farmer Tavern | Map Pack delivers a rustic countryside gathering place ideal for small-town intrigue, frontier meetings, traveling adventurers, or low-key trouble that slowly turns dangerous.

This pack features a three-level Farmer Tavern, blending a working rural atmosphere with communal drinking spaces, private rooms, and back-of-house areas where secrets, side deals, and local grudges naturally emerge.

Whether used as a humble stop along a country road, a hub for local gossip, or the quiet starting point of a much larger conflict, Farmer Tavern | Map Pack provides an authentic and flexible setting for grounded fantasy or historical campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Farmer Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
