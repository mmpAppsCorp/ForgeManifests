# Fantasy Soldier Tavern | Map Pack (Walled)

Soldier Tavern | Map Pack delivers a hard-used military drinking hall built for off-duty troops, mercenaries, and guards looking for cheap ale, loud company, and occasional trouble.

This pack features a two-level Soldier Tavern, with a rugged ground floor designed for communal drinking, gambling, and brawls, and an upper level suitable for private rooms, bunk areas, or officers’ corners. The layout supports everything from tense confrontations and recruitment scenes to undercover meetings or morale-breaking fights.

Whether it serves as a frontier garrison hangout, a mercenary stronghold, or a volatile neutral ground between factions, Soldier Tavern | Map Pack provides a gritty, practical tavern environment ready for fantasy campaigns that lean toward realism and conflict.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Soldier Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
