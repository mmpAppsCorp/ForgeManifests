# Teleportation Circles  | Map Pack  (Walled)

Teleportation Circles | Map Pack delivers a versatile collection of magical transit locations designed to seamlessly connect cities, wilderness, and hidden interiors across your fantasy campaigns.

This pack features teleportation circles embedded in a wide range of environments, from icy arctic outposts and desert cities to libraries, inns, remote huts, and ruined locations. These maps are ideal for arcane travel, secret networks, emergency escapes, and high-stakes arrivals that instantly change the flow of an adventure.

All teleportation circles share a consistent visual design, matching those found in our other fantasy map packs—including Fantasy City, 6 Fantasy Villages, Fantasy Inns, Mage Towers, Winter Walls, and Places of Worship—making them easy to integrate into existing worlds.

Whether used as ancient relics, regulated transit hubs, or forbidden magical gateways, Teleportation Circles | Map Pack provides flexible, ready-to-use locations that keep your party moving and your story connected.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Teleportation Circles in Various Locations
  - Arctic
  - Audience Chamber
  - City Terminal
  - Desert City
  - Desert
  - Deserted Island
  - Forest
  - Hut
  - Library
  - City
  - Old City
  - Ruins, arctic, desert, forest, fall
  - Secure City
  - Scholar's Apartment

The teleportation circles are of the same design as those found in our other fantasy map packs, like Fantasy City, 6 Fantasy Villages, Fantasy Inns, Mage Towers, Winter Walls, and Places of Worship.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
