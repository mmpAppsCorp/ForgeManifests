# Deep Space Station | Map Pack (Walled)

Deep Space Station | Map Pack delivers a sprawling orbital installation designed for diplomacy, intrigue, trade, and high-stakes conflict in science-fiction campaigns.

At the heart of the station is a central Hub, featuring the Bridge, captain’s quarters, reception area, and teleporter—perfect for command decisions, tense negotiations, or sudden arrivals. Radiating outward are four massive station quarters (NE, SE, NW, SW), each fully mapped across main deck, upper deck, and sub-deck levels, providing a dense, believable environment for exploration, investigation, and conflict.

Whether serving as a neutral meeting ground, a bustling trade nexus, a strategic military outpost, or a target for sabotage, Deep Space Station | Map Pack offers a versatile, fully realized setting ready to anchor entire story arcs in your sci-fi adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Deep Space Station
  - Hub - Bridge, captain's quarters, reception, teleporter
  - NE Quarter - main deck, upper deck, sub-deck
  - SE Quarter - main deck, upper deck, sub-deck
  - NW Quarter - main deck, upper deck, sub-deck
  - SW Quarter - main deck, upper deck, sub-deck

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
