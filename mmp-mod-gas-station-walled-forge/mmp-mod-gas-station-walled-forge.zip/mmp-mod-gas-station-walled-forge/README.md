# Modern Gas Station | Map Pack (Walled)

Gas Station | Map Pack delivers a compact, everyday roadside location ideal for modern encounters, investigations, ambushes, or chance meetings that spiral into chaos.

This pack includes a detailed Gas Station interior with counters, aisles, and back-of-house spaces, along with the Roof, opening up vertical options for overwatch, pursuits, or last-stand scenarios. It works equally well as a routine stop, a criminal meetup, or the flashpoint of a sudden confrontation.

Whether it’s a quiet refueling stop, a tense standoff under flickering lights, or a late-night incident on the edge of town, Gas Station | Map Pack provides a familiar setting with plenty of narrative and tactical potential.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Gas Station - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
