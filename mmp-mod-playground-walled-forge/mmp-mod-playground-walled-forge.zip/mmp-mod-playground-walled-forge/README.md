# Playground | Map Pack (Walled)

Playground | Map Pack delivers a familiar outdoor setting ideal for modern investigations, lighthearted encounters, tense confrontations, or scenes that contrast innocence with danger.

This pack features a detailed public playground layout with play structures, open areas, and surrounding space suitable for chases, stakeouts, social encounters, or unexpected conflicts. The environment works equally well for daytime scenes full of activity or quieter, more unsettling nighttime moments.

Whether used as a neighborhood gathering place, a rendezvous point, or the backdrop for a dramatic turn in your story, Playground | Map Pack provides a flexible and evocative location for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Playground

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
