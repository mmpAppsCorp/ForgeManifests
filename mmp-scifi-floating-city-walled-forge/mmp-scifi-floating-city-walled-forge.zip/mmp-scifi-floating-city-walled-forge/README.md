# Floating City | Map Pack (Walled)

Floating City | Map Pack delivers a dramatic high-altitude science-fiction setting ideal for political intrigue, covert operations, prison breaks, or desperate last stands above the clouds.

This pack features a fully realized Floating City, with maps covering key operational, residential, and security areas. Navigate Control & Security centers, move prisoners through the Prison Room and Freezing Chamber, or stage tense encounters along exposed Streets suspended in the sky. Landing Pads and Landing Pad Entrances support arrivals, departures, ambushes, or emergency evacuations, while Luxury Rooms contrast elite comfort against the city’s harsher underbelly.

Whether the Floating City serves as a neutral trade hub, authoritarian stronghold, secret research site, or final refuge, Floating City | Map Pack provides a versatile and cinematic environment for science-fiction campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Floating City
  - Control & Security
  - Freezing Chamber
  - Landing Pad
  - Landing Pad Entrance
  - Luxury Room
  - Prison Room
  - Reactor Shaft
  - Street

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
