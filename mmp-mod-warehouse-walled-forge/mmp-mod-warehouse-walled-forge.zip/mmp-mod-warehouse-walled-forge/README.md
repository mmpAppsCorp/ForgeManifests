# Modern Warehouse | Map Pack (Walled)

Modern Warehouse | Map Pack delivers a flexible industrial environment ideal for logistics operations, criminal activity, investigations, large-scale fights, or tense stealth encounters in modern campaigns.

This pack features a detailed Warehouse interior with expansive floor space and a mezzanine level, providing verticality for chases, overwatch, and ambushes. Exterior maps are included both with and without a forklift, allowing you to stage loading operations, covert meetings, or sudden confrontations in an active or abandoned facility.

Whether used as a distribution hub, a smuggling operation, a corporate asset, or an improvised battleground, Modern Warehouse | Map Pack offers a versatile and highly replayable industrial setting.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Warehouse - floor, mezzanine, exterior with and without forklift

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
