# Western Adventures - Gallows & Water Tower | Map Pack (Walled)

Western Adventures | Gallows & Water Tower | Map Pack delivers stark public landmarks essential to frontier justice, civic life, and grim storytelling in a Wild West setting.

This pack includes multiple Gallows configurations—Single, Double, and Quad—ideal for executions, last-minute rescues, public unrest, or somber town gatherings. A classic Water Tower is also provided, serving as a town utility, lookout point, or dramatic backdrop for standoffs, sabotage, and chases.

Whether your story centers on law and punishment, frontier survival, or tension-filled public scenes, Western Adventures | Gallows & Water Tower | Map Pack provides iconic structures that anchor your town and raise the stakes of any encounter.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Quad Gallows / Double Gallows / Single Gallows
- Water Tower

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
