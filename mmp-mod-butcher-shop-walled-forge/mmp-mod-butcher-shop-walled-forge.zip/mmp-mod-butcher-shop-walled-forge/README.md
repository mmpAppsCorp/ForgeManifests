# Butcher Shop | Map Pack (Walled)

Butcher Shop | Map Pack provides a detailed neighborhood butcher’s shop suitable for modern, historical, or small-town settings. Designed for investigations, roleplay encounters, or sudden violence in an otherwise ordinary location, this map offers a grounded, believable environment with plenty of atmosphere.

The shop features a fully realized retail space with display counters and prep areas, along with a rooftop map that expands the location vertically for chases, surveillance, or ambushes. Cold storage, work surfaces, and tight interior spaces make it ideal for tense close-quarters scenes or mystery-driven gameplay.

Whether your players are questioning a nervous shop owner, tracking illicit dealings, or discovering something far more sinister behind the counter, Butcher Shop | Map Pack delivers a compact but flexible location ready for modern adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Butcher Shop

Maps are created using DungeonFog.com
---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
