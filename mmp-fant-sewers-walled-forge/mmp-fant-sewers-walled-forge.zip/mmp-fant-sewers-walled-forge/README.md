# Fantasy Sewers | Map Pack (Walled)

Fantasy Sewers | Map Pack delivers a sprawling underground network perfect for intrigue, crime, dark rituals, and secret movement beneath a living fantasy city.

This pack features an interconnected sewer system layered with hidden locations and covert access points, including concealed smuggler routes, a thieves’ guild hideout, an occult lair, and a secret teleportation circle. Twisting sewer paths, blocked and broken outlets, and customizable empty chambers provide ample space for ambushes, investigations, and clandestine encounters.

Tile overlays for manholes allow you to place surface exits exactly where your story demands, seamlessly linking the undercity to streets, buildings, and districts above.

Whether your party is chasing criminals through the muck, uncovering forbidden rituals, or navigating the unseen arteries of a city, Fantasy Sewers | Map Pack offers a flexible and atmospheric foundation for underground adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fantasy Sewers
  - Secret Occult Hideout
  - Hidden Smuggler Entrance
  - Hidden Thieves Guild
  - Hidden Teleportation Circle
  - Sewer Paths
  - Hidden Empty Room - for you to customize
  - Outlet - closed & broken
  - Tile overlays to place manholes (exits) where needed

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
