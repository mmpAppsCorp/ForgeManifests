# Hidden Temple Base | Map Pack (Walled)

Hidden Temple Base | Map Pack presents an ancient structure repurposed into a concealed stronghold, blending forgotten architecture with modern—or otherworldly—function. Ideal for secret factions, lost civilizations, cult headquarters, or dramatic revelations deep within hostile terrain.

This pack features a fully realized Hidden Temple Base, centered around a concealed Hangar and Hangar Control area that supports covert arrivals and departures. Above, five interconnected upper levels rise through the temple structure, offering layered spaces for command chambers, ritual halls, living quarters, or hidden technology.

Whether used as a clandestine rebel base, an ancient site hiding advanced secrets, or a sacred place corrupted by new powers, Hidden Temple Base | Map Pack provides a dramatic and versatile setting for exploration, infiltration, and high-stakes encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Hidden Temple Base
  - Hanger
  - Hanger Control
  - Five Upper Levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
