# Fantasy Country Tavern | Map Pack (Walled)

Country Tavern | Map Pack delivers a rustic roadside gathering place ideal for travel stops, local intrigue, secret meetings, or trouble that follows adventurers off the main road.

This pack features a three-level country tavern, capturing the feel of a well-worn establishment that serves farmers, travelers, and the occasional unsavory patron. With layered interior spaces, it supports scenes ranging from quiet conversations by the hearth to brawls, ambushes, or hidden dealings behind closed doors.

Whether used as a friendly rest stop, a rumor hub, or the center of a rural conspiracy, Country Tavern | Map Pack provides a flexible and atmospheric setting for fantasy campaigns of any tone.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Country Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
