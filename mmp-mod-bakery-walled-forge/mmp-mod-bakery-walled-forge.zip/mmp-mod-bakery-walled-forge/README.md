# Bakery | Map Pack (Walled)

Bakery | Map Pack delivers a warm, everyday retail location ideal for slice-of-life scenes, investigations, meet-ups, or moments that turn unexpectedly tense.

This pack features a detailed bakery interior with display cases, prep areas, ovens, counters, and back-of-house space—perfect for early-morning encounters, casual conversations, stakeouts, or incidents that unfold in a seemingly ordinary setting.

Whether used as a neighborhood staple, a cover for something illicit, or the starting point for a larger story, Bakery | Map Pack provides a grounded and versatile location for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bakery

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
