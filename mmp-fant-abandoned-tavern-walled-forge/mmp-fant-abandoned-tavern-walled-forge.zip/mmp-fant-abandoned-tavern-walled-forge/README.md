# Fantasy Abandoned Tavern | Map Pack (Walled)

Abandoned Tavern | Map Pack delivers a decaying, atmospheric location perfect for mysteries, horror encounters, hidden lairs, or the remnants of a once-busy crossroads.

This pack features a three-level Abandoned Tavern, showcasing collapsed rooms, forgotten storage areas, and shadow-filled upper floors that hint at past violence, secret dealings, or supernatural influence. Every level is designed to support exploration, investigation, and tense encounters where danger may be lurking just out of sight.

Whether the tavern serves as a monster’s den, a cult hideout, a forgotten safehouse, or the starting point of a dark mystery, Abandoned Tavern | Map Pack provides a richly evocative setting ready to be repurposed to fit your campaign’s needs.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Abandoned Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
