# Western Adventures - Saloons | Map Pack (Walled)

Western Adventures - Saloons | Map Pack delivers a collection of classic frontier watering holes ideal for shootouts, secret meetings, high-stakes gambling, or quiet conversations that turn deadly.

This pack features multiple saloon styles—corner, one-story, two-story, and shack—each capturing a different level of prosperity and danger found in a Wild West town. From ramshackle drinking dens to prominent main-street establishments, these locations support everything from barroom brawls and poker games to ambushes and outlaw negotiations.

All saloons are provided in both summer and winter settings, allowing you to easily shift the tone from dusty heat to snow-covered tension. Whether your campaign centers on lawmen, gunslingers, or drifters passing through town, Western Adventures - Saloons | Map Pack offers versatile and atmospheric locations ready for frontier drama.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Corner Saloon - summer & winter settings
- One-Story Saloon - summer & winter settings
- Two-Story Saloon - summer & winter settings
- Shack Saloon - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
