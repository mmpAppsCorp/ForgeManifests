# Fantasy City Tavern | Map Pack (Walled)

City Tavern | Map Pack delivers a bustling urban drinking hall ideal for intrigue, negotiations, clandestine meetings, or sudden violence in the heart of a fantasy city.

This pack features a fully realized three-level City Tavern, designed to support layered gameplay—from crowded common rooms and private booths to upper floors suited for lodging, secret meetings, or hidden operations. The vertical layout makes it easy to stage chases, eavesdropping, ambushes, or escapes through multiple levels of activity.

Whether the tavern serves as a neutral meeting ground, a thieves’ hangout, a mercenary watering hole, or the spark point for a citywide conflict, City Tavern | Map Pack provides a versatile and atmospheric location ready for urban adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- City Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
