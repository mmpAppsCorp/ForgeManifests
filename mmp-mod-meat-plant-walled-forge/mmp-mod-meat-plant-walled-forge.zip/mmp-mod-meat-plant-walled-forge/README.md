# Meat Packing Plant | Map Pack (Walled)

Meat Packing Plant | Map Pack delivers a gritty industrial facility well suited for investigations, survival horror, labor disputes, corporate crime, or high-risk infiltration scenarios.

This map pack depicts a fully realized meat processing environment, with large open work areas, industrial equipment, cold storage zones, and service corridors that create natural tension and choke points. The setting works equally well as an active facility, an abandoned industrial site, or a front for illicit operations.

Whether your story involves uncovering hidden crimes, navigating hazardous machinery, or staging a desperate escape through a harsh industrial landscape, Meat Packing Plant | Map Pack provides a stark, atmospheric location for modern and near-modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Meat Packing Plant

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
