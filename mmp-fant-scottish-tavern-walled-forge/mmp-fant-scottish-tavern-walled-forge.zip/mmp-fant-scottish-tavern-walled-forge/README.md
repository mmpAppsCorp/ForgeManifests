# Fantasy Scottish Tavern | Map Pack (Walled)

Scottish Tavern | Map Pack delivers a rugged, stone-built alehouse steeped in Highland character, perfect for tavern brawls, clan negotiations, secret meetings, or a hard-earned rest after the road.

This pack features a two-level Scottish Tavern, with a hearty ground floor for drinking, dining, and music, and an upper level suited for private rooms, storage, or quieter conversations away from the crowd. Thick walls, heavy timbers, and a weathered atmosphere make it ideal for both civilized gatherings and tense confrontations.

Whether serving as a local clan hub, a remote roadside inn, or the setting for political intrigue and sudden violence, Scottish Tavern | Map Pack provides a flavorful and versatile location for fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Scottish  Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
