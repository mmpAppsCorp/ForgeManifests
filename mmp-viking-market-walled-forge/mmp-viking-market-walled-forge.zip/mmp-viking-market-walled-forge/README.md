# Viking Village - Market | Map Pack (Walled)

Viking Village – Market | Map Pack delivers a lively communal trading space at the heart of a Norse settlement, ideal for social encounters, negotiations, rivalries, and everyday village life in Viking-era campaigns.

This pack features a detailed Viking Market, presented in both interior and exterior configurations. The market is well suited for trade scenes, public gatherings, tense confrontations, or moments where news, rumors, and conflict naturally converge.

All land maps are provided in summer and winter environments, allowing you to shift the atmosphere from bustling seasonal trade to a harsher, snowbound setting without changing layout or scale.

Whether serving as a center of commerce, a backdrop for intrigue, or the spark point for village drama, Viking Village – Market | Map Pack provides a flexible and immersive setting grounded in Norse life.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Market - interior, exterior

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
