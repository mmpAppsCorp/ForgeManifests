# Western Adventures - Trains| Map Pack (Walled)

Western Adventures | Trains brings the thunder and steel of the railroad to your frontier campaigns, providing a complete and versatile set of train cars and track environments perfect for travel, heists, ambushes, troop movements, and dramatic showdowns on the rails.

This pack includes a wide variety of railcars—from boxcars, cattle cars, and troop transports to passenger, sleeper, dining, luggage, and even cannon-equipped railcars—along with a powerful steam locomotive and detailed roof maps for high-risk encounters above the tracks. A blank railcar is also included, giving you full freedom to customize it for unique story needs.

To place your trains anywhere in the frontier, the pack features track environments spanning arctic wastes, desert crossings, grasslands, mountain passes, open plains, and bridges—making it easy to stage chases, derailments, or tense standoffs in any setting.

Whether your party is guarding a shipment, robbing a payroll train, escorting soldiers, or racing against time across hostile territory, Western Adventures | Trains delivers everything you need for cinematic railroad adventures in the Old West.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Train
  - Boxcar
  - Caboose, upper & lower
  - Blank Railcar, for you to customize
  - Cannon Railcar
  - Cattle Car
  - Common Passenger Railcar
  - Common Sleeper Railcar
  - Dining Railcar
  - Luggage Railcar
  - Passenger Railcar
  - Railcar Roof
  - Sleeper Railcar
  - Steam Locomotive
  - Troop Railcar

- Tracks
  - Arctic
  - Bridge
  - Desert
  - Grassland
  - Mountain
  - Plains

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
