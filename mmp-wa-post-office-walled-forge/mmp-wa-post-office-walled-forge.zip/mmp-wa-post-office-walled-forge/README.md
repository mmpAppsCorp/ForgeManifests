# Western Adventures - Post Offices | Map Pack (Walled)

Western Adventures - Post Offices | Map Pack delivers essential frontier infrastructure ideal for mail runs, government business, robberies, investigations, or tense standoffs in classic Wild West campaigns.

This pack includes both Large and Small Post Offices, each provided in summer and winter settings, capturing everything from busy town hubs to isolated frontier outposts. These locations work equally well as centers of communication, places to intercept vital messages, or targets for outlaw schemes.

Whether serving as a quiet civil service building, a hub of town gossip, or the focal point of a daring robbery, Western Adventures - Post Offices | Map Pack provides versatile, period-appropriate locations ready for frontier drama.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Post Office / Small Post Office - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
