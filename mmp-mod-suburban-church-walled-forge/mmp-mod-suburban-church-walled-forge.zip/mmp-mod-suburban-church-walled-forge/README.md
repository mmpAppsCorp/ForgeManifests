# Suburban Church | Map Pack (Walled)

Suburban Church | Map Pack delivers a large, modern place of worship designed for contemporary stories, investigations, community-centered scenes, or dramatic turning points set outside dense urban cores.

This map presents a spacious suburban church layout with clean architecture, wide interiors, and practical modern design—ideal for services, gatherings, town meetings, counseling sessions, or tense moments that unfold behind a calm public façade.

Whether used as a peaceful sanctuary, a community hub, or the backdrop for secrets and conflict, Suburban Church | Map Pack provides a flexible and believable setting for modern campaigns across many genres.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Suburban Church

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
