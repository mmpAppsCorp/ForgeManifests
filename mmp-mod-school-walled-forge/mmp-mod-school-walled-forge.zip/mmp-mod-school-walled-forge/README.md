# Modern School | Map Pack (Walled)

Modern School | Map Pack delivers a flexible, contemporary educational setting ideal for investigations, social encounters, emergencies, or everyday slice-of-life scenes in modern campaigns.

This pack includes a fully realized school environment, featuring standard Classrooms, a Computer Classroom, Science Classroom, Gymnasium, Bathrooms, Cafeteria, Library, and Administrative Offices—providing natural spaces for classes in session, after-hours activity, lockdown scenarios, or unexpected crises.

Whether the school is a quiet backdrop for roleplay, the center of a mystery, or the site of a high-stakes incident, Modern School | Map Pack offers a grounded and versatile location ready for play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- School
  - Classroom
  - Computer Classroom
  - Science Classroom
  - Gymnasium
  - Bathrooms
  - Cafeteria
  - Library
  - Offices

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
