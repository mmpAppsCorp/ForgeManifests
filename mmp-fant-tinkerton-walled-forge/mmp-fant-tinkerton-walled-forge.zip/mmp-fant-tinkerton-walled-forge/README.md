# Tinkerton - Gnome Village | Map Pack (Walled)

Tinkerton – Gnome Village | Map Pack delivers a whimsical, clockwork-infused settlement perfect for inventive gnomes, eccentric engineers, and campaigns where curiosity, explosions, and clever solutions reign supreme.

This pack features Tinkerton, a fully realized gnome village built around tinkering, experimentation, and arcane ingenuity. At its heart is the Master Tinkerer’s Workshop, spanning two levels of gears, benches, and half-finished contraptions, alongside a Siege Weapon Shop where oversized ideas meet questionable safety standards. A lively two-level Pub provides a social hub for inventors to argue theory over drinks.

Residential and specialist buildings take the form of distinctive mushroom houses, each tailored to its occupant: Alchemist, Astronomer, Clock Maker, Mage, and Traveller dwellings offer unique layouts ideal for roleplay, investigations, or unexpected mishaps.

Whether your party is seeking experimental weapons, arcane inventions, strange NPCs, or the unintended consequences of gnomish brilliance, Tinkerton – Gnome Village | Map Pack provides a charming and chaotic setting ready for adventure.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tinkerton - Gnome Village
  - Master Tinkerer's Workshop - two levels
  - Siege Weapon Shop
  - Pub - two levels
  - Alchemist's Mushroom House
  - Astronomer's Mushroom House
  - Clock Maker's Mushroom House
  - Mage's Mushroom House
  - Traveller's Mushroom House

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
