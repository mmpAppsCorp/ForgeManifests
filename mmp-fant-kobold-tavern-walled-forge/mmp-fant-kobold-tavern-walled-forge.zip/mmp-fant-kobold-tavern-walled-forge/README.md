# Kobold Tavern | Map Pack (Walled)

Kobold Tavern | Map Pack delivers a chaotic, trap-laden underground tavern perfectly suited for cunning kobolds, sneaky intrigue, and perilous close-quarters encounters.

This pack features a five-level, twisted tavern complex, built with cramped passages, irregular rooms, and vertical connections that reflect kobold ingenuity and paranoia. The layout is ideal for ambushes, хит-and-run tactics, hidden crawlspaces, and improvised defenses, making every level feel dangerous and unpredictable.

Whether used as a kobold social hub, a monster-infested dungeon, or a deceptively welcoming stop that turns deadly fast, Kobold Tavern | Map Pack provides a uniquely hostile environment that rewards clever play and punishes careless adventurers.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Kolbold Tavern - five twisted levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
