# Nuclear Power Plant | Map Pack (Walled)

Nuclear Power Plant | Map Pack delivers a highly detailed modern industrial facility designed for tense investigations, disaster scenarios, sabotage missions, espionage operations, or high-stakes containment breaches.

This pack features a complete nuclear power generation complex, including a fortified Control Complex with dedicated security and emergency response areas, perfect for command decisions under pressure or last-minute crisis management. The Reactor Building spans three levels and includes both normal operating and refueling configurations, allowing you to stage routine inspections, covert infiltrations, or catastrophic failures.

Power generation continues through the massive Turbine Hall, complete with turbines and basement-level condensers, while the Spent Fuel Building provides a hazardous and heavily guarded environment ideal for dangerous objectives or moral dilemmas. The exterior Switchyard rounds out the facility, offering exposed high-voltage infrastructure for sabotage, firefights, or evacuation scenes.

Whether your story involves preventing a meltdown, uncovering a conspiracy, or surviving an industrial disaster, Nuclear Power Plant | Map Pack provides a realistic and immersive setting for modern and near-future campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Nuclear Power Plant
  - Control Complex - security & emergency center
  - Reactor Building - three levels with normal and refueling configurations
  - Turbine Hall - turbines with condensers in the basement
  - Spent Fuel Building
  - Switchyard

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
