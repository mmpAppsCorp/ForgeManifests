# Museum | Map Pack (Walled)

Museum | Map Pack delivers a sprawling cultural landmark ideal for investigations, heists, historical mysteries, high-profile galas, or chaos erupting in a public space.

This pack features a fully realized museum complex with multiple themed exhibition halls spread across ground and upper levels. From priceless artifacts and glittering jewel displays to classical paintings, statues, and natural history exhibits, each area offers distinct layouts, sightlines, and narrative hooks. A detailed lobby anchors the experience, complete with entrances, security checkpoints, a gift shop, and coffee area—perfect for public scenes or the moment everything goes wrong.

An Empty Hall is also included on both levels, giving you full freedom to customize special exhibitions, secret events, or campaign-specific installations.

Whether the museum is a place of learning, a battlefield for a daring theft, or the backdrop for a dramatic confrontation, Museum | Map Pack provides a versatile and immersive setting for modern and historical campaigns alike.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Museum
  - Archeology Hall - ground & upper
  - Jewels Hall - ground & upper
  - Lobby - entrance, security, gift shop, coffee
  - Mona Lisa
  - Natural History Hall - ground & upper
  - Painting Hall - ground & upper
  - Statues Hall - ground & upper
  - Empty Hall - ground & upper

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
