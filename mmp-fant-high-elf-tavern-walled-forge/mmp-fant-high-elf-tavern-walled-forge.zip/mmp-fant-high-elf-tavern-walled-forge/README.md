# 13 High Elf Tavern | Map Pack (Walled)

High-Elf Tavern | Map Pack delivers an elegant, refined social venue designed for diplomacy, intrigue, and high-society encounters rather than rowdy tavern brawls.

This pack features a High-Elf Tavern presented across two levels, emphasizing fine dining, graceful architecture, and an atmosphere of cultured restraint. Expect polished halls, private seating areas, and spaces well suited for secret negotiations, noble gatherings, romantic intrigue, or subtle political maneuvering.

Whether used as a neutral ground for rival factions, a meeting place for elven nobility, or a serene contrast to rougher inns and taverns, High-Elf Tavern | Map Pack provides a sophisticated setting ideal for fantasy campaigns that value elegance as much as danger.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- High-Elf Tavern - more fine dining than tavern, two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
