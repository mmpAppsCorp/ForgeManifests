# Viking Village - Longhouse | Map Pack (Walled)

Viking Village – Longhouse | Map Pack delivers the cultural and social heart of a Norse settlement, ideal for feasts, councils, ceremonies, and dramatic confrontations.

This pack features a detailed two-level Longhouse, with a great hall designed for gatherings, storytelling, and political intrigue, and an upper level suited for private quarters, storage, or secret meetings. The layout supports both everyday village life and high-stakes narrative moments.

All land maps are provided in both summer and winter environments, allowing you to shift the mood from lively hearth-fires to snowbound isolation.

Whether serving as a chieftain’s hall, a communal home, or the center of village power, Viking Village – Longhouse | Map Pack provides an authentic and flexible setting for Viking-themed adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Longhouse - two levels

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
