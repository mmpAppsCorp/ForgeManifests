# Summer Camp - Amphitheatre | Map Pack (Walled)

Summer Camp – Amphitheatre | Map Pack delivers an outdoor gathering space ideal for campfire meetings, performances, ceremonies, confrontations, or eerie nighttime encounters.

This pack features a detailed open-air Amphitheatre with both the main seating area and the space beneath the stage, allowing scenes to move seamlessly between public events and hidden or restricted areas. It works equally well for wholesome daytime assemblies or tense after-dark moments where secrets, rituals, or danger lurk just out of sight.

Whether used for speeches, talent shows, cult-like ceremonies, or dramatic ambushes, Summer Camp – Amphitheatre | Map Pack provides a flexible and atmospheric location for modern, horror, or adventure-focused campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Amphitheatre - ground & underneath

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
