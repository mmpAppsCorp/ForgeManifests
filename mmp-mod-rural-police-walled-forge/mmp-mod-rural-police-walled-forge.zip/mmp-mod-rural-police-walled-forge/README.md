# Rural Police Station | Map Pack (Walled)

Rural Police Station | Map Pack delivers a compact, isolated law-enforcement location ideal for small-town investigations, tense standoffs, or stories where backup is far away and authority is thin.

This pack features a Rural Police Station, including the main station interior and the rooftop, capturing the feel of a lightly staffed outpost serving a wide area. Offices, holding spaces, and functional work areas provide a grounded setting for interrogations, overnight lockups, or quiet moments before trouble arrives.

Whether your scenario involves a local mystery, a corruption plot, or a desperate defense against escalating threats, Rural Police Station | Map Pack offers a focused and atmospheric setting perfect for modern campaigns set far from the city.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Rural Police Station - station, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
