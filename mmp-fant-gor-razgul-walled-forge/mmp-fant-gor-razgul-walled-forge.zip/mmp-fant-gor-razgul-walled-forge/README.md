# Gor Razgul - Orc Village | Map Pack (Walled)

Gor Razgul – Orc Village | Map Pack delivers a brutal, lived-in stronghold built for warbands, raiders, and harsh survival on the edge of civilization. This fortified orc settlement is ideal for tribal politics, violent power struggles, prisoner rescues, or full-scale assaults.

The village features a complete network of functional and ceremonial locations, including Barracks, a Chieftain’s Tent, Guard Tower (lower and upper levels), House Tents, a rough-and-ready Pub, Shaman’s Tent, Blacksmith Tent, Slave Pit, and expansive Training Grounds. Each area reflects the practical, martial culture of an orc society built around strength and dominance.

All locations are provided in arctic, desert, and grassland environments, allowing the village to be placed in frozen wastelands, scorched badlands, or open plains without modification.

Whether used as an enemy stronghold, a volatile ally settlement, or the center of a tribal conflict, Gor Razgul – Orc Village | Map Pack provides a flexible and atmospheric setting for savage encounters and high-stakes fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Gor Razgul - Orc Village
  - Barracks
  - Chieftain Tent
  - Guard Tower - lower & upper
  - House Tent
  - Pub
  - Shaman Tent
  - Blacksmith Tent
  - Slave Pit
  - Training Grounds
  - All in arctic, desert & grassland environments

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
