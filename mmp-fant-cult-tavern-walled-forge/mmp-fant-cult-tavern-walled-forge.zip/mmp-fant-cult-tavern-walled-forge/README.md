# 11 Wilderness Taverns | Map Pack (Walled)

Cult Tavern | Map Pack delivers a secluded and unsettling mountain hideaway perfect for secret meetings, forbidden rituals, cult investigations, or horror-tinged fantasy encounters.

This pack features a three-level tavern concealed deep in the mountains, blending the appearance of a remote roadside stop with darker purposes hidden beneath the surface. From the public-facing tavern space to increasingly secretive and ominous lower levels, the location is ideal for uncovering conspiracies, staging ambushes, or revealing what truly happens behind closed doors.

Whether used as a covert cult headquarters, a front for dark worship, or a seemingly harmless tavern with a disturbing secret, Cult Tavern | Map Pack provides a tense and atmospheric setting for mystery-driven and horror-inspired campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Cult Tavern - hidden in the mountains, three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
