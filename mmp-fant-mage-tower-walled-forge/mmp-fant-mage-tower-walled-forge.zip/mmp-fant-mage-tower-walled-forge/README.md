# Fantasy Mage Towers  | Map Pack  (Walled)

Fantasy Mage Towers | Map Pack delivers a collection of iconic arcane strongholds designed for wizard duels, dark rituals, forbidden research, and high-stakes magical intrigue.

This pack features Good, Evil, and Necromancer Mage Towers, each mapped across multiple vertical levels—including ground, lower, main, upper, stairways, and rooftops—allowing encounters to unfold through laboratories, summoning chambers, libraries, and battlements. Upper levels are provided in both day and night configurations, supporting shifting moods from scholarly calm to ominous ritual.

To place these towers anywhere in your world, the ground level is included in a wide range of environments: arctic, cloud, desert, forest, island, and mountain, making them equally suited to remote wilderness, floating realms, or hostile terrain.

Whether the tower belongs to a benevolent archmage, a corrupted sorcerer, or a necromancer plotting in isolation, Fantasy Mage Towers | Map Pack provides flexible, atmospheric locations ready for exploration, confrontation, and magical catastrophe.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Good, Evil & Necromancer Mage Towers
  - Ground, stairs, lower, main, upper, and roof levels
  - Upper layers in day and night configurations
  - Ground level in arctic, cloud, desert, forest, island, and mountain environments

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
