# Summer Camp - Admin Building | Map Pack (Walled)

Summer Camp – Admin Building | Map Pack provides a central hub for organization, authority, and secrets within a classic outdoor camp setting—perfect for mystery, horror, coming-of-age adventures, or modern survival scenarios.

This pack features a detailed Admin Building, including both the ground level and roof, capturing offices, meeting areas, records storage, and staff-only spaces where decisions are made and problems are quietly buried. The rooftop adds vertical play for surveillance, escapes, or late-night confrontations under the stars.

Whether it serves as a place of safety, a nerve center during a crisis, or the setting for something far more unsettling, Summer Camp – Admin Building | Map Pack delivers a versatile and story-driven location ready to anchor your camp-based encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Admin Building - ground & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
