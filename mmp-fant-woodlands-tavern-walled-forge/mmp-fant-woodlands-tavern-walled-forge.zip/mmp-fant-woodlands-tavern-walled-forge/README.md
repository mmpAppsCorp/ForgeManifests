# Woodland Tavern | Map Pack (Walled)

Woodland Tavern | Map Pack delivers a rustic forest hideaway ideal for roadside encounters, secret meetings, monster hunts, or quiet roleplay moments far from civilization.

This pack features a two-level Woodland Tavern nestled among the trees, combining a warm, welcoming common area with private upper-level spaces for guests, staff, or hidden dealings. The natural surroundings and timber construction make it equally suited for peaceful rests, tense negotiations, or sudden ambushes.

Whether used as a trusted waypoint for travelers, a ranger’s refuge, or a tavern with secrets buried beneath the forest canopy, Woodland Tavern | Map Pack provides a flexible and atmospheric setting for fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Woodland Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
