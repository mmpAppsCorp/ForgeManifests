# Modern Gifted School | Map Pack (Walled)

Gifted School | Map Pack delivers a secluded academic complex designed for extraordinary students, secret training programs, and stories where education and danger collide.

This pack presents a fully realized school campus built to balance everyday learning with hidden purposes. Bright classrooms and a welcoming library occupy the Ground Floor, while dedicated Dorm and Teacher floors support student life and faculty oversight. Beneath the surface, the school reveals its true nature—maintenance corridors, laboratories, training spaces, and specialized facilities hidden from the outside world.

The Basement expands into pools, labs, exercise areas, and computer rooms, while the Sub-Basement houses restricted chambers reserved for developing truly exceptional abilities. A Rooftop level provides space for drills, confrontations, or dramatic reveals under open skies.

Whether used as a prestigious academy, a covert training facility, or the epicenter of escalating threats, Gifted School | Map Pack offers a versatile and immersive setting for modern, superhero, sci-fi, or high-stakes campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Gifted School
  - Ground Floor - classrooms & library
  - Dorm Floor
  - Teacher's Floor
  - Basement - maintenance, pool, lab, exercise, computer lab
  - Sub-Basement - rooms for training truly special gifts
  - Rooftop

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
