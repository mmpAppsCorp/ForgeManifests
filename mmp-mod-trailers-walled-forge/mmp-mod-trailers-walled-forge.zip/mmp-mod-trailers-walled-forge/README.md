# Trailers, Trucks & RVs | Map Pack (Walled)

Trailers, Trucks & RVs | Map Pack delivers a versatile collection of mobile and roadside locations perfect for road-trip adventures, criminal investigations, survival scenarios, or gritty modern encounters on the move.

This pack includes a detailed range of Semi-Trucks, featuring a cab plus seven distinct trailer configurations, along with multiple Trailer Home layouts and fully mapped RVs. Each RV includes interior and roof views, with a specialized mobile drug lab variant ideal for clandestine operations or law-enforcement raids. A unique Demon Hunter’s Trailer adds character and narrative flavor, serving as a mobile base, hideout, or supernatural command center.

Whether your story involves long-haul trucking, nomadic lifestyles, smuggling operations, or life on the edge of the highway, Trailers, Trucks & RVs | Map Pack provides flexible, story-driven environments ready for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Semi-Trucks - cab plus seven trailer configurations
- Trailer Home - three configurations
- RV - interior, roof, mobile drug lab
- Demon Hunter's Trailer
- Seven Environments - to park your trailers, trucks & RVs

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
