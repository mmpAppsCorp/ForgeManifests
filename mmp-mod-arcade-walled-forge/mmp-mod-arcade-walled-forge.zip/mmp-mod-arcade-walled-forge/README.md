# Retro Video Arcade | Map Pack (Walled)

Retro Video Arcade | Map Pack delivers a vibrant, neon-lit gaming hall perfect for modern campaigns, nostalgia-driven adventures, teen mysteries, or urban investigations.

This pack features a classic arcade environment filled with rows of cabinets, prize counters, seating areas, and back-of-house spaces—ideal for social encounters, covert meetings, after-hours break-ins, or scenes where something strange lurks behind the flashing screens.

Whether the arcade is a harmless hangout, a front for illegal activity, or the unexpected center of a larger mystery, Retro Video Arcade | Map Pack provides a flexible and atmospheric setting ready for play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Retro Video Arcade

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
