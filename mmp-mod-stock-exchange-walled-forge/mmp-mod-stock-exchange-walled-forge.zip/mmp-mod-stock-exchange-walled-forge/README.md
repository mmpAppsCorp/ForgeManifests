# Stock Exchange | Map Pack (Walled)

Stock Exchange | Map Pack delivers a high-energy financial hub designed for modern thrillers, corporate espionage, market manipulation plots, protests, or high-stakes action scenes.

This pack features a detailed Stock Exchange complex, including a bustling Trading Floor, Bond Floor, secure Basement areas, and a Rooftop—each offering distinct opportunities for tense negotiations, covert operations, or sudden chaos as fortunes rise and fall.

Whether your scenario involves insider trading, financial collapse, hostage situations, or a dramatic showdown above the city skyline, Stock Exchange | Map Pack provides a versatile and cinematic setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Stock Exchange - trading floor, bond floor, basement, roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
