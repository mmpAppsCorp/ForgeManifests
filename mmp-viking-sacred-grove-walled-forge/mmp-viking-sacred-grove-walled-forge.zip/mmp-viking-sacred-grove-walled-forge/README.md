# Viking Village - Sacred Grove | Map Pack (Walled)

Viking Village – Sacred Grove | Map Pack presents a secluded spiritual site where Norse tradition, ritual, and myth take center stage—perfect for ceremonies, omens, sacrifices, secret meetings, or supernatural encounters.

This pack features a Sacred Grove, centered around ancient trees, standing stones, and ritual clearings that serve as a place of worship and communion with the gods. It works equally well for solemn blessings, tense negotiations under divine watch, or darker rites performed beyond the eyes of the village.

All land maps are provided in summer and winter environments, allowing you to shift the tone from vibrant seasonal rites to stark, frozen ceremonies beneath bare branches.

Whether used as a holy site, a place of prophecy, or the setting for a pivotal mythic event, Viking Village – Sacred Grove | Map Pack adds atmosphere, tradition, and narrative weight to your Viking-era adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Sacred Grove

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
