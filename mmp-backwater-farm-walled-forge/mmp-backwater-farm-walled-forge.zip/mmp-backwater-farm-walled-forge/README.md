# Backwater Town - Farm | Map Pack (Walled)

Backwater Town – Farm | Map Pack delivers a rugged frontier homestead ideal for smuggling operations, hidden meetings, survival stories, or life on the edge of civilization.

This pack features a two-level Farm layout that can serve as a working homestead, a secret base of operations, or an isolated hideout far from authority. The structure supports a wide range of narrative uses—from legitimate agriculture to illicit dealings concealed behind a quiet rural façade.

All maps are provided in arctic, desert, and grassland environments, and each version includes both furnished and unfurnished layouts, allowing you to tailor the location to active use, abandonment, or covert occupation.

Whether it’s a peaceful stop along a dusty trade route or the setting for betrayal, ambush, or discovery, Backwater Town – Farm | Map Pack offers a flexible and atmospheric rural location for frontier and sci-fi backwater campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Farm - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
