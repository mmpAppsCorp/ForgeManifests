# Redrum Masonic Lodge | Map Pack (Walled)

Redrum Masonic Lodge | Map Pack delivers a sinister and atmospheric lodge setting ideal for occult investigations, secret societies, ritual horror, and psychological terror.

This pack centers on a Masonic Lodge presented in multiple disturbing variations, transforming a once-respectable meeting hall into a nexus of dark symbolism and supernatural threat. Scenes range from an unassuming normal lodge to increasingly nightmarish configurations featuring forbidden statues, execution chambers, occult emblems, and reality-warping phenomena.

With versions including ritual spaces, void portals, infernal imagery, and unsettling anomalies, Redrum Masonic Lodge | Map Pack is perfectly suited for slow-burn horror, cult conspiracies, and campaigns where hidden power lurks behind respectable facades.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Masonic Lodge
  - Normal
  - Cthulhu Statue
  - Dragon Statue
  - Emblem
  - Execution
  - Satanic
  - Scary Snowman (yes, you read that right!)
  - Talking Flame
  - The Eye
  - Torture
  - Void Portal

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
