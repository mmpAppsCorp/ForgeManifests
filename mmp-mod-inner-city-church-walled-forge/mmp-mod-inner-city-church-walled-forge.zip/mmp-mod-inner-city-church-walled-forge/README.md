# Inner-City Church | Map Pack (Walled)

Inner-City Church | Map Pack delivers a grounded urban place of worship ideal for modern campaigns involving investigations, community drama, social unrest, or moral crossroads.

This pack features a multi-level inner-city church with a realistic layout, including public worship spaces, administrative areas, and private rooms, all reflecting the character of a working church embedded in a dense urban neighborhood. Beneath the sanctuary lies a fully detailed soup kitchen, providing a powerful secondary setting for humanitarian efforts, covert meetings, or tense encounters away from public view.

Whether used as a sanctuary, a hub of community aid, a hiding place, or the center of a developing crisis, Inner-City Church | Map Pack offers a versatile and atmospheric location for modern storytelling.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Inner-City Church - three levels plus a soup kitchen in the basement

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
