# Biker Clubhouse | Map Pack (Walled)

Biker Clubhouse | Map Pack delivers a gritty, closed-door hangout perfect for outlaw gangs, criminal conspiracies, underground deals, or law-enforcement raids.

This pack features a fully realized Biker Clubhouse spread across multiple levels, including a ground-floor club area built for meetings and parties, an upper level for private rooms and leadership space, and a basement ideal for storage, secret activities, or darker operations. The layout supports tense negotiations, sudden violence, and high-stakes infiltration.

Whether used as a tight-knit brotherhood’s headquarters, a front for illegal business, or the target of a dramatic bust, Biker Clubhouse | Map Pack provides a raw and atmospheric setting for modern and crime-focused campaigns.

Whether your adventure involves undercover stings, heist planning, gang conflicts, missing-person investigations, or neon-soaked nightlife vignettes, Modern Adult Entertainment | Map Pack gives you immersive modern environments ready for any storyline.

---

## Included Maps

This pack contains the following locations:

- Biker Clubhouse - club, upper, basement

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
