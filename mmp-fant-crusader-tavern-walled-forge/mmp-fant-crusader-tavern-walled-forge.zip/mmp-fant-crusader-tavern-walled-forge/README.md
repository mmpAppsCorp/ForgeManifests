# Fantasy Crusader Tavern | Map Pack (Walled)

Crusader Tavern | Map Pack delivers a fortified roadside tavern built to serve soldiers, pilgrims, and mercenaries moving through contested lands.

This pack features a four-level Crusader Tavern, combining the functions of an inn, tavern, and defensive stronghold. Thick stone walls, heavy timber construction, and practical layouts make it ideal for military gatherings, tense negotiations, religious factions, or violent confrontations that break out after nightfall.

Whether used as a neutral meeting ground, a rally point for holy orders, or a stronghold under siege, Crusader Tavern | Map Pack provides a rugged, story-rich location suited for medieval and fantasy campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Crusader Tavern - four levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
