# Cathedral | Map Pack (Walled)

Cathedral | Map Pack delivers a grand medieval religious landmark ideal for political intrigue, holy ceremonies, secret cults, sieges, assassinations, or dramatic last stands beneath vaulted stone.

This pack features a massive Medieval Cathedral mapped across four detailed levels, capturing soaring naves, side chapels, clergy spaces, and elevated walkways, along with an extensive Catacombs level hidden beneath the structure—perfect for forbidden rituals, hidden tombs, smuggler routes, or ancient secrets.

Whether serving as a center of faith, a symbol of power, or the stage for heresy and rebellion, Cathedral | Map Pack provides a richly atmospheric setting for fantasy campaigns that demand scale, gravitas, and mystery.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Medieval Cathedral - four levels plus catacombs

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
