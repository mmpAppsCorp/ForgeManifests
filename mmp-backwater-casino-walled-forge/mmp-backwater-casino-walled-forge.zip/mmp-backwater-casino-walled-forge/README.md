# Backwater Town - Casino | Map Pack (Walled)

Backwater Town – Casino | Map Pack delivers a seedy gambling hall perfect for shady deals, high-stakes games, criminal intrigue, and sudden outbreaks of violence in the fringe of civilization.

This pack features a two-level Casino, including the main gaming floor and upper areas ideal for VIP rooms, back offices, or illicit operations. Whether it’s a den of chance, a criminal front, or neutral ground for dangerous negotiations, the layout supports both social tension and rapid escalation.

All maps are provided in arctic, desert, and grassland environments, and each version includes furnished and unfurnished variants, giving you full control over tone, population, and narrative use.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Casino - two levels

All maps are provided in arctic, desert, and grassland environments.
All maps come furnished and unfurnished.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
