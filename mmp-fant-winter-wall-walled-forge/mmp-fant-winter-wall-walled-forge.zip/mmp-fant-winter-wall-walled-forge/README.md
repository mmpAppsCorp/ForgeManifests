# Winter Wall  | Map Pack  (Walled)

Winter Wall | Map Pack delivers a monumental fortified barrier designed for epic fantasy campaigns, border defenses, siege warfare, and high-stakes confrontations at the edge of civilization.

This pack features a Massive Wall presented in both arctic and stone variants, complete with a two-level outpost built directly into the structure. Explore guarded passages through the wall, elevated walkways along the top, and defensive positions equipped with catapults and elevators for vertical movement and dramatic encounters.

Multiple configurations are included, featuring versions with teleportation circles as well as fully mapped areas on both sides of the wall, making it ideal for patrols, breaches, negotiations, or large-scale assaults.

Whether your party is defending the realm, sneaking across a forbidden border, or launching a full siege, Winter Wall | Map Pack provides a powerful and flexible setting for cold, brutal fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Massive Wall
  - Arctic & Stone versions
  - Two level outpost built adjacent to the wall
  - Passage through the wall
  - Top of wall with elevators
  - Top of wall with catapults
  - Versions with teleportation circles
  - Other side of wall!!

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
