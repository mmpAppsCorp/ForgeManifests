# Bounty Hunter Spaceships | Map Pack (Walled)

Bounty Hunter Spaceships | Map Pack delivers a gritty collection of purpose-built spacecraft designed for manhunts, captures, smuggling interdictions, and high-risk pursuits across the stars.

This pack features three distinct Bounty Hunter Ships—Baron, Bloodhound, and The Slaver—each mapped with multiple internal levels that emphasize detention areas, crew quarters, command spaces, and utilitarian layouts suited for tracking, capturing, and transporting dangerous targets.

All ships are provided across a wide range of environments, including landed arctic, desert, grass, metal, and pavement settings, as well as dynamic flying configurations in open sky and deep space. These variants make it easy to deploy the same vessel in frontier worlds, urban ports, or active space chases.

Whether your campaign focuses on ruthless professionals, reluctant antiheroes, or the hunted trying to escape, Bounty Hunter Spaceships | Map Pack provides versatile, atmospheric maps built for tense sci-fi encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bounty Hunter Ships
  - Baron - five levels
  - Bloodhound - three levels
  - The Slaver - three levels

Provided in six environments
  - Landed Arctic
  - Landed Desert
  - Landed Grass
  - Landed Metal
  - Landed Pavement
  - Flying Space
  - Flying Sky

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
