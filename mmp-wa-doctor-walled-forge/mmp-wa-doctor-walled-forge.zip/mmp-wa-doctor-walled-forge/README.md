# Western Adventures - Doctors | Map Pack (Walled)

Western Adventures – Doctors Offices | Map Pack delivers authentic frontier medical settings ideal for gritty survival stories, gunfight aftermaths, epidemics, and moral dilemmas on the edge of civilization.

This pack includes both a Large Doctor’s Office and a Small Doctor’s Office, each presented in summer and winter settings. From modest one-room practices to better-equipped town clinics, these maps capture the harsh realities of frontier medicine—bloodstained exam tables, sparse equipment, and the constant tension between life and death.

Whether your story involves emergency surgery after a shootout, questionable medical ethics, secret experiments, or desperate townsfolk seeking help, Western Adventures – Doctors Offices | Map Pack provides a grounded, atmospheric location perfect for Wild West campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Large Doctor Office / Small Doctor Office - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
