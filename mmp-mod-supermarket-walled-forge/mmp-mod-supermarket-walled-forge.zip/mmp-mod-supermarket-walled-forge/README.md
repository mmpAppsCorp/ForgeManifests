# Supermarket | Map Pack (Walled)

Supermarket | Map Pack provides a versatile modern retail environment ideal for everyday encounters, tense confrontations, late-night heists, zombie outbreaks, or undercover surveillance.

This pack includes a fully detailed Supermarket interior, featuring wide aisles, checkout lanes, storage areas, and back-of-house spaces that support both roleplay and tactical movement. The rooftop map adds vertical gameplay options, perfect for chases, overwatch positions, emergency extractions, or improvised entrances.

Whether your scene involves a routine shopping trip gone wrong, a desperate last stand among the shelves, or a covert operation after hours, Supermarket | Map Pack delivers a familiar setting with plenty of opportunities for drama and action.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Supermarket - store & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
