# Viking Village - Stave Church | Map Pack (Walled)

Viking Village – Stave Church | Map Pack brings a sacred and atmospheric landmark to your Norse settlements, perfect for religious rites, political gatherings, or tense moments of spiritual conflict.

This pack features a traditional Stave Church, rendered with distinctive wooden architecture, carved details, and a solemn interior suited for worship, ceremonies, or secret meetings. Whether it serves as the spiritual heart of the village, a place of refuge, or the setting for omens and divine intervention, the church provides a powerful narrative focal point.

All land maps are provided in both summer and winter environments, allowing the Stave Church to seamlessly fit into seasonal play—from bright festival days to snowbound rites beneath dark skies.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Stave Church

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
