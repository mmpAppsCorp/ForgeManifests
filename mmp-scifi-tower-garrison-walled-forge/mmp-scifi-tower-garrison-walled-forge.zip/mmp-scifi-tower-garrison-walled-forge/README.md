# SciFi Tower Garrison | Map Pack (Walled)

SciFi Tower Garrison | Map Pack delivers a versatile, vertical military installation designed for planetary defense, rapid deployment, and high-security operations in science-fiction campaigns.

This pack centers on a modular Tower Garrison, divided into specialized Air, Water, and Land towers. Each tower features purpose-built hanger decks, control centers, stabilization systems, and engineering levels, supporting everything from aircar patrols and watercraft launches to heavy ground vehicles. These structures work equally well as frontline fortresses, orbital defense relays, or authoritarian strongholds.

To expand flexibility, a full suite of Generic Decks is included—ranging from bridges, cannon decks, and shield control rooms to medical bays, prisons, workshops, and customizable blank decks. Whether you’re staging a military assault, infiltration mission, rebellion breakout, or command-level drama, SciFi Tower Garrison | Map Pack provides a scalable and highly adaptable sci-fi military environment.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tower Garrison
  - Air Tower
    - Air car hanger deck and control center
    - Air stabilizers and control deck
    - Air engineering deck
  - Water Tower
    - Watercraft hanger deck and control center
    - Water stabilizer and control deck
    - Water engineering deck
  - Land Tower
    - Vehicle hanger deck
    - Land engineering deck
  - Generic Decks
    - Blank Deck (for you to customize)
    - Bridge Deck
    - Cannon Deck
    - Captain's Deck
    - Crew Quarters Deck
    - Hanger Deck
    - Hanger Control Deck
    - Kitchen Deck
    - Medical Deck
    - Mess Deck
    - Officer's Quarters Deck
    - Prison Deck
    - Security Deck
    - Shield Deck
    - Shield Control Deck
    - Workshop Deck

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
