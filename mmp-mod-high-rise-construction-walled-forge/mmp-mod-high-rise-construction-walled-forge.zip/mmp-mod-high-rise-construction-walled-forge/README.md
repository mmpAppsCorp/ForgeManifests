# High-Rise Construction | Map Pack (Walled)

High-Rise Construction | Map Pack delivers a vertical construction site ideal for modern action, crime, disaster, or urban thriller scenarios where danger comes from both height and unfinished infrastructure.

This pack presents a multi-stage high-rise under construction, featuring ground, middle, and top levels filled with exposed steel, incomplete floors, temporary access points, and heavy equipment. These environments are perfect for tense firefights, stealth infiltrations, sabotage missions, rescues, or catastrophic accidents where footing is uncertain and visibility is wide open.

Whether your story involves corporate espionage, organized crime, emergency response, or a high-stakes showdown above the city streets, High-Rise Construction | Map Pack provides a dramatic, flexible setting built for vertical gameplay and cinematic encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- High-Rise Construction - ground, middle & top levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
