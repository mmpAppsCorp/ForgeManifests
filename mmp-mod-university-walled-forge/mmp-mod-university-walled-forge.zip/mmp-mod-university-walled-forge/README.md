# Modern University | Map Pack (Walled)

Modern University | Map Pack delivers a fully realized higher-education campus designed for contemporary investigations, student-life drama, conspiracies, protests, or high-stakes incidents that unfold across academic grounds.

This pack features a complete university environment, including a central Campus Courtyard, multiple Classrooms and Lecture Halls, Student Dorms, and shared spaces like the Library and Student Lounge—ideal for social scenes, secret meetings, or sudden chaos between classes. Academic and administrative areas such as Professor’s Offices, Student Labs, and Administration offices support research-focused plots, cover-ups, or institutional intrigue.

Whether your scenario centers on campus politics, experimental research gone wrong, undercover operations, or everyday student life disrupted by extraordinary events, Modern University | Map Pack provides a flexible and immersive setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- University
  - Campus Courtyard
  - Classrooms
  - Dorms
  - Lecture Hall
  - Library
  - Professor's Office
  - Student Lab
  - Student Lounge
  - Administration

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
