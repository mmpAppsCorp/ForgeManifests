# Modern Car Wash | Map Pack (Walled)

Car Wash | Map Pack delivers a modern roadside location ideal for investigations, surveillance, ambushes, or tense encounters that unfold in plain sight.

This pack features a detailed Car Wash environment, including drive-through wash lanes, equipment areas, and surrounding exterior space—perfect for scenes involving stakeouts, chases, covert meetings, or crimes interrupted mid-cycle.

Whether used as a mundane everyday location, a front for illicit activity, or the backdrop for a sudden confrontation, Car Wash | Map Pack provides a flexible and believable setting for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Car Wash

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
