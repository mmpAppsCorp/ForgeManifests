# Bird of Prey | Map Pack (Walled)

Bird of Prey | Map Pack delivers a compact, aggressive starship environment designed for ambushes, covert operations, tense diplomacy, and sudden violence in spacefaring campaigns.

This pack includes detailed maps of the Bird of Prey’s Command Deck, Crew Deck, and a combined Diplomacy Deck & Shuttle Bay, blending ceremonial spaces with military readiness. Tight corridors, command stations, crew quarters, and launch facilities support scenes ranging from hostile negotiations and prisoner exchanges to boarding actions and rapid strike deployments.

Whether used as a fearsome enemy vessel, an uneasy ally’s ship, or a captured prize, Bird of Prey | Map Pack provides a focused, story-driven setting ideal for fast-paced sci-fi encounters and high-stakes confrontations.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bird of Prey
  - Command Deck
  - Crew Deck
  - Diplomacy Deck, Shuttle Bay

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
