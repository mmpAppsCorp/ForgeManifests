# Redrum Haunted House | Map Pack (Walled)

Redrum Haunted House | Map Pack delivers a chilling residential location designed for horror, mystery, psychological thrillers, and supernatural investigations.

This pack features a fully realized Haunted House presented in two distinct states: empty and unsettlingly wrong. Each level—Attic, Basement, Ground Floor, and Upper Floor—can be used as a seemingly abandoned structure or transformed into a nightmarish environment filled with ominous details, distorted spaces, and creeping dread.

Whether the house is the site of a haunting, a cult’s ritual ground, a cursed property, or a slow-burn descent into terror, Redrum Haunted House | Map Pack provides a flexible and atmospheric setting ready for suspenseful exploration and horrific revelations.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Haunted House
  - Attic - empty & scary
  - Basement - empty & scary
  - Ground Level - empty & scary
  - Upper Level - empty & scary

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
