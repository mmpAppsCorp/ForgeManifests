# Imperial Battle Cruiser | Map Pack (Walled)

Imperial Battle Cruiser | Map Pack delivers a massive capital ship environment designed for space opera campaigns centered on military power, authoritarian regimes, and large-scale conflict.

This pack presents a fully realized Imperial Battle Cruiser, broken into distinct structural sections—Head, Upper Body, and Lower Body—allowing you to stage encounters across command areas, internal corridors, and the vast armored superstructure of the ship. The segmented layout makes it ideal for boarding actions, sabotage missions, prison breaks, or tense confrontations with high-ranking officers.

Whether serving as the flagship of a tyrannical empire, a looming threat over occupied worlds, or the setting for a daring infiltration, Imperial Battle Cruiser | Map Pack provides an imposing and versatile backdrop for epic sci-fi adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Imperial Battle Cruiser
  - Head
  - Lower Body
  - Upper Body

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
