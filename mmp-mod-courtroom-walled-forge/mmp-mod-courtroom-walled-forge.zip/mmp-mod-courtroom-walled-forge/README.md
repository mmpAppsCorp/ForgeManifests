# Courtroom | Map Pack (Walled)

Courtroom | Map Pack delivers a formal legal setting ideal for trials, interrogations, high-stakes testimony, political drama, or scenes where justice is contested rather than guaranteed.

This pack features a detailed modern courtroom layout, including the judge’s bench, witness stand, jury box, prosecution and defense tables, public seating, and supporting circulation space—perfect for tense legal proceedings, dramatic reveals, or sudden disruptions.

Whether your scenario centers on lawful order, corruption behind the scenes, or a trial that spirals into chaos, Courtroom | Map Pack provides a grounded, realistic environment ready for serious roleplay and decisive moments.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Courtroom

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
