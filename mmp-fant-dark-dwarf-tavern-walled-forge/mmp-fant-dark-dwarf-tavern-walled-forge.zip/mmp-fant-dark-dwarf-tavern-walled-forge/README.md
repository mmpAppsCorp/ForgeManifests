# Dark Dwarf Tavern | Map Pack (Walled)

Dark Dwarf Tavern | Map Pack delivers a grim, fortified underground tavern carved from stone and iron—perfect for brutal negotiations, secret war councils, or encounters steeped in shadow and fire.

This pack features a Dark Dwarf Tavern complex spanning multiple functional levels, including a heavily fortified tavern floor, an active forge level filled with heat, tools, and industry, and dedicated war levels designed for planning, training, and mustering forces. The layout emphasizes defensibility, claustrophobic corridors, and a harsh industrial atmosphere.

Whether serving as a clan stronghold, a neutral meeting ground for dangerous factions, or a frontline command post beneath the earth, Dark Dwarf Tavern | Map Pack provides a powerful setting for dark fantasy campaigns where steel, fire, and ambition rule.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Dark Dwarf Tavern - tavern, forge, war levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
