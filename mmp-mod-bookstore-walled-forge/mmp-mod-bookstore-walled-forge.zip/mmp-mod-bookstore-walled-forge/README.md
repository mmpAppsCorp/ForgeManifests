# Bookstore | Map Pack (Walled)

Bookstore | Map Pack delivers a modern multi-level retail space ideal for investigations, clandestine meetings, academic intrigue, or quiet moments that suddenly turn dangerous.

This pack features a detailed two-floor Bookstore complete with shelving, reading areas, counters, storage spaces, and a Rooftop level that adds vertical gameplay options for surveillance, escapes, or confrontations.

Whether used as a peaceful neighborhood shop, a front for hidden dealings, or the setting for a dramatic incident, Bookstore | Map Pack provides a flexible and atmospheric location for modern campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Bookstore - two floors & roof

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
