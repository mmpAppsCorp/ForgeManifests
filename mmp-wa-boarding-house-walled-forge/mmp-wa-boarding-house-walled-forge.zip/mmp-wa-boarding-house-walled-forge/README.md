# Western Adventures - Boarding House | Map Pack (Walled)

Western Adventures | Boarding Houses delivers authentic frontier lodging ideal for character introductions, quiet investigations, tense standoffs, or stories centered on travelers passing through a growing town.

This pack includes both a Typical Boarding House and a Nice Boarding House, each presented in summer and winter settings, capturing the contrast between rough, utilitarian accommodations and more respectable, well-kept lodgings. Interiors are suited for rented rooms, shared spaces, hushed conversations, and secrets that don’t stay secret for long.

Whether serving as a temporary home for drifters, a cover for undercover work, or the backdrop for late-night confrontations, Western Adventures | Boarding Houses provides versatile, story-rich locations for any Wild West campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Typical Boarding House / Nice Boarding House - summer & winter settings

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
