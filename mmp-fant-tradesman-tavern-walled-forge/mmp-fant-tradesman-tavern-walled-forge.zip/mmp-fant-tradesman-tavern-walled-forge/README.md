# Fantasy Tradesman Tavern | Map Pack (Walled)

Tradesman Tavern | Map Pack provides a hardworking, no-nonsense tavern designed for artisans, laborers, and traveling craftsmen—perfect for grounded fantasy settings, urban intrigue, or low-magic campaigns.

This four-level tavern features practical layouts suited to long stays and busy nights, with ample space for meals, lodging, storage, and informal meetings. It works equally well as a local hub for rumors, a neutral ground for negotiations, or the backdrop for brawls that start over wages and end in spilled ale.

Whether serving as a reliable stop for merchants, a guild-favored watering hole, or a place where deals are struck after dark, Tradesman Tavern | Map Pack offers a versatile and believable setting rooted in everyday fantasy life.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Tradesman Tavern - four levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
