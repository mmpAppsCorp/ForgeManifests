# Viking Village - Fishhouse | Map Pack (Walled)

Viking Village – Fishhouse | Map Pack delivers a practical coastal workspace essential to daily life in a Norse settlement, perfect for survival-focused scenes, economic play, or grounded village encounters.

This pack features a detailed Fishhouse, used for cleaning, drying, and storing the village’s catch. The layout supports scenes involving food production, trade disputes, sabotage, or quiet moments of daily labor that bring authenticity to Viking-era settings.

All land maps are provided in summer and winter environments, allowing you to reflect seasonal hardship, frozen scarcity, or bustling warm-weather activity in your village.

Whether it serves as a humble workplace, a cover for clandestine meetings, or a target during raids, Viking Village – Fishhouse | Map Pack adds believable texture and utility to any Norse-inspired campaign.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Fishhouse

All land maps come in summer and winter environments.

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
