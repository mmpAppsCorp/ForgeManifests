# Medieval City Streets | Map Pack (Walled)

Medieval City Streets | Map Pack delivers a versatile collection of urban street layouts designed to bring historic fantasy cities to life, from bustling market districts to shadowy back alleys and fortified thoroughfares.

This pack includes 15 distinct street configurations, allowing you to represent everything from crowded trade routes and residential lanes to guarded approaches, intersections, and winding city passages. The variety makes it easy to portray different neighborhoods, levels of wealth, and strategic choke points within the same city.

Whether your party is navigating daily city life, staging ambushes, fleeing authorities, or uncovering secrets hidden between stone walls and timbered buildings, Medieval City Streets | Map Pack provides flexible, atmospheric streetscapes ideal for exploration, intrigue, and urban encounters.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Medieval Streets - 15 configurations

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
