# Circus | Map Pack (Walled)

Circus | Map Pack delivers a vibrant and atmospheric performance space ideal for mystery, spectacle, investigations, or chaotic encounters beneath the big top.

This pack includes a detailed Circus Floor, featuring the main ring, seating, and performance areas, along with an elevated Trapeze Level that adds verticality, tension, and opportunities for daring stunts, ambushes, or dramatic reveals.

Whether your scene centers on a dazzling performance, a backstage conspiracy, a daring rescue, or a sudden outbreak of violence amid the crowd, Circus | Map Pack provides a flexible and visually striking setting for modern, pulp, or genre-blending campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Circus - floor & trapeze level

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
