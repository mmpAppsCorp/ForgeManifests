# Fantasy Walled City | Map Pack (Walled)

Walled City Tavern | Map Pack delivers a fortified urban tavern designed for life inside a crowded, defended city—perfect for intrigue, covert meetings, faction politics, or trouble that spills into the streets.

This pack features a three-level Walled City Tavern, combining a busy public taproom with private upper floors and secured back areas suited for smugglers, informants, or city officials who prefer discretion. Thick walls, narrow access points, and layered interiors reinforce the sense of a tavern built to survive unrest, sieges, and watchful authorities.

Whether serving as neutral ground between rival groups, a hideout within city walls, or the starting point for urban adventures, Walled City Tavern | Map Pack provides a dense, story-ready location ideal for fantasy campaigns focused on city life and intrigue.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Walled City Tavern - three levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
