# Modern Military | Map Pack (Walled)

**Modern Military | Map Pack** provides a focused collection of high-security, modern-era military environments designed for tactical operations, covert missions, investigations, and large-scale conflict scenarios. This pack supports stories ranging from elite strike teams and emergency evacuations to training exercises and deep-underground secrets.

At the core of the collection is a fully realized Missile Silo, mapped across ten underground levels plus a ground-level entrance. An additional elevation layout view offers a clear overview of the silo’s vertical structure, making it ideal for infiltration missions, sabotage operations, or last-stand defense scenarios.

Air operations are represented by a detailed Military Cargo Plane, with interior layouts configured for empty, evacuation, and vehicle transport roles. Each version is provided with hatches open and closed, and in flying day, flying night, and landed states—allowing seamless transitions between boarding actions, in-flight emergencies, and ground operations.

The pack also includes a comprehensive Boot Camp, presented in arctic, desert, and grassland environments. This training facility features all essential structures, including an Admin Building, Barracks, Classroom, Firing Range, Mess and Kitchen, and a full Obstacle Course—perfect for training sequences, inspections, drills, or unexpected incidents.

Whether your campaign focuses on modern warfare, espionage, disaster response, or military-adjacent storytelling, **Modern Military | Map Pack** delivers versatile, realistic locations ready to support tense, mission-driven play.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Missile Silo
  - 10 levels underground
  - Ground entrance level
  - Elevation layout view
- Military Cargo Plane
  - Empty, evacuation, and vehicle cargo
  - All maps with hatch open, hatched closed
  - Flying day, flying night, and landed configurations
- Boot Camp - arctic, desert, grass configurations
  - Admin Building
  - Barracks
  - Classroom
  - Firing Range
  - Mess & Kitchen
  - Obstacle Course
---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
