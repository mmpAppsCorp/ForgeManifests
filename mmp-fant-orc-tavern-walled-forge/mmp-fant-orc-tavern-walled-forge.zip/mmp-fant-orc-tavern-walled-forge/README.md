# Orc Tavern | Map Pack (Walled)

Orc Tavern | Map Pack delivers a brutal, battle-scarred gathering place where warriors drink, plan raids, and settle disputes with steel rather than words.

This pack features a rugged Orc Tavern built for strength and intimidation, combining a communal drinking hall with dedicated war levels used for training, armament storage, and tactical gatherings. Heavy construction, crude fortifications, and an atmosphere of constant tension make this location ideal for faction politics, violent negotiations, or all-out brawls.

Whether serving as a clan stronghold, a neutral meeting ground between rival warbands, or the starting point for a brutal campaign arc, Orc Tavern | Map Pack provides a powerful and immersive setting for savage fantasy adventures.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Orc Tavern - tavern & war levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
