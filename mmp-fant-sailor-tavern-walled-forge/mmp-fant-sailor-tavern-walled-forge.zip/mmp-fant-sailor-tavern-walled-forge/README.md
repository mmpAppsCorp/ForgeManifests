# Fantasy Sailor Tavern | Map Pack (Walled)

Sailor Tavern | Map Pack provides a classic waterfront drinking hole ideal for dockside intrigue, hard-earned shore leave, and encounters that smell of salt, rum, and trouble.

This pack features a two-level Sailor Tavern, with a lively ground floor for drinking, gambling, and brawls, and an upper level suited for private rooms, shady deals, or exhausted crews looking for a bed. The layout supports everything from casual roleplay scenes to sudden violence sparked by old grudges or unpaid debts.

Whether it’s a last stop before setting sail, a meeting place for smugglers, or a bar where rumors flow as freely as ale, Sailor Tavern | Map Pack delivers an atmospheric maritime setting ready for adventure.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Sailor Tavern - two levels

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
