# High-End Strip Club | Map Pack (Walled)

High-End Strip Club | Map Pack delivers a sleek, upscale adult-entertainment venue ideal for crime dramas, undercover operations, political intrigue, or noir-style modern campaigns.

This pack features a luxurious Ground Floor club space designed for performances and socializing, a Mezzanine level overlooking the main floor for VIP seating and private interactions, and a detailed Exterior map suitable for arrivals, surveillance, or late-night confrontations.

Whether portrayed as an exclusive nightlife hotspot, a front for illicit dealings, or the focal point of a high-stakes investigation, High-End Strip Club | Map Pack provides a polished and atmospheric setting ready for mature, modern storytelling.

Whether your adventure involves undercover stings, heist planning, gang conflicts, missing-person investigations, or neon-soaked nightlife vignettes, Modern Adult Entertainment | Map Pack gives you immersive modern environments ready for any storyline.

---

## Included Maps

This pack contains the following locations:

- High-End Strip Club - club, mezzanine, exterior

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
