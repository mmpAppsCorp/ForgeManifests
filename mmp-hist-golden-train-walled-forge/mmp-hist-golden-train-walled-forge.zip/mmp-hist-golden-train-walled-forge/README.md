# Golden Age Train | Map Pack (Walled)

Golden Age Train | Map Pack brings the elegance, power, and intrigue of early luxury rail travel to your tabletop, perfect for mysteries, espionage, high-society drama, or period adventures on the move.

This pack features a fully realized steam-era luxury train, from the roaring Steam Engine to richly appointed passenger cars, including dining, sitting, smoking, and sleeper cars. Service areas, luggage sections, and car roofs allow for chases, sabotage, or clandestine meetings as the train speeds onward.

The journey extends beyond the train itself with track environments spanning arctic wilderness, deserts, bridges, mountain passes, rural plains, and classic station platforms—giving you the flexibility to stage encounters anywhere along the route.

Whether your story involves first-class intrigue, a crime unfolding between stops, or danger racing along the rails, Golden Age Train | Map Pack delivers a timeless setting steeped in style and motion.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Golden Age Train
  - Steam Engine
  - Luxury Dining Car
  - Luxury Kitchen Car
  - Luxury Blank Car
  - Luxury Sitting Car
  - Luxury Smoking Car
  - Luxury Sleeper Car
  - Luggage
  - Car Roof
  - Tracks - arctic, bridge, desert, station, grassland, mountains, plains

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
