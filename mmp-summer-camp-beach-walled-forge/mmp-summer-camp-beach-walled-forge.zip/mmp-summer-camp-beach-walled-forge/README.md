# Summer Camp - Beach | Map Pack (Walled)

Summer Camp – Beach | Map Pack delivers a flexible outdoor shoreline setting ideal for recreation, mystery, survival scenarios, or dramatic encounters at the water’s edge.

This pack features a detailed camp Beach environment presented in both calm and rough water conditions, allowing you to shift the mood from peaceful summer activities to dangerous storms, rescues, or escalating threats. The shoreline layout works equally well for daytime leisure, nighttime incidents, or tense investigations.

Whether the beach is a place for swimming and campfire gatherings, a site of an unexpected disappearance, or the backdrop for a sudden emergency, Summer Camp – Beach | Map Pack provides a versatile coastal setting ready for modern, horror, or adventure campaigns.

This version comes with complete line-of-sight setup, with walls, doors, and windows already placed.

---

## Included Maps

This pack contains the following locations:

- Beach - calm & rough waters

Maps are created using DungeonFog.com

---

## Parameters

**Grid:** One grid square equals 70 px.

---

## Compatibility

- **Foundry VTT Version:** 13+  
- Works with any game system.

---

## About MmpApps

MmpApps creates high-quality RPG map packs, virtual tabletop content, and the D6++ tabletop roleplaying system.  
To explore more products across multiple platforms, visit:  
**https://mmpapps.com**

---

## Support

Questions, issues, or permission requests can be sent to:  
**support@mmpapps.com**
